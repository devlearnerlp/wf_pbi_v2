package com.migration.selfservice;

import com.migration.selfservice.SelfServiceModels.*;
import org.springframework.stereotype.Service;
import javax.xml.stream.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Generates valid Microsoft RDL 2016 XML from a self-service ReportDefinition.
 * Thread-safe, null-safe, guaranteed structural correctness.
 */
@Service
public class DynamicRdlGenerator {

    private static final String RDL_NS = "http://schemas.microsoft.com/sqlserver/reporting/2016/01/reportdefinition";
    private static final String RD_NS = "http://schemas.microsoft.com/SQLServer/reporting/reportdesigner";

    public byte[] generate(ReportDefinition def) {
        try {
            AtomicInteger idGen = new AtomicInteger(0);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            XMLStreamWriter w = XMLOutputFactory.newInstance().createXMLStreamWriter(baos, "UTF-8");
            w.writeStartDocument("UTF-8", "1.0");
            w.writeStartElement("Report");
            w.writeAttribute("xmlns", RDL_NS);
            w.writeNamespace("rd", RD_NS);
            el(w, "AutoRefresh", "0");
            writeDataSources(w);
            writeDataSet(w, def, idGen);
            writeBody(w, def, idGen);
            writePage(w);
            el(w, "ConsumeContainerWhitespace", "true");
            el(w, "Language", "en-US");
            w.writeEndElement(); // Report
            w.writeEndDocument();
            w.flush();
            w.close();
            return baos.toByteArray();
        } catch (Exception e) {
            throw new RuntimeException("RDL generation failed: " + e.getMessage(), e);
        }
    }

    // ── Data Sources ─────────────────────────────────────────────
    private void writeDataSources(XMLStreamWriter w) throws XMLStreamException {
        w.writeStartElement("DataSources");
        w.writeStartElement("DataSource");
        w.writeAttribute("Name", "SelfServiceDS");
        w.writeStartElement("ConnectionProperties");
        el(w, "DataProvider", "SQL");
        el(w, "ConnectString", "Data Source=YOUR_SERVER;Initial Catalog=YOUR_DATABASE");
        el(w, "IntegratedSecurity", "true");
        w.writeEndElement(); // ConnectionProperties
        w.writeEndElement(); // DataSource
        w.writeEndElement(); // DataSources
    }

    // ── Data Set ─────────────────────────────────────────────────
    private void writeDataSet(XMLStreamWriter w, ReportDefinition def, AtomicInteger idGen) throws XMLStreamException {
        w.writeStartElement("DataSets");
        w.writeStartElement("DataSet");
        w.writeAttribute("Name", "MainDS");
        w.writeStartElement("Query");
        el(w, "DataSourceName", "SelfServiceDS");
        el(w, "CommandText", buildSql(def));
        w.writeEndElement(); // Query
        w.writeStartElement("Fields");
        Set<String> added = new LinkedHashSet<>();
        for (String g : safeList(def.getGroupBy())) {
            if (added.add(g)) writeField(w, g, "System.String");
        }
        for (String c : safeList(def.getColumns())) {
            if (added.add(c)) writeField(w, c, "System.String");
        }
        for (MeasureField m : safeList(def.getMeasures())) {
            String name = str(m.getField(), "MEASURE_" + idGen.incrementAndGet());
            if (added.add(name)) writeField(w, name, "System.Decimal");
        }
        if (added.isEmpty()) writeField(w, "VALUE", "System.String");
        w.writeEndElement(); // Fields
        w.writeEndElement(); // DataSet
        w.writeEndElement(); // DataSets
    }

    private void writeField(XMLStreamWriter w, String name, String type) throws XMLStreamException {
        String safeName = safe(name);
        w.writeStartElement("Field");
        w.writeAttribute("Name", safeName);
        el(w, "DataField", name);
        w.writeStartElement("rd:TypeName");
        w.writeCharacters(type);
        w.writeEndElement();
        w.writeEndElement();
    }

    // ── Body ─────────────────────────────────────────────────────
    private void writeBody(XMLStreamWriter w, ReportDefinition def, AtomicInteger idGen) throws XMLStreamException {
        w.writeStartElement("ReportSections");
        w.writeStartElement("ReportSection");
        w.writeStartElement("Body");
        el(w, "Height", "8in");
        w.writeStartElement("ReportItems");

        // Title
        writeTextbox(w, idGen, str(def.getTitle(), "Report"), "0in", "0.25in", "0.45in", "9in", "16pt", true, "#1F4E79");

        String vt = def.getOptions() != null ? str(def.getOptions().getVisualType(), "table") : "table";
        boolean hasChart = vt.equals("bar") || vt.equals("line") || vt.equals("pie") || vt.equals("area");
        if (hasChart) writeChart(w, def, idGen, 0.6);

        double tableTop = hasChart ? 4.5 : 0.6;
        boolean isMatrix = !safeList(def.getColumns()).isEmpty();
        if (isMatrix) writeMatrix(w, def, idGen, tableTop);
        else writeTablix(w, def, idGen, tableTop);

        w.writeEndElement(); // ReportItems
        w.writeEndElement(); // Body

        writePageHeader(w, def, idGen);
        writePageFooter(w, idGen);
        el(w, "Width", "10in");
        w.writeEndElement(); // ReportSection
        w.writeEndElement(); // ReportSections
    }

    // ── Tablix ───────────────────────────────────────────────────
    private void writeTablix(XMLStreamWriter w, ReportDefinition def, AtomicInteger idGen, double topInch) throws XMLStreamException {
        List<String> labels = new ArrayList<>();
        List<String> exprs = new ArrayList<>();
        List<Boolean> isNum = new ArrayList<>();

        for (String g : safeList(def.getGroupBy())) {
            labels.add(g);
            exprs.add("=Fields!" + safe(g) + ".Value");
            isNum.add(false);
        }
        for (MeasureField m : safeList(def.getMeasures())) {
            String name = str(m.getField(), "MEASURE");
            labels.add(str(m.getAlias(), name));
            exprs.add("=" + mapAgg(m.getAggregation()) + "(Fields!" + safe(name) + ".Value)");
            isNum.add(true);
        }
        if (labels.isEmpty()) {
            labels.add("Value");
            exprs.add("=\"(no data)\"");
            isNum.add(false);
        }

        final int numCols = labels.size();
        double colW = Math.min(2.5, 9.0 / numCols);
        boolean hasSub = def.getOptions() != null && def.getOptions().isSubtotals() && !safeList(def.getGroupBy()).isEmpty();

        w.writeStartElement("Tablix");
        w.writeAttribute("Name", "DataTable");

        // TablixBody
        w.writeStartElement("TablixBody");
        w.writeStartElement("TablixColumns");
        for (int i = 0; i < numCols; i++) {
            w.writeStartElement("TablixColumn");
            el(w, "Width", fmt(colW) + "in");
            w.writeEndElement();
        }
        w.writeEndElement(); // TablixColumns

        w.writeStartElement("TablixRows");
        writeRow(w, "0.30in", numCols, i -> writeHdrCell(w, idGen, labels.get(i)));
        writeRow(w, "0.25in", numCols, i -> writeDataCell(w, idGen, exprs.get(i), isNum.get(i)));
        if (hasSub) {
            final List<String> fe = exprs;
            final List<Boolean> fn = isNum;
            writeRow(w, "0.28in", numCols, i -> {
                if (i == 0) writeSubCell(w, idGen, "=\"Subtotal\"", false);
                else if (fn.get(i)) writeSubCell(w, idGen, fe.get(i), true);
                else writeSubCell(w, idGen, "", false);
            });
        }
        w.writeEndElement(); // TablixRows
        w.writeEndElement(); // TablixBody

        // Column hierarchy
        w.writeStartElement("TablixColumnHierarchy");
        w.writeStartElement("TablixMembers");
        for (int i = 0; i < numCols; i++) {
            w.writeStartElement("TablixMember");
            w.writeEndElement();
        }
        w.writeEndElement();
        w.writeEndElement();

        // Row hierarchy
        w.writeStartElement("TablixRowHierarchy");
        w.writeStartElement("TablixMembers");
        w.writeStartElement("TablixMember");
        el(w, "KeepWithGroup", "After");
        el(w, "RepeatOnNewPage", "true");
        w.writeEndElement();

        if (!safeList(def.getGroupBy()).isEmpty()) {
            writeRowGroups(w, def, 0);
        } else {
            w.writeStartElement("TablixMember");
            w.writeStartElement("Group");
            w.writeAttribute("Name", "Detail_SS");
            w.writeEndElement();
            w.writeEndElement();
        }

        if (hasSub) {
            w.writeStartElement("TablixMember");
            el(w, "KeepWithGroup", "Before");
            w.writeEndElement();
        }
        w.writeEndElement(); // TablixMembers
        w.writeEndElement(); // TablixRowHierarchy

        el(w, "DataSetName", "MainDS");
        el(w, "Top", fmt(topInch) + "in");
        el(w, "Left", "0.25in");
        el(w, "Height", "2in");
        el(w, "Width", fmt(colW * numCols) + "in");
        el(w, "NoRowsMessage", "No data available");
        w.writeStartElement("Style");
        el(w, "FontFamily", "Segoe UI");
        el(w, "FontSize", "9pt");
        w.writeEndElement();
        w.writeEndElement(); // Tablix
    }

    // ── Row Writer ───────────────────────────────────────────────
    @FunctionalInterface
    interface CellWriter { void write(int idx) throws XMLStreamException; }

    private void writeRow(XMLStreamWriter w, String height, int numCols, CellWriter writer) throws XMLStreamException {
        w.writeStartElement("TablixRow");
        el(w, "Height", height);
        w.writeStartElement("TablixCells");
        for (int i = 0; i < numCols; i++) {
            w.writeStartElement("TablixCell");
            w.writeStartElement("CellContents");
            writer.write(i);
            w.writeEndElement(); // CellContents
            w.writeEndElement(); // TablixCell
        }
        w.writeEndElement(); // TablixCells
        w.writeEndElement(); // TablixRow
    }

    // ── Cell Writers ─────────────────────────────────────────────
    private void writeHdrCell(XMLStreamWriter w, AtomicInteger idGen, String label) throws XMLStreamException {
        w.writeStartElement("Textbox"); w.writeAttribute("Name", "H" + idGen.incrementAndGet());
        w.writeStartElement("Paragraphs"); w.writeStartElement("Paragraph"); w.writeStartElement("TextRuns"); w.writeStartElement("TextRun");
        el(w, "Value", label);
        w.writeStartElement("Style"); el(w, "FontFamily", "Segoe UI"); el(w, "FontSize", "9pt"); el(w, "FontWeight", "Bold"); el(w, "Color", "White"); w.writeEndElement();
        w.writeEndElement(); w.writeEndElement(); w.writeEndElement(); w.writeEndElement();
        w.writeStartElement("Style"); el(w, "BackgroundColor", "#1F4E79"); el(w, "PaddingLeft", "4pt"); el(w, "PaddingRight", "4pt"); el(w, "PaddingTop", "2pt"); el(w, "PaddingBottom", "2pt");
        writeBorder(w); w.writeEndElement();
        w.writeEndElement(); // Textbox
    }

    private void writeDataCell(XMLStreamWriter w, AtomicInteger idGen, String expr, boolean numeric) throws XMLStreamException {
        w.writeStartElement("Textbox"); w.writeAttribute("Name", "D" + idGen.incrementAndGet());
        w.writeStartElement("Paragraphs"); w.writeStartElement("Paragraph"); w.writeStartElement("TextRuns"); w.writeStartElement("TextRun");
        el(w, "Value", expr);
        w.writeStartElement("Style"); el(w, "FontFamily", "Segoe UI"); el(w, "FontSize", "8pt"); if (numeric) el(w, "Format", "#,##0.00"); w.writeEndElement();
        w.writeEndElement(); w.writeEndElement();
        w.writeStartElement("Style"); if (numeric) el(w, "TextAlign", "Right"); w.writeEndElement();
        w.writeEndElement(); w.writeEndElement();
        w.writeStartElement("Style"); el(w, "PaddingLeft", "4pt"); el(w, "PaddingRight", "4pt"); el(w, "PaddingTop", "2pt"); el(w, "PaddingBottom", "2pt");
        writeBorder(w); w.writeEndElement();
        w.writeEndElement(); // Textbox
    }

    private void writeSubCell(XMLStreamWriter w, AtomicInteger idGen, String expr, boolean numeric) throws XMLStreamException {
        w.writeStartElement("Textbox"); w.writeAttribute("Name", "S" + idGen.incrementAndGet());
        w.writeStartElement("Paragraphs"); w.writeStartElement("Paragraph"); w.writeStartElement("TextRuns"); w.writeStartElement("TextRun");
        el(w, "Value", expr);
        w.writeStartElement("Style"); el(w, "FontWeight", "Bold"); el(w, "FontSize", "8pt"); if (numeric) el(w, "Format", "#,##0.00"); w.writeEndElement();
        w.writeEndElement(); w.writeEndElement();
        w.writeStartElement("Style"); if (numeric) el(w, "TextAlign", "Right"); w.writeEndElement();
        w.writeEndElement(); w.writeEndElement();
        w.writeStartElement("Style"); el(w, "BackgroundColor", "#E2EFDA"); el(w, "PaddingLeft", "4pt"); el(w, "PaddingRight", "4pt");
        writeBorder(w); w.writeEndElement();
        w.writeEndElement(); // Textbox
    }

    private void writeTextbox(XMLStreamWriter w, AtomicInteger idGen, String text, String top, String left, String height, String width, String fontSize, boolean bold, String color) throws XMLStreamException {
        w.writeStartElement("Textbox"); w.writeAttribute("Name", "T" + idGen.incrementAndGet());
        w.writeStartElement("Paragraphs"); w.writeStartElement("Paragraph"); w.writeStartElement("TextRuns"); w.writeStartElement("TextRun");
        el(w, "Value", text);
        w.writeStartElement("Style"); el(w, "FontFamily", "Segoe UI"); el(w, "FontSize", fontSize); if (bold) el(w, "FontWeight", "Bold"); if (color != null) el(w, "Color", color); w.writeEndElement();
        w.writeEndElement(); w.writeEndElement(); w.writeEndElement(); w.writeEndElement();
        el(w, "Top", top); el(w, "Left", left); el(w, "Height", height); el(w, "Width", width);
        w.writeEndElement(); // Textbox
    }

    private void writeBorder(XMLStreamWriter w) throws XMLStreamException {
        w.writeStartElement("Border"); el(w, "Style", "Solid"); el(w, "Width", "0.5pt"); el(w, "Color", "#C0C0C0"); w.writeEndElement();
    }

    // ── Row Groups ───────────────────────────────────────────────
    private void writeRowGroups(XMLStreamWriter w, ReportDefinition def, int depth) throws XMLStreamException {
        List<String> groups = safeList(def.getGroupBy());
        if (depth >= groups.size()) {
            w.writeStartElement("TablixMember");
            w.writeStartElement("Group"); w.writeAttribute("Name", "Detail_SS"); w.writeEndElement();
            w.writeEndElement();
            return;
        }
        String field = groups.get(depth);
        String safeName = safe(field);
        boolean pgBreak = def.getOptions() != null && field.equals(def.getOptions().getPageBreakOn());

        w.writeStartElement("TablixMember");
        w.writeStartElement("Group"); w.writeAttribute("Name", "Grp_SS_" + safeName + "_" + depth);
        w.writeStartElement("GroupExpressions"); el(w, "GroupExpression", "=Fields!" + safeName + ".Value"); w.writeEndElement();
        if (pgBreak) { w.writeStartElement("PageBreak"); el(w, "BreakLocation", "Between"); w.writeEndElement(); }
        w.writeEndElement(); // Group
        w.writeStartElement("SortExpressions"); w.writeStartElement("SortExpression");
        el(w, "Value", "=Fields!" + safeName + ".Value"); el(w, "Direction", "Ascending");
        w.writeEndElement(); w.writeEndElement();
        w.writeStartElement("TablixMembers"); writeRowGroups(w, def, depth + 1); w.writeEndElement();
        w.writeEndElement(); // TablixMember
    }

    // ── Matrix ───────────────────────────────────────────────────
    private void writeMatrix(XMLStreamWriter w, ReportDefinition def, AtomicInteger idGen, double top) throws XMLStreamException {
        String rowF = !safeList(def.getGroupBy()).isEmpty() ? def.getGroupBy().get(0) : "Row";
        String colF = def.getColumns().get(0);
        MeasureField mf = !safeList(def.getMeasures()).isEmpty() ? def.getMeasures().get(0) : null;
        String mExpr = mf != null ? "=" + mapAgg(mf.getAggregation()) + "(Fields!" + safe(str(mf.getField(), "VAL")) + ".Value)" : "=\"\"";
        String mLabel = mf != null ? str(mf.getAlias(), str(mf.getField(), "Value")) : "Value";
        String sRow = safe(rowF);
        String sCol = safe(colF);

        w.writeStartElement("Tablix"); w.writeAttribute("Name", "Matrix");
        w.writeStartElement("TablixBody");
        w.writeStartElement("TablixColumns");
        w.writeStartElement("TablixColumn"); el(w, "Width", "2in"); w.writeEndElement();
        w.writeStartElement("TablixColumn"); el(w, "Width", "1.5in"); w.writeEndElement();
        w.writeEndElement();
        w.writeStartElement("TablixRows");
        writeRow(w, "0.30in", 2, i -> { if (i == 0) writeHdrCell(w, idGen, rowF); else writeHdrCell(w, idGen, mLabel); });
        writeRow(w, "0.25in", 2, i -> { if (i == 0) writeDataCell(w, idGen, "=Fields!" + sRow + ".Value", false); else writeDataCell(w, idGen, mExpr, true); });
        w.writeEndElement(); w.writeEndElement();

        w.writeStartElement("TablixColumnHierarchy"); w.writeStartElement("TablixMembers");
        w.writeStartElement("TablixMember"); w.writeEndElement();
        w.writeStartElement("TablixMember");
        w.writeStartElement("Group"); w.writeAttribute("Name", "ColGrp_SS_" + sCol);
        w.writeStartElement("GroupExpressions"); el(w, "GroupExpression", "=Fields!" + sCol + ".Value"); w.writeEndElement();
        w.writeEndElement(); w.writeEndElement();
        w.writeEndElement(); w.writeEndElement();

        w.writeStartElement("TablixRowHierarchy"); w.writeStartElement("TablixMembers");
        w.writeStartElement("TablixMember"); el(w, "KeepWithGroup", "After"); w.writeEndElement();
        w.writeStartElement("TablixMember");
        w.writeStartElement("Group"); w.writeAttribute("Name", "RowGrp_SS_" + sRow);
        w.writeStartElement("GroupExpressions"); el(w, "GroupExpression", "=Fields!" + sRow + ".Value"); w.writeEndElement();
        w.writeEndElement(); w.writeEndElement();
        w.writeEndElement(); w.writeEndElement();

        el(w, "DataSetName", "MainDS"); el(w, "Top", fmt(top) + "in"); el(w, "Left", "0.25in"); el(w, "Height", "2in"); el(w, "Width", "6in"); el(w, "NoRowsMessage", "No data available");
        w.writeEndElement(); // Tablix
    }

    // ── Chart ────────────────────────────────────────────────────
    private void writeChart(XMLStreamWriter w, ReportDefinition def, AtomicInteger idGen, double top) throws XMLStreamException {
        String vt = def.getOptions() != null ? str(def.getOptions().getVisualType(), "bar") : "bar";
        String type = switch (vt) { case "pie" -> "Shape"; case "line" -> "Line"; case "area" -> "Area"; default -> "Column"; };

        w.writeStartElement("Chart"); w.writeAttribute("Name", "Chart_SS");

        // Category
        w.writeStartElement("ChartCategoryHierarchy"); w.writeStartElement("ChartMembers"); w.writeStartElement("ChartMember");
        if (!safeList(def.getGroupBy()).isEmpty()) {
            String catField = safe(def.getGroupBy().get(0));
            w.writeStartElement("Group"); w.writeAttribute("Name", "ChCat_SS");
            w.writeStartElement("GroupExpressions"); el(w, "GroupExpression", "=Fields!" + catField + ".Value"); w.writeEndElement();
            w.writeEndElement();
            el(w, "Label", "=Fields!" + catField + ".Value");
        }
        w.writeEndElement(); w.writeEndElement(); w.writeEndElement();

        // Series
        w.writeStartElement("ChartSeriesHierarchy"); w.writeStartElement("ChartMembers");
        w.writeStartElement("ChartMember"); w.writeEndElement();
        w.writeEndElement(); w.writeEndElement();

        // Data — guarantee at least one series
        w.writeStartElement("ChartData"); w.writeStartElement("ChartSeriesCollection");
        boolean hasSeries = false;
        for (MeasureField m : safeList(def.getMeasures())) {
            String fname = safe(str(m.getField(), "VAL"));
            w.writeStartElement("ChartSeries"); w.writeStartElement("ChartDataPoints"); w.writeStartElement("ChartDataPoint");
            w.writeStartElement("ChartDataPointValues"); el(w, "Y", "=Sum(Fields!" + fname + ".Value)"); w.writeEndElement();
            w.writeStartElement("ChartDataLabel"); el(w, "Visible", "false"); w.writeEndElement();
            w.writeEndElement(); w.writeEndElement(); el(w, "Type", type); w.writeEndElement();
            hasSeries = true;
        }
        if (!hasSeries) {
            w.writeStartElement("ChartSeries"); w.writeStartElement("ChartDataPoints"); w.writeStartElement("ChartDataPoint");
            w.writeStartElement("ChartDataPointValues"); el(w, "Y", "=Count(Fields!VALUE.Value)"); w.writeEndElement();
            w.writeStartElement("ChartDataLabel"); el(w, "Visible", "false"); w.writeEndElement();
            w.writeEndElement(); w.writeEndElement(); el(w, "Type", type); w.writeEndElement();
        }
        w.writeEndElement(); w.writeEndElement();

        w.writeStartElement("ChartAreas"); w.writeStartElement("ChartArea"); w.writeAttribute("Name", "Default"); w.writeEndElement(); w.writeEndElement();
        w.writeStartElement("ChartLegends"); w.writeStartElement("ChartLegend"); w.writeAttribute("Name", "Default"); w.writeStartElement("Style"); w.writeEndElement(); w.writeEndElement(); w.writeEndElement();
        el(w, "DataSetName", "MainDS"); el(w, "Top", fmt(top) + "in"); el(w, "Left", "0.25in"); el(w, "Height", "3.5in"); el(w, "Width", "8in");
        w.writeEndElement(); // Chart
    }

    // ── Page Header / Footer / Setup ─────────────────────────────
    private void writePageHeader(XMLStreamWriter w, ReportDefinition def, AtomicInteger idGen) throws XMLStreamException {
        w.writeStartElement("PageHeader"); el(w, "Height", "0.4in"); el(w, "PrintOnFirstPage", "true"); el(w, "PrintOnLastPage", "true");
        w.writeStartElement("ReportItems");
        writeTextbox(w, idGen, str(def.getTitle(), "Report"), "0in", "0in", "0.3in", "9.5in", "10pt", true, "#1F4E79");
        w.writeEndElement(); w.writeEndElement();
    }

    private void writePageFooter(XMLStreamWriter w, AtomicInteger idGen) throws XMLStreamException {
        w.writeStartElement("PageFooter"); el(w, "Height", "0.35in"); el(w, "PrintOnFirstPage", "true"); el(w, "PrintOnLastPage", "true");
        w.writeStartElement("ReportItems");
        // Date
        w.writeStartElement("Textbox"); w.writeAttribute("Name", "FD" + idGen.incrementAndGet());
        w.writeStartElement("Paragraphs"); w.writeStartElement("Paragraph"); w.writeStartElement("TextRuns"); w.writeStartElement("TextRun");
        el(w, "Value", "=\"Generated: \" & Format(Now(), \"yyyy-MM-dd HH:mm\")");
        w.writeStartElement("Style"); el(w, "FontSize", "8pt"); el(w, "Color", "#999999"); w.writeEndElement();
        w.writeEndElement(); w.writeEndElement(); w.writeEndElement(); w.writeEndElement();
        el(w, "Top", "0in"); el(w, "Left", "0in"); el(w, "Height", "0.25in"); el(w, "Width", "4in"); w.writeEndElement();
        // Page#
        w.writeStartElement("Textbox"); w.writeAttribute("Name", "FP" + idGen.incrementAndGet());
        w.writeStartElement("Paragraphs"); w.writeStartElement("Paragraph"); w.writeStartElement("TextRuns"); w.writeStartElement("TextRun");
        el(w, "Value", "=\"Page \" & Globals!PageNumber & \" of \" & Globals!TotalPages");
        w.writeStartElement("Style"); el(w, "FontSize", "8pt"); el(w, "Color", "#999999"); w.writeEndElement();
        w.writeEndElement(); w.writeEndElement();
        w.writeStartElement("Style"); el(w, "TextAlign", "Right"); w.writeEndElement();
        w.writeEndElement(); w.writeEndElement();
        el(w, "Top", "0in"); el(w, "Left", "5.5in"); el(w, "Height", "0.25in"); el(w, "Width", "4in"); w.writeEndElement();
        w.writeEndElement(); w.writeEndElement();
    }

    private void writePage(XMLStreamWriter w) throws XMLStreamException {
        w.writeStartElement("Page");
        el(w, "PageHeight", "11in"); el(w, "PageWidth", "8.5in");
        el(w, "LeftMargin", "0.5in"); el(w, "RightMargin", "0.5in"); el(w, "TopMargin", "0.5in"); el(w, "BottomMargin", "0.5in");
        w.writeStartElement("Style"); w.writeEndElement();
        w.writeEndElement();
    }

    // ── SQL ──────────────────────────────────────────────────────
    private String buildSql(ReportDefinition def) {
        StringBuilder sql = new StringBuilder("SELECT ");
        List<String> cols = new ArrayList<>();
        for (String g : safeList(def.getGroupBy())) cols.add(g);
        for (String c : safeList(def.getColumns())) { if (!cols.contains(c)) cols.add(c); }
        for (MeasureField m : safeList(def.getMeasures())) { String n = str(m.getField(), "MEASURE"); if (!cols.contains(n)) cols.add(n); }
        if (cols.isEmpty()) cols.add("*");
        sql.append(String.join(", ", cols)).append("\nFROM dbo.").append(str(def.getDataSource(), "TABLE_NAME"));

        List<FilterCondition> filters = safeList(def.getFilters());
        if (!filters.isEmpty()) {
            List<String> clauses = new ArrayList<>();
            for (FilterCondition f : filters) {
                if (f.getField() == null || f.getField().isBlank() || f.getValue() == null || f.getValue().isBlank()) continue;
                String val = f.getValue();
                String op = str(f.getOperator(), "=");
                if (op.equalsIgnoreCase("LIKE")) val = "'%" + val + "%'";
                else if (op.equalsIgnoreCase("IN")) val = "(" + val + ")";
                else { try { Double.parseDouble(val); } catch (Exception e) { val = "'" + val + "'"; } }
                clauses.add(f.getField() + " " + op + " " + val);
            }
            if (!clauses.isEmpty()) sql.append("\nWHERE ").append(String.join("\n  AND ", clauses));
        }

        ReportOptions opts = def.getOptions();
        if (opts != null && opts.getSortField() != null && !opts.getSortField().isEmpty()) {
            sql.append("\nORDER BY ").append(opts.getSortField()).append(" ").append(str(opts.getSortDirection(), "ASC"));
        }
        return sql.toString();
    }

    // ── Utilities ────────────────────────────────────────────────
    private void el(XMLStreamWriter w, String n, String v) throws XMLStreamException { w.writeStartElement(n); w.writeCharacters(v); w.writeEndElement(); }

    private String safe(String name) {
        if (name == null) return "UNNAMED";
        String result = name.replaceAll("[^a-zA-Z0-9_]", "_");
        if (!result.isEmpty() && Character.isDigit(result.charAt(0))) result = "F_" + result;
        return result.isEmpty() ? "UNNAMED" : result;
    }

    private String str(String value, String fallback) { return (value != null && !value.isBlank()) ? value : fallback; }

    @SuppressWarnings("unchecked")
    private <T> List<T> safeList(List<T> list) { return list != null ? list : Collections.emptyList(); }

    private String fmt(double v) { return String.format(java.util.Locale.US, "%.2f", v); }

    private String mapAgg(String a) {
        if (a == null) return "Sum";
        return switch (a.toUpperCase()) { case "SUM" -> "Sum"; case "AVG" -> "Avg"; case "MIN" -> "Min"; case "MAX" -> "Max"; case "COUNT" -> "Count"; default -> "Sum"; };
    }
}
