package com.migration.export;

import com.migration.converter.ExpressionConverter;
import com.migration.model.ConversionResult;
import com.migration.model.ParsedFexFile;
import com.migration.model.ParsedFexFile.*;
import org.springframework.stereotype.Service;

import javax.xml.stream.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Generates valid Microsoft RDL 2016 XML from parsed FEX files.
 *
 * Critical RDL rules enforced:
 *  - Every TablixRow has EXACTLY the same number of TablixCell elements as TablixColumns
 *  - Every Textbox has a globally unique Name attribute
 *  - Every Group has a globally unique Name attribute
 *  - ChartSeriesCollection always has at least one ChartSeries
 *  - All names are XML-safe (alphanumeric + underscore only)
 *  - All decimal formatting uses Locale.US (dot separator, never comma)
 *  - Thread-safe: counter is per-invocation, not shared across threads
 */
@Service
public class RdlGenerator {

    private static final String RDL_NS = "http://schemas.microsoft.com/sqlserver/reporting/2016/01/reportdefinition";
    private static final String RD_NS = "http://schemas.microsoft.com/SQLServer/reporting/reportdesigner";
    private final ExpressionConverter exprConverter;

    public RdlGenerator(ExpressionConverter exprConverter) {
        this.exprConverter = exprConverter;
    }

    public byte[] generateRdl(ParsedFexFile fex, ConversionResult conversion) {
        try {
            // Thread-safe: new counter per invocation
            AtomicInteger idGen = new AtomicInteger(0);

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            XMLStreamWriter w = XMLOutputFactory.newInstance().createXMLStreamWriter(baos, "UTF-8");

            w.writeStartDocument("UTF-8", "1.0");
            w.writeStartElement("Report");
            w.writeAttribute("xmlns", RDL_NS);
            w.writeNamespace("rd", RD_NS);

            el(w, "AutoRefresh", "0");
            writeDataSources(w);
            writeDataSets(w, fex, idGen);
            writeReportParameters(w, fex);
            writeReportSections(w, fex, idGen);
            writePage(w);
            el(w, "ConsumeContainerWhitespace", "true");
            el(w, "Language", "en-US");

            w.writeEndElement(); // Report
            w.writeEndDocument();
            w.flush();
            w.close();
            return baos.toByteArray();
        } catch (Exception e) {
            throw new RuntimeException("RDL generation failed: " + e.getMessage(), e);
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // DATA SOURCES
    // ═══════════════════════════════════════════════════════════════
    private void writeDataSources(XMLStreamWriter w) throws XMLStreamException {
        w.writeStartElement("DataSources");
        w.writeStartElement("DataSource");
        w.writeAttribute("Name", "WebFocusDataSource");
        w.writeStartElement("ConnectionProperties");
        el(w, "DataProvider", "SQL");
        el(w, "ConnectString", "Data Source=YOUR_SERVER;Initial Catalog=YOUR_DATABASE");
        el(w, "IntegratedSecurity", "true");
        w.writeEndElement(); // ConnectionProperties
        w.writeEndElement(); // DataSource
        w.writeEndElement(); // DataSources
    }

    // ═══════════════════════════════════════════════════════════════
    // DATA SETS
    // ═══════════════════════════════════════════════════════════════
    private void writeDataSets(XMLStreamWriter w, ParsedFexFile fex, AtomicInteger idGen) throws XMLStreamException {
        List<TableRequest> requests = safeList(fex.getRequests());
        if (requests.isEmpty()) return;

        w.writeStartElement("DataSets");
        int dsIdx = 1;
        for (TableRequest req : requests) {
            String fileName = safeStr(req.getFile(), "TABLE");
            String dsName = "DS_" + safe(fileName) + "_" + dsIdx;

            w.writeStartElement("DataSet");
            w.writeAttribute("Name", dsName);

            // Query
            w.writeStartElement("Query");
            el(w, "DataSourceName", "WebFocusDataSource");
            el(w, "CommandText", buildSql(req));
            w.writeEndElement(); // Query

            // Fields
            w.writeStartElement("Fields");
            Set<String> added = new LinkedHashSet<>();
            for (String g : safeList(req.getGroupBy())) {
                if (added.add(g)) writeField(w, g, guessType(g, fex));
            }
            for (String a : safeList(req.getAcrossFields())) {
                if (added.add(a)) writeField(w, a, "System.String");
            }
            for (RequestField rf : safeList(req.getFields())) {
                String name = safeStr(rf.getName(), "FIELD_" + idGen.incrementAndGet());
                if (added.add(name)) {
                    writeField(w, name, rf.getAggregation() != null ? "System.Decimal" : guessType(name, fex));
                }
            }
            for (ComputeField cf : safeList(req.getComputes())) {
                String name = safeStr(cf.getField(), "COMP_" + idGen.incrementAndGet());
                if (added.add(name)) writeField(w, name, "System.Decimal");
            }
            // Guarantee at least one field
            if (added.isEmpty()) {
                writeField(w, "VALUE", "System.String");
            }
            w.writeEndElement(); // Fields
            w.writeEndElement(); // DataSet
            dsIdx++;
        }
        w.writeEndElement(); // DataSets
    }

    private void writeField(XMLStreamWriter w, String name, String type) throws XMLStreamException {
        String safeName = safe(name);
        if (safeName.isEmpty()) safeName = "F_UNNAMED";
        w.writeStartElement("Field");
        w.writeAttribute("Name", safeName);
        el(w, "DataField", name);
        w.writeStartElement("rd:TypeName");
        w.writeCharacters(type);
        w.writeEndElement();
        w.writeEndElement();
    }

    // ═══════════════════════════════════════════════════════════════
    // PARAMETERS
    // ═══════════════════════════════════════════════════════════════
    private void writeReportParameters(XMLStreamWriter w, ParsedFexFile fex) throws XMLStreamException {
        List<PromptSpec> prompts = safeList(fex.getPrompts());
        List<Variable> vars = safeList(fex.getVariables());
        if (prompts.isEmpty() && vars.isEmpty()) return;

        w.writeStartElement("ReportParameters");

        for (PromptSpec p : prompts) {
            String name = safeStr(p.getParamName(), "param_" + p.getLine());
            w.writeStartElement("ReportParameter");
            w.writeAttribute("Name", safe(name));
            el(w, "DataType", mapParamType(p.getParamType()));
            el(w, "Nullable", "false");
            el(w, "Prompt", safeStr(p.getDescription(), name));
            if (p.getDefaultValue() != null && !p.getDefaultValue().isEmpty()) {
                w.writeStartElement("DefaultValue");
                w.writeStartElement("Values");
                el(w, "Value", p.getDefaultValue());
                w.writeEndElement(); // Values
                w.writeEndElement(); // DefaultValue
            }
            w.writeEndElement(); // ReportParameter
        }

        for (Variable v : vars) {
            String name = safeStr(v.getName(), "VAR");
            String value = v.getValue() != null ? v.getValue().replaceAll("^['\"]|['\"]$", "") : "";
            w.writeStartElement("ReportParameter");
            w.writeAttribute("Name", safe(name));
            el(w, "DataType", "String");
            el(w, "Nullable", "false");
            el(w, "Prompt", name);
            w.writeStartElement("DefaultValue");
            w.writeStartElement("Values");
            el(w, "Value", value);
            w.writeEndElement(); // Values
            w.writeEndElement(); // DefaultValue
            w.writeEndElement(); // ReportParameter
        }

        w.writeEndElement(); // ReportParameters
    }

    // ═══════════════════════════════════════════════════════════════
    // REPORT SECTIONS (Body + Header + Footer)
    // ═══════════════════════════════════════════════════════════════
    private void writeReportSections(XMLStreamWriter w, ParsedFexFile fex, AtomicInteger idGen) throws XMLStreamException {
        List<TableRequest> requests = safeList(fex.getRequests());

        w.writeStartElement("ReportSections");
        w.writeStartElement("ReportSection");

        // Body
        w.writeStartElement("Body");
        double totalHeight = calcHeight(requests);
        el(w, "Height", fmt(Math.max(2.0, totalHeight)) + "in");

        w.writeStartElement("ReportItems");

        if (requests.isEmpty()) {
            // Empty report — add a placeholder textbox so ReportItems is not empty
            writeTextbox(w, idGen, "No report requests found", "0in", "0.25in", "0.5in", "6in", "12pt", false);
        } else {
            double top = 0;
            int reqIdx = 1;
            for (TableRequest req : requests) {
                String fileName = safeStr(req.getFile(), "TABLE");
                String dsName = "DS_" + safe(fileName) + "_" + reqIdx;
                String type = safeStr(req.getType(), "TABLE");

                if ("GRAPH".equals(type)) {
                    writeChart(w, req, dsName, reqIdx, idGen, top);
                    top += 4.0;
                } else if (!safeList(req.getAcrossFields()).isEmpty()) {
                    writeMatrix(w, req, dsName, reqIdx, idGen, top);
                    top += 2.5;
                } else {
                    writeTablix(w, req, dsName, reqIdx, idGen, top);
                    top += estimateHeight(req);
                }
                reqIdx++;
            }
        }

        w.writeEndElement(); // ReportItems
        w.writeEndElement(); // Body

        writePageHeader(w, fex, idGen);
        writePageFooter(w, idGen);

        el(w, "Width", "10in");
        w.writeEndElement(); // ReportSection
        w.writeEndElement(); // ReportSections
    }

    // ═══════════════════════════════════════════════════════════════
    // TABLIX (Standard Table)
    // ═══════════════════════════════════════════════════════════════
    private void writeTablix(XMLStreamWriter w, TableRequest req, String dsName, int reqIdx,
                             AtomicInteger idGen, double top) throws XMLStreamException {
        // Build column specs — label, expression, isNumeric for each column
        List<String> labels = new ArrayList<>();
        List<String> exprs = new ArrayList<>();
        List<Boolean> isNum = new ArrayList<>();

        for (RequestField rf : safeList(req.getFields())) {
            if (rf.isNoprint()) continue;
            String name = safeStr(rf.getName(), "FIELD");
            labels.add(safeStr(rf.getAlias(), name));
            if (rf.getAggregation() != null) {
                exprs.add("=" + mapAgg(rf.getAggregation()) + "(Fields!" + safe(name) + ".Value)");
                isNum.add(true);
            } else {
                exprs.add("=Fields!" + safe(name) + ".Value");
                isNum.add(false);
            }
        }
        for (ComputeField cf : safeList(req.getComputes())) {
            String name = safeStr(cf.getField(), "COMPUTE");
            labels.add(name);
            exprs.add("=Fields!" + safe(name) + ".Value");
            isNum.add(true);
        }

        // MUST have at least 1 column
        if (labels.isEmpty()) {
            labels.add("Value");
            exprs.add("=\"(no data)\"");
            isNum.add(false);
        }

        final int numCols = labels.size();
        double colW = Math.min(2.5, 9.5 / numCols);
        boolean hasSub = req.isSubTotals() && !safeList(req.getGroupBy()).isEmpty();

        w.writeStartElement("Tablix");
        w.writeAttribute("Name", "Tbl_" + reqIdx + "_" + safe(dsName));

        // ── TablixBody ──
        w.writeStartElement("TablixBody");

        // Columns
        w.writeStartElement("TablixColumns");
        for (int i = 0; i < numCols; i++) {
            w.writeStartElement("TablixColumn");
            el(w, "Width", fmt(colW) + "in");
            w.writeEndElement();
        }
        w.writeEndElement(); // TablixColumns

        // Rows — each row MUST have exactly numCols TablixCells
        w.writeStartElement("TablixRows");

        // Row 1: Header
        writeRow(w, "0.30in", numCols, i -> writeHdrCell(w, idGen, labels.get(i)));

        // Row 2: Detail
        writeRow(w, "0.25in", numCols, i -> writeDataCell(w, idGen, exprs.get(i), isNum.get(i)));

        // Row 3: Subtotal (optional, only if subtotals enabled AND groups exist)
        if (hasSub) {
            // Capture the final lists for the lambda
            final List<String> fExprs = exprs;
            final List<Boolean> fIsNum = isNum;
            writeRow(w, "0.28in", numCols, i -> {
                if (i == 0) writeSubCell(w, idGen, "=\"Subtotal\"", false);
                else if (fIsNum.get(i)) writeSubCell(w, idGen, fExprs.get(i), true);
                else writeSubCell(w, idGen, "", false);
            });
        }

        w.writeEndElement(); // TablixRows
        w.writeEndElement(); // TablixBody

        // ── Column Hierarchy (one static TablixMember per column) ──
        w.writeStartElement("TablixColumnHierarchy");
        w.writeStartElement("TablixMembers");
        for (int i = 0; i < numCols; i++) {
            w.writeStartElement("TablixMember");
            w.writeEndElement();
        }
        w.writeEndElement(); // TablixMembers
        w.writeEndElement(); // TablixColumnHierarchy

        // ── Row Hierarchy ──
        // Must have exactly as many leaf TablixMembers as TablixRows
        w.writeStartElement("TablixRowHierarchy");
        w.writeStartElement("TablixMembers");

        // Member for header row (static, no group)
        w.writeStartElement("TablixMember");
        el(w, "KeepWithGroup", "After");
        el(w, "RepeatOnNewPage", "true");
        w.writeEndElement();

        // Member(s) for detail row — with or without groups
        List<String> groups = safeList(req.getGroupBy());
        if (!groups.isEmpty()) {
            writeNestedGroups(w, req, groups, 0, reqIdx);
        } else {
            // No groups — simple detail member
            w.writeStartElement("TablixMember");
            w.writeStartElement("Group");
            w.writeAttribute("Name", "Detail_" + reqIdx);
            w.writeEndElement(); // Group
            w.writeEndElement(); // TablixMember
        }

        // Member for subtotal row (static, no group)
        if (hasSub) {
            w.writeStartElement("TablixMember");
            el(w, "KeepWithGroup", "Before");
            w.writeEndElement();
        }

        w.writeEndElement(); // TablixMembers
        w.writeEndElement(); // TablixRowHierarchy

        // Tablix properties
        el(w, "DataSetName", dsName);
        el(w, "Top", fmt(top) + "in");
        el(w, "Left", "0.25in");
        el(w, "Height", fmt(estimateHeight(req)) + "in");
        el(w, "Width", fmt(colW * numCols) + "in");
        el(w, "NoRowsMessage", "No data available");

        w.writeStartElement("Style");
        el(w, "FontFamily", "Segoe UI");
        el(w, "FontSize", "9pt");
        w.writeEndElement(); // Style

        w.writeEndElement(); // Tablix
    }

    // ═══════════════════════════════════════════════════════════════
    // ROW WRITER (guarantees exact cell count)
    // ═══════════════════════════════════════════════════════════════
    @FunctionalInterface
    interface CellWriter {
        void write(int colIndex) throws XMLStreamException;
    }

    private void writeRow(XMLStreamWriter w, String height, int numCols, CellWriter writer) throws XMLStreamException {
        w.writeStartElement("TablixRow");
        el(w, "Height", height);
        w.writeStartElement("TablixCells");
        for (int i = 0; i < numCols; i++) {
            w.writeStartElement("TablixCell");
            w.writeStartElement("CellContents");
            writer.write(i);
            w.writeEndElement(); // CellContents
            w.writeEndElement(); // TablixCell
        }
        w.writeEndElement(); // TablixCells
        w.writeEndElement(); // TablixRow
    }

    // ═══════════════════════════════════════════════════════════════
    // CELL WRITERS (each writes exactly one Textbox)
    // ═══════════════════════════════════════════════════════════════
    private void writeHdrCell(XMLStreamWriter w, AtomicInteger idGen, String label) throws XMLStreamException {
        w.writeStartElement("Textbox");
        w.writeAttribute("Name", "H" + idGen.incrementAndGet());

        w.writeStartElement("Paragraphs");
        w.writeStartElement("Paragraph");
        w.writeStartElement("TextRuns");
        w.writeStartElement("TextRun");
        el(w, "Value", label);
        w.writeStartElement("Style");
        el(w, "FontFamily", "Segoe UI");
        el(w, "FontSize", "9pt");
        el(w, "FontWeight", "Bold");
        el(w, "Color", "White");
        w.writeEndElement(); // Style
        w.writeEndElement(); // TextRun
        w.writeEndElement(); // TextRuns
        w.writeEndElement(); // Paragraph
        w.writeEndElement(); // Paragraphs

        w.writeStartElement("Style");
        el(w, "BackgroundColor", "#4472C4");
        el(w, "PaddingLeft", "4pt");
        el(w, "PaddingRight", "4pt");
        el(w, "PaddingTop", "2pt");
        el(w, "PaddingBottom", "2pt");
        writeBorder(w);
        w.writeEndElement(); // Style

        w.writeEndElement(); // Textbox
    }

    private void writeDataCell(XMLStreamWriter w, AtomicInteger idGen, String expr, boolean numeric) throws XMLStreamException {
        w.writeStartElement("Textbox");
        w.writeAttribute("Name", "D" + idGen.incrementAndGet());

        w.writeStartElement("Paragraphs");
        w.writeStartElement("Paragraph");
        w.writeStartElement("TextRuns");
        w.writeStartElement("TextRun");
        el(w, "Value", expr);
        w.writeStartElement("Style");
        el(w, "FontFamily", "Segoe UI");
        el(w, "FontSize", "8pt");
        if (numeric) el(w, "Format", "#,##0.00");
        w.writeEndElement(); // Style
        w.writeEndElement(); // TextRun
        w.writeEndElement(); // TextRuns
        w.writeStartElement("Style");
        if (numeric) el(w, "TextAlign", "Right");
        w.writeEndElement(); // Style (paragraph)
        w.writeEndElement(); // Paragraph
        w.writeEndElement(); // Paragraphs

        w.writeStartElement("Style");
        el(w, "PaddingLeft", "4pt");
        el(w, "PaddingRight", "4pt");
        el(w, "PaddingTop", "2pt");
        el(w, "PaddingBottom", "2pt");
        writeBorder(w);
        w.writeEndElement(); // Style

        w.writeEndElement(); // Textbox
    }

    private void writeSubCell(XMLStreamWriter w, AtomicInteger idGen, String expr, boolean numeric) throws XMLStreamException {
        w.writeStartElement("Textbox");
        w.writeAttribute("Name", "S" + idGen.incrementAndGet());

        w.writeStartElement("Paragraphs");
        w.writeStartElement("Paragraph");
        w.writeStartElement("TextRuns");
        w.writeStartElement("TextRun");
        el(w, "Value", expr);
        w.writeStartElement("Style");
        el(w, "FontWeight", "Bold");
        el(w, "FontSize", "8pt");
        if (numeric) el(w, "Format", "#,##0.00");
        w.writeEndElement(); // Style
        w.writeEndElement(); // TextRun
        w.writeEndElement(); // TextRuns
        w.writeStartElement("Style");
        if (numeric) el(w, "TextAlign", "Right");
        w.writeEndElement(); // Style (paragraph)
        w.writeEndElement(); // Paragraph
        w.writeEndElement(); // Paragraphs

        w.writeStartElement("Style");
        el(w, "BackgroundColor", "#E2EFDA");
        el(w, "PaddingLeft", "4pt");
        el(w, "PaddingRight", "4pt");
        writeBorder(w);
        w.writeEndElement(); // Style

        w.writeEndElement(); // Textbox
    }

    private void writeTextbox(XMLStreamWriter w, AtomicInteger idGen, String text, String top,
                              String left, String height, String width, String fontSize, boolean bold) throws XMLStreamException {
        w.writeStartElement("Textbox");
        w.writeAttribute("Name", "T" + idGen.incrementAndGet());
        w.writeStartElement("Paragraphs");
        w.writeStartElement("Paragraph");
        w.writeStartElement("TextRuns");
        w.writeStartElement("TextRun");
        el(w, "Value", text);
        w.writeStartElement("Style");
        el(w, "FontFamily", "Segoe UI");
        el(w, "FontSize", fontSize);
        if (bold) el(w, "FontWeight", "Bold");
        w.writeEndElement(); // Style
        w.writeEndElement(); // TextRun
        w.writeEndElement(); // TextRuns
        w.writeEndElement(); // Paragraph
        w.writeEndElement(); // Paragraphs
        el(w, "Top", top);
        el(w, "Left", left);
        el(w, "Height", height);
        el(w, "Width", width);
        w.writeEndElement(); // Textbox
    }

    private void writeBorder(XMLStreamWriter w) throws XMLStreamException {
        w.writeStartElement("Border");
        el(w, "Style", "Solid");
        el(w, "Width", "0.5pt");
        el(w, "Color", "#C0C0C0");
        w.writeEndElement();
    }

    // ═══════════════════════════════════════════════════════════════
    // NESTED ROW GROUPS
    // ═══════════════════════════════════════════════════════════════
    private void writeNestedGroups(XMLStreamWriter w, TableRequest req, List<String> groups,
                                   int depth, int reqIdx) throws XMLStreamException {
        if (depth >= groups.size()) {
            // Leaf: detail row member
            w.writeStartElement("TablixMember");
            w.writeStartElement("Group");
            w.writeAttribute("Name", "Detail_" + reqIdx);
            w.writeEndElement();
            w.writeEndElement();
            return;
        }

        String field = groups.get(depth);
        String safeName = safe(field);
        if (safeName.isEmpty()) safeName = "GRP";

        w.writeStartElement("TablixMember");

        // Group definition (unique name: Grp_reqIdx_fieldName_depth)
        w.writeStartElement("Group");
        w.writeAttribute("Name", "Grp_" + reqIdx + "_" + safeName + "_" + depth);
        w.writeStartElement("GroupExpressions");
        el(w, "GroupExpression", "=Fields!" + safeName + ".Value");
        w.writeEndElement(); // GroupExpressions

        // Page break
        Set<String> pageBreaks = req.getPageBreaks() != null ? req.getPageBreaks() : Collections.emptySet();
        if (pageBreaks.contains(field)) {
            w.writeStartElement("PageBreak");
            el(w, "BreakLocation", "Between");
            w.writeEndElement();
        }

        w.writeEndElement(); // Group

        // Sort
        w.writeStartElement("SortExpressions");
        w.writeStartElement("SortExpression");
        el(w, "Value", "=Fields!" + safeName + ".Value");
        el(w, "Direction", "Ascending");
        w.writeEndElement(); // SortExpression
        w.writeEndElement(); // SortExpressions

        // Recurse into children
        w.writeStartElement("TablixMembers");
        writeNestedGroups(w, req, groups, depth + 1, reqIdx);
        w.writeEndElement(); // TablixMembers

        w.writeEndElement(); // TablixMember
    }

    // ═══════════════════════════════════════════════════════════════
    // MATRIX (ACROSS → Column Group)
    // ═══════════════════════════════════════════════════════════════
    private void writeMatrix(XMLStreamWriter w, TableRequest req, String dsName, int reqIdx,
                             AtomicInteger idGen, double top) throws XMLStreamException {
        String rowField = !safeList(req.getGroupBy()).isEmpty() ? req.getGroupBy().get(0) : "Row";
        String colField = req.getAcrossFields().get(0);
        String safeRow = safe(rowField);
        String safeCol = safe(colField);
        if (safeRow.isEmpty()) safeRow = "ROW";
        if (safeCol.isEmpty()) safeCol = "COL";

        // Find a measure
        RequestField mf = null;
        for (RequestField rf : safeList(req.getFields())) {
            if (rf.getAggregation() != null) { mf = rf; break; }
        }
        if (mf == null && !safeList(req.getFields()).isEmpty()) {
            mf = req.getFields().get(0);
        }
        String measureExpr = mf != null ? "=Sum(Fields!" + safe(safeStr(mf.getName(), "VAL")) + ".Value)" : "=\"\"";
        String measureLabel = mf != null ? safeStr(mf.getAlias(), safeStr(mf.getName(), "Value")) : "Value";

        w.writeStartElement("Tablix");
        w.writeAttribute("Name", "Mtx_" + reqIdx + "_" + safe(dsName));

        // TablixBody: 2 columns, 2 rows
        w.writeStartElement("TablixBody");
        w.writeStartElement("TablixColumns");
        w.writeStartElement("TablixColumn"); el(w, "Width", "2in"); w.writeEndElement();
        w.writeStartElement("TablixColumn"); el(w, "Width", "1.5in"); w.writeEndElement();
        w.writeEndElement(); // TablixColumns

        w.writeStartElement("TablixRows");
        // Header row: exactly 2 cells
        writeRow(w, "0.30in", 2, i -> {
            if (i == 0) writeHdrCell(w, idGen, rowField);
            else writeHdrCell(w, idGen, measureLabel);
        });
        // Data row: exactly 2 cells
        final String fSafeRow = safeRow;
        writeRow(w, "0.25in", 2, i -> {
            if (i == 0) writeDataCell(w, idGen, "=Fields!" + fSafeRow + ".Value", false);
            else writeDataCell(w, idGen, measureExpr, true);
        });
        w.writeEndElement(); // TablixRows
        w.writeEndElement(); // TablixBody

        // Column hierarchy: static + column group
        w.writeStartElement("TablixColumnHierarchy");
        w.writeStartElement("TablixMembers");
        w.writeStartElement("TablixMember"); w.writeEndElement(); // static for row label column
        w.writeStartElement("TablixMember");
        w.writeStartElement("Group");
        w.writeAttribute("Name", "ColGrp_" + reqIdx + "_" + safeCol);
        w.writeStartElement("GroupExpressions");
        el(w, "GroupExpression", "=Fields!" + safeCol + ".Value");
        w.writeEndElement(); // GroupExpressions
        w.writeEndElement(); // Group
        w.writeEndElement(); // TablixMember (column group)
        w.writeEndElement(); // TablixMembers
        w.writeEndElement(); // TablixColumnHierarchy

        // Row hierarchy: static header + row group
        w.writeStartElement("TablixRowHierarchy");
        w.writeStartElement("TablixMembers");
        w.writeStartElement("TablixMember");
        el(w, "KeepWithGroup", "After");
        w.writeEndElement();
        w.writeStartElement("TablixMember");
        w.writeStartElement("Group");
        w.writeAttribute("Name", "RowGrp_" + reqIdx + "_" + safeRow);
        w.writeStartElement("GroupExpressions");
        el(w, "GroupExpression", "=Fields!" + safeRow + ".Value");
        w.writeEndElement(); // GroupExpressions
        w.writeEndElement(); // Group
        w.writeEndElement(); // TablixMember (row group)
        w.writeEndElement(); // TablixMembers
        w.writeEndElement(); // TablixRowHierarchy

        el(w, "DataSetName", dsName);
        el(w, "Top", fmt(top) + "in");
        el(w, "Left", "0.25in");
        el(w, "Height", "2in");
        el(w, "Width", "6in");
        el(w, "NoRowsMessage", "No data available");

        w.writeEndElement(); // Tablix
    }

    // ═══════════════════════════════════════════════════════════════
    // CHART
    // ═══════════════════════════════════════════════════════════════
    private void writeChart(XMLStreamWriter w, TableRequest req, String dsName, int reqIdx,
                            AtomicInteger idGen, double top) throws XMLStreamException {
        String chartType = "Column";
        if (req.getGraphConfig() != null && req.getGraphConfig().getGraphType() != null) {
            chartType = switch (req.getGraphConfig().getGraphType().toUpperCase()) {
                case "PIE" -> "Shape";
                case "LINE" -> "Line";
                case "BAR", "VBAR" -> "Column";
                case "HBAR" -> "Bar";
                case "AREA" -> "Area";
                case "SCATTER", "BUBBLE" -> "Scatter";
                default -> "Column";
            };
        }

        w.writeStartElement("Chart");
        w.writeAttribute("Name", "Cht_" + reqIdx + "_" + safe(dsName));

        // Category hierarchy (X axis)
        w.writeStartElement("ChartCategoryHierarchy");
        w.writeStartElement("ChartMembers");
        w.writeStartElement("ChartMember");
        if (!safeList(req.getGroupBy()).isEmpty()) {
            String catField = safe(req.getGroupBy().get(0));
            w.writeStartElement("Group");
            w.writeAttribute("Name", "ChCat_" + reqIdx);
            w.writeStartElement("GroupExpressions");
            el(w, "GroupExpression", "=Fields!" + catField + ".Value");
            w.writeEndElement();
            w.writeEndElement(); // Group
            el(w, "Label", "=Fields!" + catField + ".Value");
        }
        w.writeEndElement(); // ChartMember
        w.writeEndElement(); // ChartMembers
        w.writeEndElement(); // ChartCategoryHierarchy

        // Series hierarchy
        w.writeStartElement("ChartSeriesHierarchy");
        w.writeStartElement("ChartMembers");
        w.writeStartElement("ChartMember");
        w.writeEndElement();
        w.writeEndElement();
        w.writeEndElement();

        // Chart data — MUST have at least one ChartSeries
        w.writeStartElement("ChartData");
        w.writeStartElement("ChartSeriesCollection");

        boolean hasAnySeries = false;
        for (RequestField rf : safeList(req.getFields())) {
            if (rf.getAggregation() != null) {
                String fieldName = safe(safeStr(rf.getName(), "VAL"));
                w.writeStartElement("ChartSeries");
                w.writeStartElement("ChartDataPoints");
                w.writeStartElement("ChartDataPoint");
                w.writeStartElement("ChartDataPointValues");
                el(w, "Y", "=Sum(Fields!" + fieldName + ".Value)");
                w.writeEndElement();
                w.writeStartElement("ChartDataLabel");
                el(w, "Visible", "false");
                w.writeEndElement();
                w.writeEndElement(); // ChartDataPoint
                w.writeEndElement(); // ChartDataPoints
                el(w, "Type", chartType);
                w.writeEndElement(); // ChartSeries
                hasAnySeries = true;
            }
        }

        // Fallback: if no fields had aggregation, create a dummy series
        if (!hasAnySeries) {
            String fallbackField = !safeList(req.getFields()).isEmpty()
                ? safe(safeStr(req.getFields().get(0).getName(), "VAL"))
                : "VALUE";
            w.writeStartElement("ChartSeries");
            w.writeStartElement("ChartDataPoints");
            w.writeStartElement("ChartDataPoint");
            w.writeStartElement("ChartDataPointValues");
            el(w, "Y", "=Count(Fields!" + fallbackField + ".Value)");
            w.writeEndElement();
            w.writeStartElement("ChartDataLabel");
            el(w, "Visible", "false");
            w.writeEndElement();
            w.writeEndElement();
            w.writeEndElement();
            el(w, "Type", chartType);
            w.writeEndElement();
        }

        w.writeEndElement(); // ChartSeriesCollection
        w.writeEndElement(); // ChartData

        // Chart areas
        w.writeStartElement("ChartAreas");
        w.writeStartElement("ChartArea");
        w.writeAttribute("Name", "Default");
        w.writeEndElement();
        w.writeEndElement();

        // Legend
        w.writeStartElement("ChartLegends");
        w.writeStartElement("ChartLegend");
        w.writeAttribute("Name", "Default");
        w.writeStartElement("Style");
        w.writeEndElement();
        w.writeEndElement();
        w.writeEndElement();

        el(w, "DataSetName", dsName);
        el(w, "Top", fmt(top) + "in");
        el(w, "Left", "0.25in");
        el(w, "Height", "3.5in");
        el(w, "Width", "8in");

        w.writeEndElement(); // Chart
    }

    // ═══════════════════════════════════════════════════════════════
    // PAGE HEADER
    // ═══════════════════════════════════════════════════════════════
    private void writePageHeader(XMLStreamWriter w, ParsedFexFile fex, AtomicInteger idGen) throws XMLStreamException {
        List<String> headings = new ArrayList<>();
        for (TableRequest r : safeList(fex.getRequests())) {
            headings.addAll(safeList(r.getHeadings()));
        }
        if (headings.isEmpty()) return;

        w.writeStartElement("PageHeader");
        el(w, "Height", "0.5in");
        el(w, "PrintOnFirstPage", "true");
        el(w, "PrintOnLastPage", "true");
        w.writeStartElement("ReportItems");
        writeTextbox(w, idGen, cleanHeading(headings.get(0)),
            "0in", "0in", "0.4in", "9.5in", "14pt", true);
        w.writeEndElement(); // ReportItems
        w.writeEndElement(); // PageHeader
    }

    // ═══════════════════════════════════════════════════════════════
    // PAGE FOOTER
    // ═══════════════════════════════════════════════════════════════
    private void writePageFooter(XMLStreamWriter w, AtomicInteger idGen) throws XMLStreamException {
        w.writeStartElement("PageFooter");
        el(w, "Height", "0.35in");
        el(w, "PrintOnFirstPage", "true");
        el(w, "PrintOnLastPage", "true");

        w.writeStartElement("ReportItems");

        // Date textbox
        w.writeStartElement("Textbox");
        w.writeAttribute("Name", "FtrDt_" + idGen.incrementAndGet());
        w.writeStartElement("Paragraphs");
        w.writeStartElement("Paragraph");
        w.writeStartElement("TextRuns");
        w.writeStartElement("TextRun");
        el(w, "Value", "=\"Generated: \" & Format(Now(), \"yyyy-MM-dd HH:mm\")");
        w.writeStartElement("Style");
        el(w, "FontSize", "8pt");
        el(w, "Color", "#999999");
        w.writeEndElement();
        w.writeEndElement(); // TextRun
        w.writeEndElement(); // TextRuns
        w.writeEndElement(); // Paragraph
        w.writeEndElement(); // Paragraphs
        el(w, "Top", "0in");
        el(w, "Left", "0in");
        el(w, "Height", "0.25in");
        el(w, "Width", "4in");
        w.writeEndElement(); // Textbox

        // Page number textbox
        w.writeStartElement("Textbox");
        w.writeAttribute("Name", "FtrPg_" + idGen.incrementAndGet());
        w.writeStartElement("Paragraphs");
        w.writeStartElement("Paragraph");
        w.writeStartElement("TextRuns");
        w.writeStartElement("TextRun");
        el(w, "Value", "=\"Page \" & Globals!PageNumber & \" of \" & Globals!TotalPages");
        w.writeStartElement("Style");
        el(w, "FontSize", "8pt");
        el(w, "Color", "#999999");
        w.writeEndElement();
        w.writeEndElement(); // TextRun
        w.writeEndElement(); // TextRuns
        w.writeStartElement("Style");
        el(w, "TextAlign", "Right");
        w.writeEndElement();
        w.writeEndElement(); // Paragraph
        w.writeEndElement(); // Paragraphs
        el(w, "Top", "0in");
        el(w, "Left", "5.5in");
        el(w, "Height", "0.25in");
        el(w, "Width", "4in");
        w.writeEndElement(); // Textbox

        w.writeEndElement(); // ReportItems
        w.writeEndElement(); // PageFooter
    }

    // ═══════════════════════════════════════════════════════════════
    // PAGE SETUP
    // ═══════════════════════════════════════════════════════════════
    private void writePage(XMLStreamWriter w) throws XMLStreamException {
        w.writeStartElement("Page");
        el(w, "PageHeight", "11in");
        el(w, "PageWidth", "8.5in");
        el(w, "LeftMargin", "0.5in");
        el(w, "RightMargin", "0.5in");
        el(w, "TopMargin", "0.5in");
        el(w, "BottomMargin", "0.5in");
        w.writeStartElement("Style");
        w.writeEndElement();
        w.writeEndElement(); // Page
    }

    // ═══════════════════════════════════════════════════════════════
    // SQL GENERATION
    // ═══════════════════════════════════════════════════════════════
    private String buildSql(TableRequest req) {
        StringBuilder sql = new StringBuilder("SELECT ");
        List<String> cols = new ArrayList<>();
        for (String g : safeList(req.getGroupBy())) cols.add(g);
        for (String a : safeList(req.getAcrossFields())) { if (!cols.contains(a)) cols.add(a); }
        for (RequestField rf : safeList(req.getFields())) {
            String name = safeStr(rf.getName(), "FIELD");
            if (!cols.contains(name)) cols.add(name);
        }
        for (ComputeField cf : safeList(req.getComputes())) {
            String name = safeStr(cf.getField(), "COMPUTE");
            if (!cols.contains(name)) cols.add(name);
        }
        if (cols.isEmpty()) cols.add("*");

        sql.append(String.join(", ", cols));
        sql.append("\nFROM dbo.").append(safeStr(req.getFile(), "TABLE_NAME"));

        List<String> wheres = new ArrayList<>();
        for (FilterSpec f : safeList(req.getFilters())) {
            String expr = f.getExpression();
            if (expr == null || expr.isBlank()) continue;
            expr = expr.replaceAll("(?i)^(WHERE|IF)\\s+", "").trim()
                .replaceAll("(?i)\\bEQ\\b", "=").replaceAll("(?i)\\bNE\\b", "<>")
                .replaceAll("(?i)\\bGT\\b", ">").replaceAll("(?i)\\bLT\\b", "<")
                .replaceAll("(?i)\\bGE\\b", ">=").replaceAll("(?i)\\bLE\\b", "<=")
                .replaceAll("&(\\w+)", "@$1");
            if (!expr.isEmpty()) wheres.add(expr);
        }
        if (!wheres.isEmpty()) {
            sql.append("\nWHERE ").append(String.join("\n  AND ", wheres));
        }

        return sql.toString();
    }

    // ═══════════════════════════════════════════════════════════════
    // UTILITIES
    // ═══════════════════════════════════════════════════════════════
    private void el(XMLStreamWriter w, String name, String value) throws XMLStreamException {
        w.writeStartElement(name);
        w.writeCharacters(value);
        w.writeEndElement();
    }

    /** Sanitize a name for use in RDL Name attributes (alphanumeric + underscore only) */
    private String safe(String name) {
        if (name == null) return "UNNAMED";
        String result = name.replaceAll("[^a-zA-Z0-9_]", "_");
        // XML names cannot start with a digit
        if (!result.isEmpty() && Character.isDigit(result.charAt(0))) result = "F_" + result;
        return result.isEmpty() ? "UNNAMED" : result;
    }

    /** Return value if non-null and non-empty, otherwise return fallback */
    private String safeStr(String value, String fallback) {
        return (value != null && !value.isBlank()) ? value : fallback;
    }

    /** Return list if non-null, otherwise empty list */
    @SuppressWarnings("unchecked")
    private <T> List<T> safeList(List<T> list) {
        return list != null ? list : Collections.emptyList();
    }

    /** Format double with US locale (dot separator, never comma) */
    private String fmt(double value) {
        return String.format(java.util.Locale.US, "%.2f", value);
    }

    private String mapAgg(String agg) {
        if (agg == null) return "First";
        return switch (agg.toUpperCase()) {
            case "SUM" -> "Sum";
            case "COUNT", "CNT" -> "Count";
            case "AVG" -> "Avg";
            case "MIN" -> "Min";
            case "MAX" -> "Max";
            case "FIRST" -> "First";
            case "LAST" -> "Last";
            default -> "Sum";
        };
    }

    private String mapParamType(String type) {
        if (type == null) return "String";
        return switch (type.toUpperCase()) {
            case "INTEGER", "I", "INT" -> "Integer";
            case "FLOAT", "DOUBLE", "D", "P" -> "Float";
            case "DATE", "YYMD" -> "DateTime";
            default -> "String";
        };
    }

    private String guessType(String fieldName, ParsedFexFile fex) {
        for (DefineField d : safeList(fex.getDefines())) {
            if (d.getField() != null && d.getField().equalsIgnoreCase(fieldName) && d.getFormat() != null) {
                if (d.getFormat().startsWith("A")) return "System.String";
                if (d.getFormat().startsWith("I")) return "System.Int32";
                if (d.getFormat().startsWith("D") || d.getFormat().startsWith("P")) return "System.Decimal";
            }
        }
        return "System.String";
    }

    private String cleanHeading(String heading) {
        if (heading == null) return "Report";
        String cleaned = heading.replaceAll("^[\"']|[\"']$", "")
            .replaceAll("&\\w+", "").replaceAll("<[^>]+>", "").trim();
        return cleaned.isEmpty() ? "Report" : cleaned;
    }

    private double calcHeight(List<TableRequest> requests) {
        double h = 0;
        for (TableRequest r : requests) {
            String type = safeStr(r.getType(), "TABLE");
            h += "GRAPH".equals(type) ? 4.0 : estimateHeight(r);
        }
        return h;
    }

    private double estimateHeight(TableRequest req) {
        int rows = 2; // header + detail
        rows += safeList(req.getGroupBy()).size();
        if (req.isSubTotals() && !safeList(req.getGroupBy()).isEmpty()) rows++;
        return Math.max(0.3 * rows + 0.5, 1.5);
    }
}
