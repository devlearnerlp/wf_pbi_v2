package com.migration.controller;

import com.migration.export.RdlGenerator;
import com.migration.model.*;
import com.migration.parser.FexParser;
import com.migration.service.MigrationService;
import org.slf4j.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;

@RestController
@RequestMapping("/api/migration")
@CrossOrigin(origins = "*")
public class MigrationController {
    private static final Logger log = LoggerFactory.getLogger(MigrationController.class);
    private final MigrationService service;
    private final RdlGenerator rdlGenerator;
    private final FexParser fexParser;

    public MigrationController(MigrationService service, RdlGenerator rdlGenerator, FexParser fexParser) {
        this.service = service; this.rdlGenerator = rdlGenerator; this.fexParser = fexParser;
    }

    @PostMapping("/analyze")
    public ResponseEntity<MigrationResponse> analyze(@RequestParam("files") List<MultipartFile> files) {
        if (files == null || files.isEmpty()) {
            MigrationResponse err = new MigrationResponse(); err.setStatus("error");
            err.getErrors().add("No files provided"); return ResponseEntity.badRequest().body(err);
        }
        log.info("Analysis: {} files", files.size());
        MigrationResponse response = service.processMigration(files);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/generate-rdl")
    public ResponseEntity<byte[]> generateRdlBundle(@RequestParam("files") List<MultipartFile> files) {
        if (files == null || files.isEmpty()) return ResponseEntity.badRequest().build();
        log.info("RDL batch: {} files", files.size());
        try {
            ByteArrayOutputStream zipBaos = new ByteArrayOutputStream();
            ZipOutputStream zipOut = new ZipOutputStream(zipBaos);
            List<String> manifest = new ArrayList<>(List.of(
                "WEBFOCUS → POWER BI RDL MIGRATION BUNDLE", "═".repeat(50),
                "Generated: " + java.time.LocalDateTime.now(), ""));
            int generated = 0, skipped = 0;

            for (MultipartFile file : files) {
                String name = file.getOriginalFilename() != null ? file.getOriginalFilename() : "unknown.fex";
                String ext = name.substring(name.lastIndexOf('.') + 1).toLowerCase();
                if ("mas".equals(ext)) { manifest.add("SKIP  " + name + " (Master File)"); skipped++; continue; }
                try {
                    String content = new String(file.getBytes(), StandardCharsets.UTF_8);
                    ParsedFexFile parsed = fexParser.parse(content, name);
                    if (parsed.getRequests().isEmpty()) { manifest.add("SKIP  " + name + " (No requests)"); skipped++; continue; }
                    ConversionResult conv = service.convertSingleFex(parsed);
                    byte[] rdl = rdlGenerator.generateRdl(parsed, conv);
                    String folder = classifyFolder(parsed);
                    String rdlName = name.replaceAll("\\.[^.]+$", "") + ".rdl";
                    String entryPath = folder + "/" + rdlName;
                    zipOut.putNextEntry(new ZipEntry(entryPath)); zipOut.write(rdl); zipOut.closeEntry();
                    manifest.add("OK    " + entryPath + " (" + conv.getConfidence() + "% confidence, " + parsed.getRequests().size() + " requests)");
                    generated++;
                } catch (Exception e) { manifest.add("ERROR " + name + " — " + e.getMessage()); log.error("RDL gen failed: {}", name, e); }
            }
            manifest.addAll(List.of("", "TOTAL: " + generated + " generated, " + skipped + " skipped", "",
                "NEXT STEPS:", "1. Extract this ZIP",
                "2. Open each .rdl in Power BI Report Builder",
                "3. Update data source connection (right-click DataSource → Properties)",
                "4. Preview report (Run button)", "5. Publish to Report Server (File → Save As → Report Server)"));
            zipOut.putNextEntry(new ZipEntry("_MIGRATION_MANIFEST.txt"));
            zipOut.write(String.join("\n", manifest).getBytes(StandardCharsets.UTF_8)); zipOut.closeEntry();
            zipOut.close();

            HttpHeaders h = new HttpHeaders(); h.setContentType(MediaType.APPLICATION_OCTET_STREAM);
            h.setContentDisposition(ContentDisposition.attachment().filename("webfocus_rdl_bundle.zip").build());
            return ResponseEntity.ok().headers(h).body(zipBaos.toByteArray());
        } catch (IOException e) { log.error("ZIP creation failed", e); return ResponseEntity.internalServerError().build(); }
    }

    @PostMapping("/generate-rdl-single")
    public ResponseEntity<byte[]> generateSingleRdl(@RequestParam("file") MultipartFile file) {
        try {
            String content = new String(file.getBytes(), StandardCharsets.UTF_8);
            String name = file.getOriginalFilename() != null ? file.getOriginalFilename() : "report.fex";
            ParsedFexFile parsed = fexParser.parse(content, name);
            if (parsed.getRequests().isEmpty()) return ResponseEntity.badRequest().build();
            ConversionResult conv = service.convertSingleFex(parsed);
            byte[] rdl = rdlGenerator.generateRdl(parsed, conv);
            HttpHeaders h = new HttpHeaders(); h.setContentType(MediaType.APPLICATION_XML);
            h.setContentDisposition(ContentDisposition.attachment().filename(name.replaceAll("\\.[^.]+$", "") + ".rdl").build());
            return ResponseEntity.ok().headers(h).body(rdl);
        } catch (Exception e) { log.error("Single RDL failed", e); return ResponseEntity.internalServerError().build(); }
    }

    @PostMapping("/export/dax")
    public ResponseEntity<byte[]> exportDAX(@RequestBody List<ConversionResult> c) { return dl(service.generateDAXScript(c), "migration_dax.dax"); }
    @PostMapping("/export/m")
    public ResponseEntity<byte[]> exportM(@RequestBody List<ConversionResult> c) { return dl(service.generateMQueryScript(c), "migration_m_queries.pq"); }
    @PostMapping("/export/report")
    public ResponseEntity<byte[]> exportReport(@RequestBody MigrationResponse r) { return dl(service.generateReport(r.getParsedFiles(), r.getConversions()), "migration_report.txt"); }

    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> health() {
        return ResponseEntity.ok(Map.of("status", "UP", "version", "3.0.0", "rdlGeneration", true, "batchSupport", true, "target", "Power BI Report Server (On-Prem)"));
    }

    private String classifyFolder(ParsedFexFile fex) {
        var c = fex.getClassification();
        if (c.isPaginatedReport()) return "paginated";
        if (c.isSelfServiceReport()) return "self-service";
        if (c.isActiveReport()) return "active-reports";
        if (c.isDashboard()) return "dashboards";
        if (c.isEtlProcedure()) return "etl";
        return "standard";
    }

    private ResponseEntity<byte[]> dl(String content, String filename) {
        HttpHeaders h = new HttpHeaders(); h.setContentType(MediaType.TEXT_PLAIN);
        h.setContentDisposition(ContentDisposition.attachment().filename(filename).build());
        return ResponseEntity.ok().headers(h).body(content.getBytes(StandardCharsets.UTF_8));
    }
}
