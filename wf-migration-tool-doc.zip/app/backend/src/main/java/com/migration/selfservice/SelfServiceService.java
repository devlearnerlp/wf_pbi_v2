package com.migration.selfservice;

import com.migration.selfservice.SelfServiceModels.*;
import com.migration.model.ParsedMasterFile;
import com.migration.parser.MasterFileParser;
import org.slf4j.*;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class SelfServiceService {
    private static final Logger log = LoggerFactory.getLogger(SelfServiceService.class);

    private final DynamicRdlGenerator rdlGenerator;
    private final ReportRenderer reportRenderer;
    private final MasterFileParser masterParser;

    private final Map<String, TableMeta> fieldCatalog = new ConcurrentHashMap<>();
    private final Map<String, SavedReport> savedReports = new ConcurrentHashMap<>();

    public SelfServiceService(DynamicRdlGenerator rdlGenerator, ReportRenderer reportRenderer, MasterFileParser masterParser) {
        this.rdlGenerator = rdlGenerator;
        this.reportRenderer = reportRenderer;
        this.masterParser = masterParser;
        initDefaultCatalog();
    }

    // ═══ Catalog ═════════════════════════════════════════════════
    public DataSourceCatalog getCatalog() {
        DataSourceCatalog c = new DataSourceCatalog();
        c.getTables().addAll(fieldCatalog.values());
        return c;
    }

    public TableMeta importFromMasterFile(String content, String fileName) {
        ParsedMasterFile mas = masterParser.parse(content, fileName);
        String tableName = mas.getAccessFile() != null ? mas.getAccessFile() : fileName.replaceAll("(?i)\\.mas$", "");
        TableMeta table = new TableMeta(tableName, tableName);
        for (ParsedMasterFile.MasterField mf : mas.getFields()) {
            String dt = mapType(mf.getDataType(), mf.getFormat());
            String usage = isNumeric(dt) ? "measure" : "dimension";
            table.getFields().add(new FieldMeta(mf.getName(), mf.getTitle() != null ? mf.getTitle() : mf.getName(), dt, usage));
        }
        fieldCatalog.put(tableName, table);
        log.info("Imported {} fields from {} as '{}'", table.getFields().size(), fileName, tableName);
        return table;
    }

    public TableMeta addTable(TableMeta table) { fieldCatalog.put(table.getName(), table); return table; }
    public boolean removeTable(String name) { return fieldCatalog.remove(name) != null; }

    // ═══ RDL Generation (for developers) ═════════════════════════
    public byte[] generateRdl(ReportDefinition def) {
        validate(def);
        return rdlGenerator.generate(def);
    }

    // ═══ Report Rendering (for end users) ════════════════════════
    public ReportRenderer.RenderResult renderReport(ReportDefinition def, String format) {
        validate(def);
        log.info("Rendering report: table={}, measures={}, format={}", def.getDataSource(), def.getMeasures().size(), format);
        return reportRenderer.renderReport(def, format);
    }

    public Map<String, Object> getRenderCapabilities() {
        Map<String, Object> caps = new LinkedHashMap<>();
        caps.put("reportServerConfigured", reportRenderer.isReportServerConfigured());
        caps.put("databaseConfigured", reportRenderer.isDatabaseConfigured());
        caps.put("availableFormats", reportRenderer.isReportServerConfigured()
            ? List.of("HTML5", "PDF", "EXCELOPENXML", "CSV")
            : List.of("HTML5"));
        caps.put("renderMode", reportRenderer.isReportServerConfigured() ? "ReportServer"
            : reportRenderer.isDatabaseConfigured() ? "Standalone" : "Preview");
        return caps;
    }

    // ═══ Saved Reports CRUD ══════════════════════════════════════
    public SavedReport saveReport(SaveReportRequest request) {
        validate(request.getDefinition());
        SavedReport sr = new SavedReport();
        sr.setId(UUID.randomUUID().toString().substring(0, 8));
        sr.setName(request.getName());
        sr.setCreatedBy("user");
        sr.setCreatedAt(LocalDateTime.now());
        sr.setUpdatedAt(LocalDateTime.now());
        sr.setDefinition(request.getDefinition());
        savedReports.put(sr.getId(), sr);
        log.info("Saved report '{}' (id={})", sr.getName(), sr.getId());
        return sr;
    }

    public SavedReport updateReport(String id, SaveReportRequest request) {
        SavedReport sr = savedReports.get(id);
        if (sr == null) throw new IllegalArgumentException("Report not found: " + id);
        validate(request.getDefinition());
        sr.setName(request.getName());
        sr.setDefinition(request.getDefinition());
        sr.setUpdatedAt(LocalDateTime.now());
        log.info("Updated report '{}' (id={})", sr.getName(), id);
        return sr;
    }

    public List<SavedReport> listSavedReports() {
        List<SavedReport> list = new ArrayList<>(savedReports.values());
        list.sort((a, b) -> b.getUpdatedAt().compareTo(a.getUpdatedAt()));
        return list;
    }

    public SavedReport getSavedReport(String id) {
        SavedReport sr = savedReports.get(id);
        if (sr == null) throw new IllegalArgumentException("Report not found: " + id);
        return sr;
    }

    public boolean deleteSavedReport(String id) { return savedReports.remove(id) != null; }

    public byte[] runSavedReportRdl(String id) {
        SavedReport sr = getSavedReport(id);
        sr.setLastRunAt(LocalDateTime.now());
        return generateRdl(sr.getDefinition());
    }

    public ReportRenderer.RenderResult runSavedReportRendered(String id, String format) {
        SavedReport sr = getSavedReport(id);
        sr.setLastRunAt(LocalDateTime.now());
        return renderReport(sr.getDefinition(), format);
    }

    // ═══ Helpers ═════════════════════════════════════════════════
    private void validate(ReportDefinition def) {
        if (def.getDataSource() == null || def.getDataSource().isBlank())
            throw new IllegalArgumentException("Data source (table) is required");
        if (def.getMeasures().isEmpty() && def.getGroupBy().isEmpty())
            throw new IllegalArgumentException("At least one measure or group-by field required");
        for (MeasureField m : def.getMeasures()) {
            if (m.getField() == null || m.getField().isBlank()) throw new IllegalArgumentException("Measure field name required");
            if (m.getAggregation() == null || m.getAggregation().isBlank()) m.setAggregation("SUM");
        }
    }

    private String mapType(String dt, String fmt) {
        if (dt != null) return switch (dt) { case "ALPHANUMERIC" -> "String"; case "INTEGER" -> "Integer"; case "PACKED", "DOUBLE" -> "Decimal"; default -> "String"; };
        if (fmt != null) { if (fmt.startsWith("A")) return "String"; if (fmt.startsWith("I")) return "Integer"; if (fmt.startsWith("D") || fmt.startsWith("P")) return "Decimal"; }
        return "String";
    }

    private boolean isNumeric(String type) { return "Integer".equals(type) || "Decimal".equals(type); }

    private void initDefaultCatalog() {
        TableMeta sales = new TableMeta("STORE_SALES", "Store Sales");
        sales.getFields().addAll(List.of(
            new FieldMeta("REVENUE", "Revenue", "Decimal", "measure"),
            new FieldMeta("COST_OF_GOODS", "Cost of Goods", "Decimal", "measure"),
            new FieldMeta("OPERATING_EXPENSES", "Operating Expenses", "Decimal", "measure"),
            new FieldMeta("TAX_AMOUNT", "Tax Amount", "Decimal", "measure"),
            new FieldMeta("TRANSACTION_COUNT", "Transactions", "Integer", "measure"),
            new FieldMeta("STOCK_ON_HAND", "Stock On Hand", "Integer", "measure"),
            new FieldMeta("PREV_YEAR_REV", "Prior Year Revenue", "Decimal", "measure"),
            new FieldMeta("REGION_NAME", "Region", "String", "dimension"),
            new FieldMeta("STORE_NAME", "Store Name", "String", "dimension"),
            new FieldMeta("STORE_CITY", "City", "String", "dimension"),
            new FieldMeta("STORE_STATE", "State", "String", "dimension"),
            new FieldMeta("PRODUCT_CATEGORY", "Product Category", "String", "dimension"),
            new FieldMeta("PRODUCT_SKU", "Product SKU", "String", "dimension"),
            new FieldMeta("FISCAL_YEAR", "Fiscal Year", "Integer", "filter"),
            new FieldMeta("FISCAL_QUARTER", "Quarter", "Integer", "filter"),
            new FieldMeta("FISCAL_MONTH", "Month", "Integer", "filter")
        ));
        fieldCatalog.put("STORE_SALES", sales);

        TableMeta emp = new TableMeta("EMPLOYEE", "Employee");
        emp.getFields().addAll(List.of(
            new FieldMeta("SALARY", "Salary", "Decimal", "measure"),
            new FieldMeta("EMP_ID", "Employee ID", "Integer", "dimension"),
            new FieldMeta("FIRST_NAME", "First Name", "String", "dimension"),
            new FieldMeta("LAST_NAME", "Last Name", "String", "dimension"),
            new FieldMeta("DEPT_NAME", "Department", "String", "dimension"),
            new FieldMeta("JOB_TITLE", "Job Title", "String", "dimension"),
            new FieldMeta("LOCATION", "Location", "String", "dimension"),
            new FieldMeta("STATUS", "Status", "String", "filter")
        ));
        fieldCatalog.put("EMPLOYEE", emp);
        log.info("Initialized catalog with {} tables", fieldCatalog.size());
    }
}
