package com.migration.selfservice;

import com.migration.selfservice.SelfServiceModels.*;
import org.slf4j.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.nio.charset.StandardCharsets;
import java.util.*;

@RestController
@RequestMapping("/api/self-service")
@CrossOrigin(origins = "*")
public class SelfServiceController {
    private static final Logger log = LoggerFactory.getLogger(SelfServiceController.class);
    private final SelfServiceService service;

    public SelfServiceController(SelfServiceService service) { this.service = service; }

    // ═══ Catalog ═════════════════════════════════════════════════
    @GetMapping("/catalog")
    public ResponseEntity<DataSourceCatalog> getCatalog() { return ResponseEntity.ok(service.getCatalog()); }

    @PostMapping("/catalog/import")
    public ResponseEntity<TableMeta> importMas(@RequestParam("file") MultipartFile file) {
        try {
            return ResponseEntity.ok(service.importFromMasterFile(new String(file.getBytes(), StandardCharsets.UTF_8), file.getOriginalFilename()));
        } catch (Exception e) { return ResponseEntity.badRequest().build(); }
    }

    // ═══ Render Capabilities ═════════════════════════════════════
    @GetMapping("/capabilities")
    public ResponseEntity<Map<String, Object>> capabilities() {
        return ResponseEntity.ok(service.getRenderCapabilities());
    }

    // ═══ Generate RDL (for developers) ═══════════════════════════
    @PostMapping("/generate-rdl")
    public ResponseEntity<byte[]> generateRdl(@RequestBody ReportDefinition def) {
        try {
            byte[] rdl = service.generateRdl(def);
            String name = (def.getTitle() != null ? def.getTitle() : "report").replaceAll("[^a-zA-Z0-9_\\- ]", "").replaceAll("\\s+", "_");
            HttpHeaders h = new HttpHeaders();
            h.setContentType(MediaType.APPLICATION_XML);
            h.setContentDisposition(ContentDisposition.attachment().filename(name + ".rdl").build());
            return ResponseEntity.ok().headers(h).body(rdl);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage().getBytes());
        }
    }

    // ═══ Generate Report (for end users — returns rendered output) ═══
    @PostMapping("/generate-report")
    public ResponseEntity<byte[]> generateReport(
            @RequestBody ReportDefinition def,
            @RequestParam(defaultValue = "HTML5") String format) {
        try {
            ReportRenderer.RenderResult result = service.renderReport(def, format);
            MediaType contentType = mapContentType(result.getFormat());
            HttpHeaders h = new HttpHeaders();
            h.setContentType(contentType);
            h.set("X-Render-Mode", result.getRenderMode());

            // For downloadable formats, set filename
            if (Set.of("PDF", "EXCELOPENXML", "CSV").contains(format.toUpperCase())) {
                String name = (def.getTitle() != null ? def.getTitle() : "report").replaceAll("[^a-zA-Z0-9_\\- ]", "").replaceAll("\\s+", "_");
                String ext = switch (format.toUpperCase()) { case "PDF" -> ".pdf"; case "EXCELOPENXML" -> ".xlsx"; case "CSV" -> ".csv"; default -> ".html"; };
                h.setContentDisposition(ContentDisposition.attachment().filename(name + ext).build());
            }

            return ResponseEntity.ok().headers(h).body(result.getData());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage().getBytes());
        } catch (Exception e) {
            log.error("Report rendering failed", e);
            return ResponseEntity.internalServerError().body(("Rendering failed: " + e.getMessage()).getBytes());
        }
    }

    // ═══ Preview (returns JSON with SQL + RDL XML) ═══════════════
    @PostMapping("/preview")
    public ResponseEntity<Map<String, Object>> preview(@RequestBody ReportDefinition def) {
        try {
            byte[] rdl = service.generateRdl(def);
            String xml = new String(rdl, StandardCharsets.UTF_8);
            Map<String, Object> resp = new LinkedHashMap<>();
            resp.put("status", "success");
            resp.put("rdlXml", xml);
            resp.put("rdlSizeBytes", rdl.length);
            resp.put("sql", extractSql(xml));
            resp.put("capabilities", service.getRenderCapabilities());
            return ResponseEntity.ok(resp);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("status", "error", "message", e.getMessage()));
        }
    }

    // ═══ Save / Update / List / Get / Delete / Run ═══════════════
    @PostMapping("/reports/save")
    public ResponseEntity<SavedReport> save(@RequestBody SaveReportRequest req) {
        try { return ResponseEntity.ok(service.saveReport(req)); }
        catch (Exception e) { return ResponseEntity.badRequest().build(); }
    }

    @PutMapping("/reports/{id}")
    public ResponseEntity<SavedReport> update(@PathVariable String id, @RequestBody SaveReportRequest req) {
        try { return ResponseEntity.ok(service.updateReport(id, req)); }
        catch (IllegalArgumentException e) { return ResponseEntity.notFound().build(); }
    }

    @GetMapping("/reports")
    public ResponseEntity<List<SavedReport>> list() { return ResponseEntity.ok(service.listSavedReports()); }

    @GetMapping("/reports/{id}")
    public ResponseEntity<SavedReport> get(@PathVariable String id) {
        try { return ResponseEntity.ok(service.getSavedReport(id)); }
        catch (IllegalArgumentException e) { return ResponseEntity.notFound().build(); }
    }

    @DeleteMapping("/reports/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id) { service.deleteSavedReport(id); return ResponseEntity.ok().build(); }

    @GetMapping("/reports/{id}/rdl")
    public ResponseEntity<byte[]> runRdl(@PathVariable String id) {
        try {
            byte[] rdl = service.runSavedReportRdl(id);
            SavedReport sr = service.getSavedReport(id);
            HttpHeaders h = new HttpHeaders();
            h.setContentType(MediaType.APPLICATION_XML);
            h.setContentDisposition(ContentDisposition.attachment().filename(sr.getName().replaceAll("\\s+", "_") + ".rdl").build());
            return ResponseEntity.ok().headers(h).body(rdl);
        } catch (IllegalArgumentException e) { return ResponseEntity.notFound().build(); }
    }

    @GetMapping("/reports/{id}/render")
    public ResponseEntity<byte[]> runRendered(@PathVariable String id, @RequestParam(defaultValue = "HTML5") String format) {
        try {
            ReportRenderer.RenderResult result = service.runSavedReportRendered(id, format);
            HttpHeaders h = new HttpHeaders();
            h.setContentType(mapContentType(result.getFormat()));
            h.set("X-Render-Mode", result.getRenderMode());
            if (Set.of("PDF", "EXCELOPENXML", "CSV").contains(format.toUpperCase())) {
                SavedReport sr = service.getSavedReport(id);
                String ext = switch (format.toUpperCase()) { case "PDF" -> ".pdf"; case "EXCELOPENXML" -> ".xlsx"; case "CSV" -> ".csv"; default -> ".html"; };
                h.setContentDisposition(ContentDisposition.attachment().filename(sr.getName().replaceAll("\\s+", "_") + ext).build());
            }
            return ResponseEntity.ok().headers(h).body(result.getData());
        } catch (IllegalArgumentException e) { return ResponseEntity.notFound().build(); }
    }

    // ═══ Helpers ═════════════════════════════════════════════════
    private MediaType mapContentType(String format) {
        return switch (format.toUpperCase()) {
            case "PDF" -> MediaType.APPLICATION_PDF;
            case "EXCELOPENXML" -> MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            case "CSV" -> MediaType.parseMediaType("text/csv");
            default -> MediaType.TEXT_HTML;
        };
    }

    private String extractSql(String xml) {
        int a = xml.indexOf("<CommandText>"), b = xml.indexOf("</CommandText>");
        return (a >= 0 && b > a) ? xml.substring(a + 13, b).trim() : "";
    }
}
