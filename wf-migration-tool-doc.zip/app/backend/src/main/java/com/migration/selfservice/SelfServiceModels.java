package com.migration.selfservice;

import java.time.LocalDateTime;
import java.util.*;

/**
 * Models for the Self-Service Report Builder.
 * These represent the JSON structures exchanged between the React UI and Java backend.
 */
public class SelfServiceModels {

    /**
     * A user-designed report definition — the JSON payload from the UI.
     */
    public static class ReportDefinition {
        private String title = "Untitled Report";
        private String dataSource;               // table name
        private List<MeasureField> measures = new ArrayList<>();
        private List<String> groupBy = new ArrayList<>();
        private List<String> columns = new ArrayList<>();  // ACROSS equivalent
        private List<FilterCondition> filters = new ArrayList<>();
        private ReportOptions options = new ReportOptions();

        public String getTitle() { return title; }
        public void setTitle(String t) { this.title = t; }
        public String getDataSource() { return dataSource; }
        public void setDataSource(String d) { this.dataSource = d; }
        public List<MeasureField> getMeasures() { return measures; }
        public void setMeasures(List<MeasureField> m) { this.measures = m; }
        public List<String> getGroupBy() { return groupBy; }
        public void setGroupBy(List<String> g) { this.groupBy = g; }
        public List<String> getColumns() { return columns; }
        public void setColumns(List<String> c) { this.columns = c; }
        public List<FilterCondition> getFilters() { return filters; }
        public void setFilters(List<FilterCondition> f) { this.filters = f; }
        public ReportOptions getOptions() { return options; }
        public void setOptions(ReportOptions o) { this.options = o; }
    }

    public static class MeasureField {
        private String field;
        private String aggregation = "SUM";  // SUM, COUNT, AVG, MIN, MAX
        private String alias;

        public MeasureField() {}
        public MeasureField(String field, String aggregation, String alias) {
            this.field = field; this.aggregation = aggregation; this.alias = alias;
        }
        public String getField() { return field; }
        public void setField(String f) { this.field = f; }
        public String getAggregation() { return aggregation; }
        public void setAggregation(String a) { this.aggregation = a; }
        public String getAlias() { return alias; }
        public void setAlias(String a) { this.alias = a; }
    }

    public static class FilterCondition {
        private String field;
        private String operator = "=";   // =, <>, >, <, >=, <=, LIKE, IN
        private String value;

        public FilterCondition() {}
        public FilterCondition(String field, String operator, String value) {
            this.field = field; this.operator = operator; this.value = value;
        }
        public String getField() { return field; }
        public void setField(String f) { this.field = f; }
        public String getOperator() { return operator; }
        public void setOperator(String o) { this.operator = o; }
        public String getValue() { return value; }
        public void setValue(String v) { this.value = v; }
    }

    public static class ReportOptions {
        private String visualType = "table";  // table, bar, line, pie, matrix, area
        private boolean subtotals = false;
        private boolean columnTotals = false;
        private String pageBreakOn;           // field to break pages on
        private String sortField;
        private String sortDirection = "ASC"; // ASC, DESC

        public String getVisualType() { return visualType; }
        public void setVisualType(String v) { this.visualType = v; }
        public boolean isSubtotals() { return subtotals; }
        public void setSubtotals(boolean s) { this.subtotals = s; }
        public boolean isColumnTotals() { return columnTotals; }
        public void setColumnTotals(boolean c) { this.columnTotals = c; }
        public String getPageBreakOn() { return pageBreakOn; }
        public void setPageBreakOn(String p) { this.pageBreakOn = p; }
        public String getSortField() { return sortField; }
        public void setSortField(String s) { this.sortField = s; }
        public String getSortDirection() { return sortDirection; }
        public void setSortDirection(String s) { this.sortDirection = s; }
    }

    /**
     * Field catalog — metadata about available tables and fields.
     */
    public static class DataSourceCatalog {
        private List<TableMeta> tables = new ArrayList<>();

        public List<TableMeta> getTables() { return tables; }
    }

    public static class TableMeta {
        private String name;
        private String displayName;
        private List<FieldMeta> fields = new ArrayList<>();

        public TableMeta() {}
        public TableMeta(String name, String displayName) {
            this.name = name; this.displayName = displayName;
        }
        public String getName() { return name; }
        public void setName(String n) { this.name = n; }
        public String getDisplayName() { return displayName; }
        public void setDisplayName(String d) { this.displayName = d; }
        public List<FieldMeta> getFields() { return fields; }
    }

    public static class FieldMeta {
        private String name;
        private String displayName;
        private String dataType;    // String, Integer, Decimal, DateTime
        private String usage;       // measure, dimension, filter
        private List<String> allowedAggregations = new ArrayList<>();

        public FieldMeta() {}
        public FieldMeta(String name, String displayName, String dataType, String usage) {
            this.name = name; this.displayName = displayName;
            this.dataType = dataType; this.usage = usage;
            if ("measure".equals(usage)) {
                this.allowedAggregations = List.of("SUM", "AVG", "MIN", "MAX", "COUNT");
            } else {
                this.allowedAggregations = List.of("COUNT");
            }
        }
        public String getName() { return name; }
        public void setName(String n) { this.name = n; }
        public String getDisplayName() { return displayName; }
        public void setDisplayName(String d) { this.displayName = d; }
        public String getDataType() { return dataType; }
        public void setDataType(String d) { this.dataType = d; }
        public String getUsage() { return usage; }
        public void setUsage(String u) { this.usage = u; }
        public List<String> getAllowedAggregations() { return allowedAggregations; }
        public void setAllowedAggregations(List<String> a) { this.allowedAggregations = a; }
    }

    /**
     * A saved report definition (persisted in memory or database).
     */
    public static class SavedReport {
        private String id;
        private String name;
        private String createdBy;
        private LocalDateTime createdAt;
        private LocalDateTime lastRunAt;
        private LocalDateTime updatedAt;
        private ReportDefinition definition;

        public String getId() { return id; }
        public void setId(String i) { this.id = i; }
        public String getName() { return name; }
        public void setName(String n) { this.name = n; }
        public String getCreatedBy() { return createdBy; }
        public void setCreatedBy(String c) { this.createdBy = c; }
        public LocalDateTime getCreatedAt() { return createdAt; }
        public void setCreatedAt(LocalDateTime c) { this.createdAt = c; }
        public LocalDateTime getLastRunAt() { return lastRunAt; }
        public void setLastRunAt(LocalDateTime l) { this.lastRunAt = l; }
        public LocalDateTime getUpdatedAt() { return updatedAt; }
        public void setUpdatedAt(LocalDateTime u) { this.updatedAt = u; }
        public ReportDefinition getDefinition() { return definition; }
        public void setDefinition(ReportDefinition d) { this.definition = d; }
    }

    /**
     * Request to run a self-service report.
     */
    public static class RunReportRequest {
        private ReportDefinition definition;
        private String format = "HTML5";  // HTML5, PDF, EXCELOPENXML, CSV

        public ReportDefinition getDefinition() { return definition; }
        public void setDefinition(ReportDefinition d) { this.definition = d; }
        public String getFormat() { return format; }
        public void setFormat(String f) { this.format = f; }
    }

    /**
     * Request to save a report definition.
     */
    public static class SaveReportRequest {
        private String name;
        private ReportDefinition definition;

        public String getName() { return name; }
        public void setName(String n) { this.name = n; }
        public ReportDefinition getDefinition() { return definition; }
        public void setDefinition(ReportDefinition d) { this.definition = d; }
    }
}
