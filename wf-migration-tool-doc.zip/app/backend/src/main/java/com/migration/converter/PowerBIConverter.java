package com.migration.converter;

import com.migration.model.*;
import com.migration.model.ConversionResult.*;
import com.migration.model.ParsedFexFile.*;
import com.migration.model.ParsedMasterFile.*;
import org.springframework.stereotype.Service;
import java.util.*;
import java.util.stream.*;

@Service
public class PowerBIConverter {
    private final ExpressionConverter expr;

    public PowerBIConverter(ExpressionConverter expr) { this.expr = expr; }

    // ═══════════════════════════════════════════════════════════════
    // Master File → Power BI Tables/Relationships
    // ═══════════════════════════════════════════════════════════════
    public ConversionResult convertMasterFile(ParsedMasterFile mas) {
        ConversionResult r = new ConversionResult();
        r.setSourceFile(mas.getFileName()); r.setSourceType("Master File");
        r.setSourceClassification("DataModel");
        PowerBIOutput out = new PowerBIOutput();

        if (!mas.getSegments().isEmpty()) {
            for (Segment seg : mas.getSegments()) {
                TableDef t = new TableDef();
                t.setName(seg.getTableName() != null ? seg.getTableName() : seg.getName());
                t.setSource("Segment: " + seg.getName());
                for (MasterField f : seg.getFields()) t.getColumns().add(convertMasterField(f));
                out.getTables().add(t);
                if (seg.getParent() != null) {
                    Relationship rel = new Relationship();
                    rel.setFromTable(t.getName()); rel.setToTable(seg.getParent());
                    rel.setType(seg.isCrossRef() ? "Many-to-Many" : "Many-to-One");
                    rel.setCrossFilterDirection("Single");
                    rel.setNote("Segment hierarchy: " + seg.getName() + " → " + seg.getParent());
                    out.getRelationships().add(rel);
                    r.getMappings().add(new Mapping("Segment " + seg.getName() + " PARENT=" + seg.getParent(),
                        "Relationship: " + t.getName() + " → " + seg.getParent(), "Converted", "Relationship"));
                }
            }
        } else {
            TableDef t = new TableDef();
            t.setName(mas.getAccessFile() != null ? mas.getAccessFile() : mas.getFileName().replaceAll("(?i)\\.mas$", ""));
            t.setSource("Master File"); 
            for (MasterField f : mas.getFields()) t.getColumns().add(convertMasterField(f));
            out.getTables().add(t);
        }

        // DBA → Power Query connection string
        if (mas.getDbaConfig() != null) {
            MQuery connQuery = new MQuery("Connection_" + mas.getAccessFile(),
                generateConnectionM(mas), "DBA Configuration");
            out.getQueries().add(connQuery);
            r.getMappings().add(new Mapping("DBA " + mas.getDbaConfig().getDbType(),
                "Power Query connection: " + mas.getDbaConfig().getDbType(), "Converted", "Connection"));
        }

        for (MasterField f : mas.getFields()) {
            String pbiType = expr.mapDataType(f.getFormat(), f.getDataType());
            r.getMappings().add(new Mapping(f.getName() + " (" + (f.getFormat() != null ? f.getFormat() : "?") + ")",
                f.getName() + " (" + pbiType + ")", f.getFormat() != null ? "Converted" : "Needs Review", "Column"));
        }

        // Defines in master → calculated columns
        for (DefineInMaster d : mas.getDefines()) {
            var outcome = expr.convertExpression(d.getExpression());
            CalculatedColumn cc = new CalculatedColumn();
            cc.setName(d.getField()); cc.setTable(mas.getAccessFile());
            cc.setExpression(outcome.getDax()); cc.setSource("Master DEFINE: " + d.getField());
            out.getCalculatedColumns().add(cc);
            r.getMappings().add(new Mapping("Master DEFINE " + d.getField(), "Calc Column: " + outcome.getDax(),
                outcome.getConfidence() > 0.7 ? "Converted" : "Needs Review", "Column"));
        }

        r.setPowerBI(out);
        r.setConfidence(calcConfidence(r));
        return r;
    }

    // ═══════════════════════════════════════════════════════════════
    // FOCEXEC → Full Power BI conversion
    // ═══════════════════════════════════════════════════════════════
    public ConversionResult convertFexFile(ParsedFexFile fex) {
        ConversionResult r = new ConversionResult();
        r.setSourceFile(fex.getFileName()); r.setSourceType("FOCEXEC");
        PowerBIOutput out = new PowerBIOutput();

        // Classify
        FileClassification cls = fex.getClassification();
        if (cls.isActiveReport()) r.setSourceClassification("ActiveReport");
        else if (cls.isSelfServiceReport()) r.setSourceClassification("SelfService");
        else if (cls.isDashboard()) r.setSourceClassification("Dashboard");
        else if (cls.isPaginatedReport()) r.setSourceClassification("PaginatedReport");
        else if (cls.isEtlProcedure()) r.setSourceClassification("ETL");
        else r.setSourceClassification("Standard");

        // ── DEFINE → Calculated Columns ──────────────────────────
        for (DefineField def : fex.getDefines()) {
            var outcome = expr.convertExpression(def.getExpression());
            CalculatedColumn cc = new CalculatedColumn();
            cc.setName(def.getField()); cc.setTable(def.getFile());
            cc.setExpression(outcome.getDax()); cc.setSource("DEFINE " + def.getField() + " = " + def.getExpression());
            out.getCalculatedColumns().add(cc);
            r.getMappings().add(new Mapping("DEFINE " + def.getField(),
                "Calculated Column: " + def.getField() + " = " + outcome.getDax(),
                outcome.getConfidence() > 0.7 ? "Converted" : "Needs Review", "Column"));
            outcome.getIssues().forEach(iss -> r.getIssues().add(new Issue("warning", iss, def.getLine())));
        }

        // ── ACCEPT/PROMPT → Parameters/Slicers ──────────────────
        for (PromptSpec prompt : fex.getPrompts()) {
            ParameterDef pd = new ParameterDef();
            pd.setName(prompt.getParamName() != null ? prompt.getParamName() : "param_" + prompt.getLine());
            pd.setDisplayName(prompt.getDescription() != null ? prompt.getDescription() : pd.getName());
            pd.setDefaultValue(prompt.getDefaultValue());
            pd.setDataType(prompt.getParamType() != null ? mapParamType(prompt.getParamType()) : "Text");
            pd.setPbiType(prompt.getAllowedValues().isEmpty() ? "Parameter" : "Slicer");
            pd.getAllowedValues().addAll(prompt.getAllowedValues());
            pd.setSource(prompt.getText());
            out.getParameters().add(pd);
            r.getMappings().add(new Mapping("ACCEPT/PROMPT " + pd.getName(),
                "PBI Parameter: " + pd.getName() + " (" + pd.getPbiType() + ")",
                "Converted", "Parameter"));
        }

        // ── -SET variables → Parameters ──────────────────────────
        for (Variable v : fex.getVariables()) {
            ParameterDef pd = new ParameterDef();
            pd.setName(v.getName()); pd.setDisplayName(v.getName());
            pd.setDefaultValue(v.getValue()); pd.setDataType(mapVarType(v.getDataType()));
            pd.setPbiType("Parameter"); pd.setSource("-SET &" + v.getName() + " = " + v.getValue());
            out.getParameters().add(pd);
            r.getMappings().add(new Mapping("-SET &" + v.getName() + " = " + v.getValue(),
                "PBI Parameter: " + v.getName() + " (default: " + v.getValue() + ")",
                "Converted", "Parameter"));
        }

        // ── JOINs → Relationships ────────────────────────────────
        for (JoinSpec join : fex.getJoins()) {
            if (join.getLeftField() != null) {
                Relationship rel = new Relationship();
                rel.setFromTable(join.getLeftFile()); rel.setToTable(join.getRightFile());
                rel.setFromColumn(join.getLeftField()); rel.setToColumn(join.getRightField());
                rel.setType("Many-to-One"); rel.setCrossFilterDirection("Single");
                out.getRelationships().add(rel);
                r.getMappings().add(new Mapping(
                    "JOIN " + join.getLeftField() + " IN " + join.getLeftFile() + " TO " + join.getRightField() + " IN " + join.getRightFile(),
                    "Relationship: " + join.getLeftFile() + "[" + join.getLeftField() + "] → " + join.getRightFile() + "[" + join.getRightField() + "]",
                    "Converted", "Relationship"));
            }
        }

        // ── MATCH/COMBINE → Power Query Append/Merge ─────────────
        for (MatchSpec match : fex.getMatches()) {
            String mExpr = match.getMatchType().equals("MATCH")
                ? generateMatchM(match) : generateCombineM(match);
            out.getQueries().add(new MQuery("Query_" + match.getMatchType() + "_" + match.getLine(), mExpr, match.getRaw()));
            r.getMappings().add(new Mapping(match.getRaw(),
                "Power Query " + (match.getMatchType().equals("MATCH") ? "Table.NestedJoin" : "Table.Combine"),
                "Needs Review", "Query"));
        }

        // ── TABLE/GRAPH Requests ─────────────────────────────────
        int reportIdx = 1;
        for (TableRequest req : fex.getRequests()) {
            convertRequest(req, out, r, fex, reportIdx++);
        }

        // ── Self-Service Mapping ─────────────────────────────────
        if (cls.isSelfServiceReport() && fex.getSelfService() != null) {
            SelfServiceMapping ssm = new SelfServiceMapping();
            ssm.setSourceToolType(fex.getSelfService().getToolType());
            ssm.setTargetReportType("Interactive");
            if (fex.getSelfService().isAllowFilter()) ssm.getEnabledFeatures().add("Filter");
            if (fex.getSelfService().isAllowSort()) ssm.getEnabledFeatures().add("Sort");
            if (fex.getSelfService().isAllowDrillDown()) ssm.getEnabledFeatures().add("DrillDown");
            if (fex.getSelfService().isAllowExport()) ssm.getEnabledFeatures().add("Export");
            if (fex.getSelfService().isAllowPivot()) ssm.getEnabledFeatures().add("Pivot");
            ssm.setEnableQA(true); ssm.setEnableSubscriptions(true);
            r.setSelfServiceMapping(ssm);
            r.getMappings().add(new Mapping("Self-Service: " + ssm.getSourceToolType(),
                "PBI Interactive Report with: " + String.join(", ", ssm.getEnabledFeatures()),
                "Converted", "SelfService"));
        }

        // ── Active Report Mapping ────────────────────────────────
        if (cls.isActiveReport() && fex.getActiveReportConfig() != null) {
            ActiveReportMapping arm = new ActiveReportMapping();
            arm.setTargetType("Interactive Report with Bookmarks");
            if (fex.getActiveReportConfig().isHasInteractiveFilters()) arm.getInteractiveFilters().add("All Fields");
            if (fex.getActiveReportConfig().isHasPivot()) arm.setHasPivot(true);
            if (fex.getActiveReportConfig().isHasRollup()) arm.setHasRollup(true);
            r.setActiveReportMapping(arm);
            r.getMappings().add(new Mapping("Active Report (v" + fex.getActiveReportConfig().getArVersion() + ")",
                "PBI Interactive Report with Bookmarks/Slicers",
                "Needs Review", "ActiveReport"));
        }

        // ── HOLD chains → Dataflow ───────────────────────────────
        if (cls.isEtlProcedure() && !fex.getHolds().isEmpty()) {
            DataflowDef df = new DataflowDef();
            df.setName("Dataflow_" + fex.getFileName().replaceAll("\\.[^.]+$", ""));
            for (HoldSpec h : fex.getHolds()) {
                DataflowStep step = new DataflowStep();
                step.setName(h.getHoldName() != null ? h.getHoldName() : "Step_" + h.getLine());
                step.setType("Transform");
                step.setSource(h.getText());
                step.setMExpression("// HOLD " + (h.getHoldName() != null ? h.getHoldName() : "") +
                    " → Power BI Dataflow step");
                df.getSteps().add(step);
            }
            r.setDataflow(df);
            r.getMappings().add(new Mapping("HOLD chain (" + fex.getHolds().size() + " steps)",
                "PBI Dataflow: " + df.getName(), "Needs Review", "ETL"));
        }

        // ── Dialogue Manager → Manual steps ──────────────────────
        for (DMCommand dm : fex.getDialogueManagerCommands()) {
            if (dm.getCommand().equals("RUN") || dm.getCommand().equals("IF") || dm.getCommand().equals("GOTO")) {
                r.getMappings().add(new Mapping("DM: -" + dm.getCommand() + " " + dm.getArguments(),
                    "Manual: Power Automate flow or PBI parameter logic",
                    "Manual", "DialogueManager"));
            }
        }

        r.setPowerBI(out);
        r.setConfidence(calcConfidence(r));

        // ── Paginated Report ─────────────────────────────────────
        if (cls.isPaginatedReport()) {
            r.setPaginatedReport(buildPaginatedReport(fex, r));
        }

        return r;
    }

    // ═══════════════════════════════════════════════════════════════
    // Convert a single TABLE/GRAPH request
    // ═══════════════════════════════════════════════════════════════
    private void convertRequest(TableRequest req, PowerBIOutput out, ConversionResult r, ParsedFexFile fex, int idx) {
        String pageName = "Page " + idx + " - " + req.getFile();

        // Aggregated fields → DAX Measures
        for (RequestField f : req.getFields()) {
            if (f.getAggregation() != null) {
                String mName = f.getAlias() != null ? f.getAlias() : f.getAggregation() + "_" + f.getName();
                String daxFunc = expr.mapAggregation(f.getAggregation());
                String daxExpr = daxFunc + "(" + req.getFile() + "[" + f.getName() + "])";
                Measure m = new Measure(mName, daxExpr, f.getAggregation() + " " + f.getName(), req.getFile());
                m.setFormatString(expr.convertFormatMask(f.getFormat()));
                out.getMeasures().add(m);
                r.getMappings().add(new Mapping(f.getAggregation() + " " + f.getName(),
                    "DAX: " + mName + " = " + daxExpr, "Converted", "Measure"));
            }
        }

        // COMPUTE → DAX Measures
        for (ComputeField comp : req.getComputes()) {
            var outcome = expr.convertExpression(comp.getExpression());
            out.getMeasures().add(new Measure(comp.getField(), outcome.getDax(),
                "COMPUTE " + comp.getField() + " = " + comp.getExpression(), req.getFile()));
            r.getMappings().add(new Mapping("COMPUTE " + comp.getField(),
                "DAX: " + comp.getField() + " = " + outcome.getDax(),
                outcome.getConfidence() > 0.7 ? "Converted" : "Needs Review", "Measure"));
        }

        // RECAP/RECOMPUTE → DAX measures with context
        for (RecapField recap : req.getRecaps()) {
            var outcome = expr.convertExpression(recap.getExpression());
            String measureName = recap.getRecapType() + "_" + recap.getField();
            out.getMeasures().add(new Measure(measureName, outcome.getDax(),
                recap.getRecapType() + " " + recap.getField() + " = " + recap.getExpression(), req.getFile()));
            r.getMappings().add(new Mapping(recap.getRecapType() + " " + recap.getField(),
                "DAX: " + measureName + " (at " + recap.getBreakField() + " break)",
                "Needs Review", "Pagination"));
        }

        // Filters → DAX CALCULATE
        for (FilterSpec filter : req.getFilters()) {
            String daxFilter = expr.convertFilter(filter.getExpression(), req.getFile());
            String status = filter.isParameterized() ? "Converted" : "Needs Review";
            r.getMappings().add(new Mapping(filter.getExpression(), "DAX: " + daxFilter, status, "Filter"));
        }

        // Style rules → Conditional formatting
        for (StyleRule style : req.getStyleRules()) {
            if (style.getCondition() != null || style.getTargetField() != null) {
                ConditionalFormat cf = new ConditionalFormat();
                cf.setTargetField(style.getTargetField());
                cf.setCondition(style.getCondition() != null ? expr.convertCondition(style.getCondition()) : null);
                cf.setBackgroundColor(expr.convertColor(style.getProperties().get("BACKCOLOR")));
                cf.setFontColor(expr.convertColor(style.getProperties().get("COLOR")));
                cf.setSource("STYLE: " + style.getTarget() + (style.getTargetField() != null ? "=" + style.getTargetField() : ""));
                out.getConditionalFormats().add(cf);
                r.getMappings().add(new Mapping("STYLE " + cf.getSource(),
                    "PBI Conditional Format: " + (cf.getCondition() != null ? cf.getCondition() : "static"),
                    "Converted", "Style"));
            }
        }

        // Drill-downs → Drill-through pages
        for (DrillDownSpec dd : req.getDrillDowns()) {
            DrillThroughPage dtp = new DrillThroughPage();
            dtp.setPageName("DrillThrough_" + dd.getSourceField());
            dtp.setSourceField(dd.getSourceField());
            dtp.setTargetReport(dd.getTargetProcedure());
            dtp.getPassedFilters().addAll(dd.getPassedParameters());
            out.getDrillThroughPages().add(dtp);
            r.getMappings().add(new Mapping("Drill-down: " + dd.getSourceField() + " → " + dd.getTargetProcedure(),
                "PBI Drill-through page: " + dtp.getPageName(), "Needs Review", "DrillDown"));
        }

        // Visual config
        VisualConfig vc = new VisualConfig();
        vc.setPageName(pageName);
        if (req.getType().equals("GRAPH")) {
            String gt = req.getGraphConfig() != null ? req.getGraphConfig().getGraphType() : null;
            vc.setType(expr.mapGraphType(gt, req.getRaw()));
        } else if (!req.getAcrossFields().isEmpty()) {
            vc.setType("Matrix");
        } else {
            vc.setType("Table");
        }
        vc.getFields().addAll(req.getFields().stream().map(f -> f.getAlias() != null ? f.getAlias() : f.getName()).collect(Collectors.toList()));
        vc.getGroupBy().addAll(req.getGroupBy());
        if (!req.getAcrossFields().isEmpty()) vc.setAcross(String.join(", ", req.getAcrossFields()));
        vc.setHasSubTotals(req.isSubTotals());
        vc.setSource(req.getType() + " FILE " + req.getFile());
        out.getVisualConfigs().add(vc);

        // Power Query M
        out.getQueries().add(new MQuery("Query_" + req.getFile() + "_" + idx, generateMQuery(req), req.getType() + " FILE " + req.getFile()));

        // Pagination mappings
        if (req.getPagination().isHasPageBreaks()) {
            r.getMappings().add(new Mapping("PAGE-BREAK on: " + String.join(", ", req.getPageBreaks()),
                "PBI Paginated Report group break with page-break-before",
                "Converted", "Pagination"));
        }
        if (req.isSubTotals()) {
            r.getMappings().add(new Mapping("SUBTOTAL", "PBI Matrix/Table subtotals enabled", "Converted", "Pagination"));
        }
        if (req.isColumnTotal()) {
            r.getMappings().add(new Mapping("COLUMN-TOTAL", "PBI Table grand total row", "Converted", "Pagination"));
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // Paginated Report Definition (RDL-like structure)
    // ═══════════════════════════════════════════════════════════════
    private PaginatedReportDef buildPaginatedReport(ParsedFexFile fex, ConversionResult r) {
        PaginatedReportDef pr = new PaginatedReportDef();
        pr.setReportName(fex.getFileName().replaceAll("\\.[^.]+$", ""));

        // Parameters from prompts and variables
        for (PromptSpec p : fex.getPrompts()) {
            ReportParameter rp = new ReportParameter();
            rp.setName(p.getParamName() != null ? p.getParamName() : "param");
            rp.setPrompt(p.getDescription() != null ? p.getDescription() : rp.getName());
            rp.setDataType(p.getParamType() != null ? mapParamType(p.getParamType()) : "String");
            rp.setDefaultValue(p.getDefaultValue()); rp.setRequired(p.isRequired());
            pr.getParameters().add(rp);
        }

        // Process each request for paginated structure
        for (TableRequest req : fex.getRequests()) {
            // Header/Footer
            if (!req.getHeadings().isEmpty() && pr.getHeader() == null) {
                ReportHeader hdr = new ReportHeader();
                hdr.getTextLines().addAll(req.getHeadings());
                hdr.setShowOnEveryPage(true);
                pr.setHeader(hdr);
            }
            if (!req.getFootings().isEmpty() && pr.getFooter() == null) {
                ReportFooter ftr = new ReportFooter();
                ftr.getTextLines().addAll(req.getFootings());
                ftr.setHasPageNumber(req.getPagination().isHasPageNumbering());
                ftr.setHasRunDate(req.getPagination().isHasRunDate());
                ftr.setHasTotalPages(req.getPagination().isHasTotalPages());
                pr.setFooter(ftr);
            }

            // Groups with page breaks
            for (String by : req.getGroupBy()) {
                GroupDefinition gd = new GroupDefinition();
                gd.setFieldName(by);
                gd.setHasHeader(!req.getSubHeadings().isEmpty());
                gd.setHasFooter(!req.getSubFootings().isEmpty() || req.isSubTotals());
                gd.setPageBreakBefore(req.getPageBreaks().contains(by));
                gd.setRepeatHeaderOnNewPage(true);
                // Subtotal expressions
                for (RequestField f : req.getFields()) {
                    if (f.getAggregation() != null) {
                        gd.getSubtotalExpressions().add("=Sum(Fields!" + f.getName() + ".Value)");
                    }
                }
                pr.getGroups().add(gd);
            }

            // Body item
            ReportBody body = new ReportBody();
            body.setType(req.getType().equals("GRAPH") ? "Chart" : (!req.getAcrossFields().isEmpty() ? "Matrix" : "Tablix"));
            body.setName(req.getType() + "_" + req.getFile());
            body.getProperties().put("fields", req.getFields().stream().map(RequestField::getName).collect(Collectors.toList()));
            body.getProperties().put("groupBy", req.getGroupBy());
            body.getProperties().put("pageBreaks", req.getPageBreaks());
            pr.getBodyItems().add(body);
        }

        pr.setHasPageNumbers(fex.getRequests().stream().anyMatch(rq -> rq.getPagination().isHasPageNumbering()));
        pr.setHasRunDate(fex.getRequests().stream().anyMatch(rq -> rq.getPagination().isHasRunDate()));

        r.getMappings().add(new Mapping("Paginated Report: " + pr.getReportName(),
            "PBI Paginated Report with " + pr.getGroups().size() + " groups, " +
            pr.getParameters().size() + " parameters", "Converted", "Pagination"));

        return pr;
    }

    // ═══════════════════════════════════════════════════════════════
    // Helpers
    // ═══════════════════════════════════════════════════════════════
    private ColumnDef convertMasterField(MasterField f) {
        ColumnDef c = new ColumnDef();
        c.setName(f.getAlias() != null ? f.getAlias() : f.getName());
        c.setDataType(expr.mapDataType(f.getFormat(), f.getDataType()));
        c.setDescription(f.getDescription() != null ? f.getDescription() : (f.getTitle() != null ? f.getTitle() : ""));
        c.setFormat(f.getFormat()); c.setSourceField(f.getName());
        return c;
    }

    private String generateMQuery(TableRequest req) {
        StringBuilder sb = new StringBuilder();
        sb.append("let\n    Source = Sql.Database(\"server\", \"database\"),\n");
        sb.append("    ").append(req.getFile()).append(" = Source{[Schema=\"dbo\", Item=\"").append(req.getFile()).append("\"]}[Data],\n");
        String prev = req.getFile();

        if (!req.getFilters().isEmpty()) {
            sb.append("    Filtered = Table.SelectRows(").append(prev).append(", each\n");
            for (FilterSpec f : req.getFilters()) sb.append("        // ").append(f.getExpression()).append("\n");
            sb.append("        true // TODO: implement filter logic\n    ),\n");
            prev = "Filtered";
        }
        if (!req.getGroupBy().isEmpty() && req.getFields().stream().anyMatch(f -> f.getAggregation() != null)) {
            String groupCols = req.getGroupBy().stream().map(g -> "\"" + g + "\"").collect(Collectors.joining(", "));
            String aggFields = req.getFields().stream().filter(f -> f.getAggregation() != null)
                .map(f -> "{\"" + (f.getAlias() != null ? f.getAlias() : f.getName()) + "\", each " +
                    expr.mapAggregationToM(f.getAggregation()) + "([" + f.getName() + "]), type number}")
                .collect(Collectors.joining(",\n        "));
            sb.append("    Grouped = Table.Group(").append(prev).append(", {").append(groupCols).append("}, {\n        ").append(aggFields).append("\n    }),\n");
            prev = "Grouped";
        }
        sb.append("    Result = ").append(prev).append("\nin\n    Result");
        return sb.toString();
    }

    private String generateMatchM(MatchSpec match) {
        return "let\n    // MATCH FILE → Table.NestedJoin\n" +
            "    Source1 = #\"" + (match.getFiles().size() > 0 ? match.getFiles().get(0) : "Table1") + "\",\n" +
            "    Source2 = #\"" + (match.getFiles().size() > 1 ? match.getFiles().get(1) : "Table2") + "\",\n" +
            "    Merged = Table.NestedJoin(Source1, " +
            match.getMatchFields().stream().map(f -> "\"" + f + "\"").collect(Collectors.joining(", ")) +
            ", Source2, JoinKind.LeftOuter)\nin\n    Merged";
    }

    private String generateCombineM(MatchSpec match) {
        return "let\n    // COMBINE → Table.Combine\n    Combined = Table.Combine({" +
            match.getFiles().stream().map(f -> "#\"" + f + "\"").collect(Collectors.joining(", ")) +
            "})\nin\n    Combined";
    }

    private String generateConnectionM(ParsedMasterFile mas) {
        DBAConfig dba = mas.getDbaConfig();
        String provider = dba.getDbType() != null ? dba.getDbType() : "ODBC";
        return "let\n    // Connection from WebFocus DBA: " + provider + "\n" +
            "    Source = " + switch (provider.toUpperCase()) {
                case "DB2" -> "DB2.Database(\"server\", \"" + (dba.getCatalog() != null ? dba.getCatalog() : "db") + "\")";
                case "ORACLE" -> "Oracle.Database(\"server\")";
                case "SQLSVR" -> "Sql.Database(\"server\", \"" + (dba.getCatalog() != null ? dba.getCatalog() : "db") + "\")";
                default -> "Odbc.DataSource(\"DSN=" + (dba.getConnectionName() != null ? dba.getConnectionName() : "MyDSN") + "\")";
            } + "\nin\n    Source";
    }

    private String mapParamType(String wfType) {
        if (wfType == null) return "Text";
        return switch (wfType.toUpperCase()) {
            case "INTEGER", "I", "INT" -> "Integer";
            case "DOUBLE", "FLOAT", "D", "P" -> "Decimal";
            case "DATE", "YYMD", "YMD" -> "Date";
            case "DATETIME" -> "DateTime";
            default -> "Text";
        };
    }

    private String mapVarType(String type) {
        if (type == null) return "Text";
        return switch (type) { case "INTEGER" -> "Integer"; case "DECIMAL" -> "Decimal"; default -> "Text"; };
    }

    private int calcConfidence(ConversionResult r) {
        int total = Math.max(r.getMappings().size(), 1);
        int converted = (int) r.getMappings().stream().filter(m -> "Converted".equals(m.getStatus())).count();
        return Math.round((float) converted / total * 100);
    }
}
