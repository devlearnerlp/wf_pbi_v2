package com.migration.model;

import java.util.*;

/**
 * Complete conversion result covering all Power BI target types:
 * Interactive Reports, Paginated Reports (RDL), Dashboards,
 * Dataflows (from HOLD chains), Parameters, Drill-through pages,
 * Conditional formatting, and Active Report → Interactive features.
 */
public class ConversionResult {
    private String sourceFile;
    private String sourceType;          // FOCEXEC, Master File
    private String sourceClassification; // PaginatedReport, SelfService, Dashboard, ActiveReport, ETL, Standard
    private PowerBIOutput powerBI = new PowerBIOutput();
    private PaginatedReportDef paginatedReport;
    private SelfServiceMapping selfServiceMapping;
    private DashboardMapping dashboardMapping;
    private ActiveReportMapping activeReportMapping;
    private DataflowDef dataflow;
    private List<Mapping> mappings = new ArrayList<>();
    private List<Issue> issues = new ArrayList<>();
    private int confidence;

    // Getters/Setters
    public String getSourceFile() { return sourceFile; }
    public void setSourceFile(String s) { this.sourceFile = s; }
    public String getSourceType() { return sourceType; }
    public void setSourceType(String s) { this.sourceType = s; }
    public String getSourceClassification() { return sourceClassification; }
    public void setSourceClassification(String s) { this.sourceClassification = s; }
    public PowerBIOutput getPowerBI() { return powerBI; }
    public void setPowerBI(PowerBIOutput p) { this.powerBI = p; }
    public PaginatedReportDef getPaginatedReport() { return paginatedReport; }
    public void setPaginatedReport(PaginatedReportDef p) { this.paginatedReport = p; }
    public SelfServiceMapping getSelfServiceMapping() { return selfServiceMapping; }
    public void setSelfServiceMapping(SelfServiceMapping s) { this.selfServiceMapping = s; }
    public DashboardMapping getDashboardMapping() { return dashboardMapping; }
    public void setDashboardMapping(DashboardMapping d) { this.dashboardMapping = d; }
    public ActiveReportMapping getActiveReportMapping() { return activeReportMapping; }
    public void setActiveReportMapping(ActiveReportMapping a) { this.activeReportMapping = a; }
    public DataflowDef getDataflow() { return dataflow; }
    public void setDataflow(DataflowDef d) { this.dataflow = d; }
    public List<Mapping> getMappings() { return mappings; }
    public List<Issue> getIssues() { return issues; }
    public int getConfidence() { return confidence; }
    public void setConfidence(int c) { this.confidence = c; }

    // ═══════════════════════════════════════════════════════════════
    // Standard Power BI Output (DAX, M, Tables, Relationships)
    // ═══════════════════════════════════════════════════════════════
    public static class PowerBIOutput {
        private List<TableDef> tables = new ArrayList<>();
        private List<Relationship> relationships = new ArrayList<>();
        private List<Measure> measures = new ArrayList<>();
        private List<CalculatedColumn> calculatedColumns = new ArrayList<>();
        private List<MQuery> queries = new ArrayList<>();
        private List<VisualConfig> visualConfigs = new ArrayList<>();
        private List<ParameterDef> parameters = new ArrayList<>();
        private List<ConditionalFormat> conditionalFormats = new ArrayList<>();
        private List<DrillThroughPage> drillThroughPages = new ArrayList<>();
        private List<BookmarkDef> bookmarks = new ArrayList<>();

        public List<TableDef> getTables() { return tables; }
        public List<Relationship> getRelationships() { return relationships; }
        public List<Measure> getMeasures() { return measures; }
        public List<CalculatedColumn> getCalculatedColumns() { return calculatedColumns; }
        public List<MQuery> getQueries() { return queries; }
        public List<VisualConfig> getVisualConfigs() { return visualConfigs; }
        public List<ParameterDef> getParameters() { return parameters; }
        public List<ConditionalFormat> getConditionalFormats() { return conditionalFormats; }
        public List<DrillThroughPage> getDrillThroughPages() { return drillThroughPages; }
        public List<BookmarkDef> getBookmarks() { return bookmarks; }
    }

    public static class TableDef {
        private String name;
        private List<ColumnDef> columns = new ArrayList<>();
        private String source;
        private String sourceQuery; // SQL passthrough if applicable
        public String getName() { return name; }
        public void setName(String n) { this.name = n; }
        public List<ColumnDef> getColumns() { return columns; }
        public String getSource() { return source; }
        public void setSource(String s) { this.source = s; }
        public String getSourceQuery() { return sourceQuery; }
        public void setSourceQuery(String q) { this.sourceQuery = q; }
    }

    public static class ColumnDef {
        private String name;
        private String dataType;
        private String description;
        private String format;
        private String sourceField;
        public ColumnDef() {}
        public ColumnDef(String name, String dataType, String description) {
            this.name = name; this.dataType = dataType; this.description = description;
        }
        public String getName() { return name; }
        public void setName(String n) { this.name = n; }
        public String getDataType() { return dataType; }
        public void setDataType(String d) { this.dataType = d; }
        public String getDescription() { return description; }
        public void setDescription(String d) { this.description = d; }
        public String getFormat() { return format; }
        public void setFormat(String f) { this.format = f; }
        public String getSourceField() { return sourceField; }
        public void setSourceField(String s) { this.sourceField = s; }
    }

    public static class Relationship {
        private String fromTable; private String toTable;
        private String fromColumn; private String toColumn;
        private String type; private String crossFilterDirection;
        private String note;
        public String getFromTable() { return fromTable; }
        public void setFromTable(String f) { this.fromTable = f; }
        public String getToTable() { return toTable; }
        public void setToTable(String t) { this.toTable = t; }
        public String getFromColumn() { return fromColumn; }
        public void setFromColumn(String f) { this.fromColumn = f; }
        public String getToColumn() { return toColumn; }
        public void setToColumn(String t) { this.toColumn = t; }
        public String getType() { return type; }
        public void setType(String t) { this.type = t; }
        public String getCrossFilterDirection() { return crossFilterDirection; }
        public void setCrossFilterDirection(String c) { this.crossFilterDirection = c; }
        public String getNote() { return note; }
        public void setNote(String n) { this.note = n; }
    }

    public static class Measure {
        private String name; private String expression;
        private String source; private String table;
        private String formatString;
        public Measure() {}
        public Measure(String name, String expression, String source, String table) {
            this.name = name; this.expression = expression; this.source = source; this.table = table;
        }
        public String getName() { return name; }
        public void setName(String n) { this.name = n; }
        public String getExpression() { return expression; }
        public void setExpression(String e) { this.expression = e; }
        public String getSource() { return source; }
        public void setSource(String s) { this.source = s; }
        public String getTable() { return table; }
        public void setTable(String t) { this.table = t; }
        public String getFormatString() { return formatString; }
        public void setFormatString(String f) { this.formatString = f; }
    }

    public static class CalculatedColumn {
        private String name; private String table;
        private String expression; private String source;
        public String getName() { return name; }
        public void setName(String n) { this.name = n; }
        public String getTable() { return table; }
        public void setTable(String t) { this.table = t; }
        public String getExpression() { return expression; }
        public void setExpression(String e) { this.expression = e; }
        public String getSource() { return source; }
        public void setSource(String s) { this.source = s; }
    }

    public static class MQuery {
        private String name; private String expression; private String source;
        public MQuery() {}
        public MQuery(String n, String e, String s) { this.name = n; this.expression = e; this.source = s; }
        public String getName() { return name; }
        public void setName(String n) { this.name = n; }
        public String getExpression() { return expression; }
        public void setExpression(String e) { this.expression = e; }
        public String getSource() { return source; }
        public void setSource(String s) { this.source = s; }
    }

    public static class VisualConfig {
        private String type; private List<String> fields = new ArrayList<>();
        private List<String> groupBy = new ArrayList<>();
        private String across; private boolean hasSubTotals;
        private String source; private String pageName;
        public String getType() { return type; }
        public void setType(String t) { this.type = t; }
        public List<String> getFields() { return fields; }
        public List<String> getGroupBy() { return groupBy; }
        public String getAcross() { return across; }
        public void setAcross(String a) { this.across = a; }
        public boolean isHasSubTotals() { return hasSubTotals; }
        public void setHasSubTotals(boolean h) { this.hasSubTotals = h; }
        public String getSource() { return source; }
        public void setSource(String s) { this.source = s; }
        public String getPageName() { return pageName; }
        public void setPageName(String p) { this.pageName = p; }
    }

    // ═══════════════════════════════════════════════════════════════
    // Parameters (from ACCEPT/PROMPT → PBI Parameters/Slicers)
    // ═══════════════════════════════════════════════════════════════
    public static class ParameterDef {
        private String name;
        private String displayName;
        private String dataType;
        private String defaultValue;
        private List<String> allowedValues = new ArrayList<>();
        private String pbiType;          // Parameter, Slicer, Filter
        private String source;

        public String getName() { return name; }
        public void setName(String n) { this.name = n; }
        public String getDisplayName() { return displayName; }
        public void setDisplayName(String d) { this.displayName = d; }
        public String getDataType() { return dataType; }
        public void setDataType(String d) { this.dataType = d; }
        public String getDefaultValue() { return defaultValue; }
        public void setDefaultValue(String d) { this.defaultValue = d; }
        public List<String> getAllowedValues() { return allowedValues; }
        public String getPbiType() { return pbiType; }
        public void setPbiType(String p) { this.pbiType = p; }
        public String getSource() { return source; }
        public void setSource(String s) { this.source = s; }
    }

    // ═══════════════════════════════════════════════════════════════
    // Conditional Formatting (from SET STYLE WHEN → PBI Rules)
    // ═══════════════════════════════════════════════════════════════
    public static class ConditionalFormat {
        private String targetField;
        private String condition;
        private String backgroundColor;
        private String fontColor;
        private String icon;
        private String source;
        public String getTargetField() { return targetField; }
        public void setTargetField(String t) { this.targetField = t; }
        public String getCondition() { return condition; }
        public void setCondition(String c) { this.condition = c; }
        public String getBackgroundColor() { return backgroundColor; }
        public void setBackgroundColor(String b) { this.backgroundColor = b; }
        public String getFontColor() { return fontColor; }
        public void setFontColor(String f) { this.fontColor = f; }
        public String getIcon() { return icon; }
        public void setIcon(String i) { this.icon = i; }
        public String getSource() { return source; }
        public void setSource(String s) { this.source = s; }
    }

    public static class DrillThroughPage {
        private String pageName;
        private String sourceField;
        private String targetReport;
        private List<String> passedFilters = new ArrayList<>();
        public String getPageName() { return pageName; }
        public void setPageName(String p) { this.pageName = p; }
        public String getSourceField() { return sourceField; }
        public void setSourceField(String s) { this.sourceField = s; }
        public String getTargetReport() { return targetReport; }
        public void setTargetReport(String t) { this.targetReport = t; }
        public List<String> getPassedFilters() { return passedFilters; }
    }

    public static class BookmarkDef {
        private String name;
        private String description;
        private List<String> activeFilters = new ArrayList<>();
        public String getName() { return name; }
        public void setName(String n) { this.name = n; }
        public String getDescription() { return description; }
        public void setDescription(String d) { this.description = d; }
        public List<String> getActiveFilters() { return activeFilters; }
    }

    // ═══════════════════════════════════════════════════════════════
    // Paginated Report Definition (RDL structure)
    // ═══════════════════════════════════════════════════════════════
    public static class PaginatedReportDef {
        private String reportName;
        private PageSetup pageSetup = new PageSetup();
        private List<ReportParameter> parameters = new ArrayList<>();
        private List<DataSource> dataSources = new ArrayList<>();
        private List<DataSet> dataSets = new ArrayList<>();
        private ReportHeader header;
        private ReportFooter footer;
        private List<ReportBody> bodyItems = new ArrayList<>();
        private List<GroupDefinition> groups = new ArrayList<>();
        private boolean hasPageNumbers;
        private boolean hasRunDate;

        public String getReportName() { return reportName; }
        public void setReportName(String r) { this.reportName = r; }
        public PageSetup getPageSetup() { return pageSetup; }
        public List<ReportParameter> getParameters() { return parameters; }
        public List<DataSource> getDataSources() { return dataSources; }
        public List<DataSet> getDataSets() { return dataSets; }
        public ReportHeader getHeader() { return header; }
        public void setHeader(ReportHeader h) { this.header = h; }
        public ReportFooter getFooter() { return footer; }
        public void setFooter(ReportFooter f) { this.footer = f; }
        public List<ReportBody> getBodyItems() { return bodyItems; }
        public List<GroupDefinition> getGroups() { return groups; }
        public boolean isHasPageNumbers() { return hasPageNumbers; }
        public void setHasPageNumbers(boolean h) { this.hasPageNumbers = h; }
        public boolean isHasRunDate() { return hasRunDate; }
        public void setHasRunDate(boolean h) { this.hasRunDate = h; }
    }

    public static class PageSetup {
        private double pageWidth = 8.5;
        private double pageHeight = 11.0;
        private double marginTop = 0.5;
        private double marginBottom = 0.5;
        private double marginLeft = 0.75;
        private double marginRight = 0.75;
        private String orientation = "Portrait";  // Portrait / Landscape
        public double getPageWidth() { return pageWidth; }
        public void setPageWidth(double p) { this.pageWidth = p; }
        public double getPageHeight() { return pageHeight; }
        public void setPageHeight(double p) { this.pageHeight = p; }
        public double getMarginTop() { return marginTop; }
        public void setMarginTop(double m) { this.marginTop = m; }
        public double getMarginBottom() { return marginBottom; }
        public void setMarginBottom(double m) { this.marginBottom = m; }
        public double getMarginLeft() { return marginLeft; }
        public void setMarginLeft(double m) { this.marginLeft = m; }
        public double getMarginRight() { return marginRight; }
        public void setMarginRight(double m) { this.marginRight = m; }
        public String getOrientation() { return orientation; }
        public void setOrientation(String o) { this.orientation = o; }
    }

    public static class ReportParameter {
        private String name; private String prompt;
        private String dataType; private String defaultValue;
        private boolean allowMultiple; private boolean required;
        private List<String> validValues = new ArrayList<>();
        public String getName() { return name; }
        public void setName(String n) { this.name = n; }
        public String getPrompt() { return prompt; }
        public void setPrompt(String p) { this.prompt = p; }
        public String getDataType() { return dataType; }
        public void setDataType(String d) { this.dataType = d; }
        public String getDefaultValue() { return defaultValue; }
        public void setDefaultValue(String d) { this.defaultValue = d; }
        public boolean isAllowMultiple() { return allowMultiple; }
        public void setAllowMultiple(boolean a) { this.allowMultiple = a; }
        public boolean isRequired() { return required; }
        public void setRequired(boolean r) { this.required = r; }
        public List<String> getValidValues() { return validValues; }
    }

    public static class DataSource {
        private String name; private String connectionString;
        private String provider;
        public String getName() { return name; }
        public void setName(String n) { this.name = n; }
        public String getConnectionString() { return connectionString; }
        public void setConnectionString(String c) { this.connectionString = c; }
        public String getProvider() { return provider; }
        public void setProvider(String p) { this.provider = p; }
    }

    public static class DataSet {
        private String name; private String query; private String dataSourceRef;
        private List<DataField> fields = new ArrayList<>();
        public String getName() { return name; }
        public void setName(String n) { this.name = n; }
        public String getQuery() { return query; }
        public void setQuery(String q) { this.query = q; }
        public String getDataSourceRef() { return dataSourceRef; }
        public void setDataSourceRef(String d) { this.dataSourceRef = d; }
        public List<DataField> getFields() { return fields; }
    }

    public static class DataField {
        private String name; private String dataType;
        public DataField() {}
        public DataField(String n, String d) { this.name = n; this.dataType = d; }
        public String getName() { return name; }
        public void setName(String n) { this.name = n; }
        public String getDataType() { return dataType; }
        public void setDataType(String d) { this.dataType = d; }
    }

    public static class ReportHeader {
        private List<String> textLines = new ArrayList<>();
        private boolean showOnFirstPage; private boolean showOnEveryPage;
        public List<String> getTextLines() { return textLines; }
        public boolean isShowOnFirstPage() { return showOnFirstPage; }
        public void setShowOnFirstPage(boolean s) { this.showOnFirstPage = s; }
        public boolean isShowOnEveryPage() { return showOnEveryPage; }
        public void setShowOnEveryPage(boolean s) { this.showOnEveryPage = s; }
    }

    public static class ReportFooter {
        private List<String> textLines = new ArrayList<>();
        private boolean hasPageNumber; private boolean hasRunDate; private boolean hasTotalPages;
        public List<String> getTextLines() { return textLines; }
        public boolean isHasPageNumber() { return hasPageNumber; }
        public void setHasPageNumber(boolean h) { this.hasPageNumber = h; }
        public boolean isHasRunDate() { return hasRunDate; }
        public void setHasRunDate(boolean h) { this.hasRunDate = h; }
        public boolean isHasTotalPages() { return hasTotalPages; }
        public void setHasTotalPages(boolean h) { this.hasTotalPages = h; }
    }

    public static class ReportBody {
        private String type;  // Tablix, TextBox, Chart, SubReport, Image, Rectangle
        private String name;
        private Map<String, Object> properties = new LinkedHashMap<>();
        public String getType() { return type; }
        public void setType(String t) { this.type = t; }
        public String getName() { return name; }
        public void setName(String n) { this.name = n; }
        public Map<String, Object> getProperties() { return properties; }
    }

    public static class GroupDefinition {
        private String fieldName; private boolean hasHeader; private boolean hasFooter;
        private boolean pageBreakBefore; private boolean repeatHeaderOnNewPage;
        private List<String> subtotalExpressions = new ArrayList<>();
        public String getFieldName() { return fieldName; }
        public void setFieldName(String f) { this.fieldName = f; }
        public boolean isHasHeader() { return hasHeader; }
        public void setHasHeader(boolean h) { this.hasHeader = h; }
        public boolean isHasFooter() { return hasFooter; }
        public void setHasFooter(boolean h) { this.hasFooter = h; }
        public boolean isPageBreakBefore() { return pageBreakBefore; }
        public void setPageBreakBefore(boolean p) { this.pageBreakBefore = p; }
        public boolean isRepeatHeaderOnNewPage() { return repeatHeaderOnNewPage; }
        public void setRepeatHeaderOnNewPage(boolean r) { this.repeatHeaderOnNewPage = r; }
        public List<String> getSubtotalExpressions() { return subtotalExpressions; }
    }

    // ═══════════════════════════════════════════════════════════════
    // Self-Service Mapping (InfoAssist → PBI Self-Service)
    // ═══════════════════════════════════════════════════════════════
    public static class SelfServiceMapping {
        private String sourceToolType;
        private String targetReportType;       // Interactive, Paginated
        private List<String> enabledFeatures = new ArrayList<>();  // Filter, Sort, DrillDown, Export, Pivot
        private List<SlicerDef> slicers = new ArrayList<>();
        private boolean enableQA;              // Q&A natural language
        private boolean enableSubscriptions;
        public String getSourceToolType() { return sourceToolType; }
        public void setSourceToolType(String s) { this.sourceToolType = s; }
        public String getTargetReportType() { return targetReportType; }
        public void setTargetReportType(String t) { this.targetReportType = t; }
        public List<String> getEnabledFeatures() { return enabledFeatures; }
        public List<SlicerDef> getSlicers() { return slicers; }
        public boolean isEnableQA() { return enableQA; }
        public void setEnableQA(boolean e) { this.enableQA = e; }
        public boolean isEnableSubscriptions() { return enableSubscriptions; }
        public void setEnableSubscriptions(boolean e) { this.enableSubscriptions = e; }
    }

    public static class SlicerDef {
        private String fieldName; private String slicerType;
        private String defaultValue;
        public String getFieldName() { return fieldName; }
        public void setFieldName(String f) { this.fieldName = f; }
        public String getSlicerType() { return slicerType; }
        public void setSlicerType(String s) { this.slicerType = s; }
        public String getDefaultValue() { return defaultValue; }
        public void setDefaultValue(String d) { this.defaultValue = d; }
    }

    // ═══════════════════════════════════════════════════════════════
    // Dashboard Mapping (WF Composite → PBI Dashboard)
    // ═══════════════════════════════════════════════════════════════
    public static class DashboardMapping {
        private List<DashboardPage> pages = new ArrayList<>();
        private String sourceType;
        public List<DashboardPage> getPages() { return pages; }
        public String getSourceType() { return sourceType; }
        public void setSourceType(String s) { this.sourceType = s; }
    }

    public static class DashboardPage {
        private String name;
        private List<DashboardTile> tiles = new ArrayList<>();
        public String getName() { return name; }
        public void setName(String n) { this.name = n; }
        public List<DashboardTile> getTiles() { return tiles; }
    }

    public static class DashboardTile {
        private String title; private String visualType;
        private String sourceReport; private String sourceVisual;
        public String getTitle() { return title; }
        public void setTitle(String t) { this.title = t; }
        public String getVisualType() { return visualType; }
        public void setVisualType(String v) { this.visualType = v; }
        public String getSourceReport() { return sourceReport; }
        public void setSourceReport(String s) { this.sourceReport = s; }
        public String getSourceVisual() { return sourceVisual; }
        public void setSourceVisual(String s) { this.sourceVisual = s; }
    }

    // ═══════════════════════════════════════════════════════════════
    // Active Report Mapping (WF Active → PBI Interactive)
    // ═══════════════════════════════════════════════════════════════
    public static class ActiveReportMapping {
        private List<String> interactiveFilters = new ArrayList<>();
        private List<String> interactiveSorts = new ArrayList<>();
        private boolean hasPivot;
        private boolean hasRollup;
        private List<String> bookmarkStates = new ArrayList<>();
        private String targetType;
        public List<String> getInteractiveFilters() { return interactiveFilters; }
        public List<String> getInteractiveSorts() { return interactiveSorts; }
        public boolean isHasPivot() { return hasPivot; }
        public void setHasPivot(boolean h) { this.hasPivot = h; }
        public boolean isHasRollup() { return hasRollup; }
        public void setHasRollup(boolean h) { this.hasRollup = h; }
        public List<String> getBookmarkStates() { return bookmarkStates; }
        public String getTargetType() { return targetType; }
        public void setTargetType(String t) { this.targetType = t; }
    }

    // ═══════════════════════════════════════════════════════════════
    // Dataflow (from HOLD chains → PBI Dataflow)
    // ═══════════════════════════════════════════════════════════════
    public static class DataflowDef {
        private String name;
        private List<DataflowStep> steps = new ArrayList<>();
        public String getName() { return name; }
        public void setName(String n) { this.name = n; }
        public List<DataflowStep> getSteps() { return steps; }
    }

    public static class DataflowStep {
        private String name; private String type;
        private String mExpression; private String source;
        public String getName() { return name; }
        public void setName(String n) { this.name = n; }
        public String getType() { return type; }
        public void setType(String t) { this.type = t; }
        public String getMExpression() { return mExpression; }
        public void setMExpression(String m) { this.mExpression = m; }
        public String getSource() { return source; }
        public void setSource(String s) { this.source = s; }
    }

    // ═══════════════════════════════════════════════════════════════
    // Mapping & Issue tracking
    // ═══════════════════════════════════════════════════════════════
    public static class Mapping {
        private String source;
        private String target;
        private String status;      // Converted, Needs Review, Unsupported, Manual
        private String category;    // Measure, Column, Filter, Parameter, Style, Pagination, Relationship
        private String notes;

        public Mapping() {}
        public Mapping(String source, String target, String status) {
            this.source = source; this.target = target; this.status = status;
        }
        public Mapping(String source, String target, String status, String category) {
            this(source, target, status); this.category = category;
        }
        public String getSource() { return source; }
        public void setSource(String s) { this.source = s; }
        public String getTarget() { return target; }
        public void setTarget(String t) { this.target = t; }
        public String getStatus() { return status; }
        public void setStatus(String s) { this.status = s; }
        public String getCategory() { return category; }
        public void setCategory(String c) { this.category = c; }
        public String getNotes() { return notes; }
        public void setNotes(String n) { this.notes = n; }
    }

    public static class Issue {
        private String type; private String message; private int line;
        private String severity; // CRITICAL, WARNING, INFO
        public Issue() {}
        public Issue(String type, String message, int line) {
            this.type = type; this.message = message; this.line = line;
        }
        public String getType() { return type; }
        public void setType(String t) { this.type = t; }
        public String getMessage() { return message; }
        public void setMessage(String m) { this.message = m; }
        public int getLine() { return line; }
        public void setLine(int l) { this.line = l; }
        public String getSeverity() { return severity; }
        public void setSeverity(String s) { this.severity = s; }
    }
}
