const { useState, useCallback, useRef, useMemo, useEffect } = React;

const C = { bg: "#06070c", card: "#0d0e16", border: "#181a28", accent: "#4f46e5", accent2: "#7c3aed", green: "#10b981", yellow: "#fbbf24", red: "#f87171", text: "#c8c8d8", muted: "#55556a", white: "#fff" };
const FONT = "'JetBrains Mono','Fira Code','Cascadia Code',monospace";
const STATUS_COLORS = { Converted: { bg: "#0d3320", text: "#34d399", border: "#065f46" }, "Needs Review": { bg: "#3b2308", text: "#fbbf24", border: "#78350f" }, Manual: { bg: "#1e1a3a", text: "#a78bfa", border: "#4c1d95" }, Unsupported: { bg: "#3b0e0e", text: "#f87171", border: "#7f1d1d" } };
const CAT_COLORS = { Measure: "#6366f1", Column: "#10b981", Filter: "#f59e0b", Parameter: "#a855f7", Relationship: "#06b6d4", Style: "#ec4899", Pagination: "#f97316", DrillDown: "#14b8a6", SelfService: "#8b5cf6", ActiveReport: "#f43f5e", ETL: "#84cc16", Query: "#0ea5e9", DialogueManager: "#d946ef", Connection: "#22d3ee" };
const AGG_OPTIONS = ["SUM", "AVG", "MIN", "MAX", "COUNT"];
const VIS_TYPES = [{ id: "table", label: "Table", icon: "\u25A6" }, { id: "bar", label: "Bar", icon: "\u25AE" }, { id: "line", label: "Line", icon: "\u2307" }, { id: "pie", label: "Pie", icon: "\u25D5" }, { id: "area", label: "Area", icon: "\u25B2" }, { id: "matrix", label: "Matrix", icon: "\u229E" }];
const OP_OPTIONS = ["=", "<>", ">", "<", ">=", "<=", "LIKE", "IN"];

const s = {
  btn: function(v, sm) { v = v || "primary"; return { padding: sm ? "5px 12px" : "9px 18px", border: v === "primary" ? "none" : "1px solid " + C.border, borderRadius: "6px", background: v === "primary" ? "linear-gradient(135deg," + C.accent + "," + C.accent2 + ")" : v === "green" ? "linear-gradient(135deg,#059669," + C.green + ")" : "transparent", color: C.white, cursor: "pointer", fontSize: sm ? "11px" : "12px", fontWeight: "700", fontFamily: FONT, display: "inline-flex", alignItems: "center", gap: "5px", transition: "all 0.15s" }; },
  card: { background: C.card, border: "1px solid " + C.border, borderRadius: "10px", padding: "18px", marginBottom: "12px" },
  cardTitle: { fontSize: "13px", fontWeight: "800", marginBottom: "12px", color: C.white, display: "flex", alignItems: "center", gap: "8px" },
  input: { background: "#0a0b14", border: "1px solid " + C.border, borderRadius: "6px", padding: "7px 12px", color: C.text, fontSize: "12px", fontFamily: FONT, width: "100%", outline: "none" },
  select: { background: "#0a0b14", border: "1px solid " + C.border, borderRadius: "6px", padding: "7px 10px", color: C.text, fontSize: "12px", fontFamily: FONT, outline: "none", cursor: "pointer" },
  label: { fontSize: "10px", color: C.muted, fontWeight: "700", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: "4px", display: "block" },
  badge: function(st) { var c = STATUS_COLORS[st] || STATUS_COLORS.Unsupported; return { display: "inline-flex", padding: "2px 9px", borderRadius: "99px", fontSize: "10px", fontWeight: "700", fontFamily: FONT, background: c.bg, color: c.text, border: "1px solid " + c.border }; },
  catBadge: function(cat) { var col = CAT_COLORS[cat] || "#666"; return { display: "inline-flex", padding: "2px 8px", borderRadius: "99px", fontSize: "10px", fontWeight: "600", fontFamily: FONT, background: col + "18", color: col, border: "1px solid " + col + "40" }; },
  pill: function(a) { return { padding: "4px 12px", border: "none", borderRadius: "99px", background: a ? C.accent : "#151628", color: a ? C.white : "#6a6a80", cursor: "pointer", fontSize: "10px", fontWeight: "700", fontFamily: FONT }; },
  table: { width: "100%", borderCollapse: "collapse", fontSize: "11px" },
  th: { textAlign: "left", padding: "8px 10px", borderBottom: "1px solid " + C.border, color: C.muted, fontWeight: "700", fontSize: "10px", textTransform: "uppercase", letterSpacing: "0.05em" },
  td: { padding: "8px 10px", borderBottom: "1px solid #0e0f18", verticalAlign: "top" },
  code: { background: "#08091a", border: "1px solid " + C.border, borderRadius: "8px", padding: "14px", fontSize: "11px", lineHeight: "1.7", overflow: "auto", maxHeight: "400px", whiteSpace: "pre-wrap", fontFamily: FONT, color: "#a0a0c0" },
  scroll: { maxHeight: "500px", overflowY: "auto" },
  fileItem: { display: "flex", justifyContent: "space-between", alignItems: "center", padding: "9px 12px", background: "#0a0b14", borderRadius: "8px", marginBottom: "5px", border: "1px solid " + C.border },
  fileIcon: function(t) { return { width: "28px", height: "28px", borderRadius: "5px", background: t === "mas" ? "linear-gradient(135deg,#059669,#10b981)" : "linear-gradient(135deg," + C.accent + "," + C.accent2 + ")", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "9px", fontWeight: "900", color: C.white }; },
  progressBar: { height: "5px", background: "#1a1a30", borderRadius: "3px", overflow: "hidden" },
  progressFill: function(p) { return { height: "100%", width: p + "%", background: p > 70 ? "linear-gradient(90deg,#10b981,#34d399)" : p > 40 ? "linear-gradient(90deg,#f59e0b,#fbbf24)" : "linear-gradient(90deg,#ef4444,#f87171)", borderRadius: "3px", transition: "width 0.4s" }; },
  chip: { display: "inline-flex", alignItems: "center", gap: "4px", padding: "4px 10px", borderRadius: "6px", fontSize: "11px", fontWeight: "600", fontFamily: FONT, background: C.accent + "20", color: C.accent, border: "1px solid " + C.accent + "40", cursor: "default" },
  removeBtn: { background: "none", border: "none", color: C.muted, cursor: "pointer", fontSize: "13px", padding: "0 2px", fontFamily: FONT },
  zoneTitle: { fontSize: "10px", color: C.accent2, fontWeight: "800", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: "6px" },
  sectionLabel: { fontSize: "10px", fontWeight: "800", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: "6px" },
};

// ═══════════════════════════════════════════════════════════════
function App() {
  const [mode, setMode] = useState("migration");
  const [backendOk, setBackendOk] = useState(null);
  useEffect(function() { API.healthCheck().then(function(d) { setBackendOk(!!d); }).catch(function() { setBackendOk(false); }); }, []);

  return (
    <div style={{ fontFamily: FONT, background: C.bg, color: C.text, minHeight: "100vh", display: "flex", flexDirection: "column" }}>
      <div style={{ background: "linear-gradient(135deg,#0a0b18,#10071f)", borderBottom: "1px solid " + C.border, padding: "12px 24px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
          <div style={{ width: "36px", height: "36px", background: "linear-gradient(135deg," + C.accent + "," + C.accent2 + ")", borderRadius: "9px", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: "900", fontSize: "13px", color: C.white }}>WF</div>
          <div><div style={{ fontSize: "14px", fontWeight: "800", color: C.white }}>WebFocus → Power BI</div><div style={{ fontSize: "10px", color: C.accent2, fontWeight: "600", letterSpacing: "0.05em" }}>MIGRATION & SELF-SERVICE PLATFORM v4.0</div></div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: "4px" }}>
          <div style={{ display: "flex", background: "#0c0d18", borderRadius: "8px", padding: "3px", marginRight: "12px" }}>
            {[{ id: "migration", label: "\u21C4 Migration", bg: C.accent }, { id: "selfservice", label: "\u2605 Self-Service", bg: "linear-gradient(135deg,#059669," + C.green + ")" }].map(function(m) {
              return <button key={m.id} onClick={function() { setMode(m.id); }} style={{ padding: "8px 18px", border: "none", borderRadius: "6px", background: mode === m.id ? m.bg : "transparent", color: mode === m.id ? C.white : C.muted, cursor: "pointer", fontSize: "12px", fontWeight: "700", fontFamily: FONT }}>{m.label}</button>;
            })}
          </div>
          {backendOk !== null && <span style={{ fontSize: "10px", color: backendOk ? C.green : C.red, fontWeight: "600" }}>{backendOk ? "\u25CF Connected" : "\u25CB Offline"}</span>}
        </div>
      </div>
      <div style={{ flex: 1, padding: "20px 24px", maxWidth: "1300px", margin: "0 auto", width: "100%" }}>
        {mode === "migration" ? <MigrationModule /> : <SelfServiceModule />}
      </div>
      <div style={{ borderTop: "1px solid " + C.border, padding: "8px 24px", fontSize: "10px", color: "#2a2a3a", textAlign: "center" }}>WebFocus 7/8 → Power BI Report Server (On-Prem)</div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// MIGRATION MODULE — FULL VERSION WITH ALL TABS
// ═══════════════════════════════════════════════════════════════
function MigrationModule() {
  const [tab, setTab] = useState("upload");
  const [files, setFiles] = useState([]);
  const [response, setResponse] = useState(null);
  const [processing, setProcessing] = useState(false);
  const [rdlGen, setRdlGen] = useState(false);
  const [error, setError] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [filterCat, setFilterCat] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [outputView, setOutputView] = useState("dax");
  const fileRef = useRef(null);

  const conversions = response && response.conversions ? response.conversions : [];
  const summary = response && response.summary ? response.summary : {};
  const featureCoverage = response && response.featureCoverage ? response.featureCoverage : {};

  const allMappings = useMemo(function() {
    var r = [];
    conversions.forEach(function(c) { (c.mappings || []).forEach(function(m) { r.push(Object.assign({}, m, { fileName: c.sourceFile, classification: c.sourceClassification })); }); });
    return r;
  }, [conversions]);

  const filteredMappings = useMemo(function() { return allMappings.filter(function(m) { return (filterCat === "all" || m.category === filterCat) && (filterStatus === "all" || m.status === filterStatus); }); }, [allMappings, filterCat, filterStatus]);
  const categories = useMemo(function() { var st = new Set(); allMappings.forEach(function(m) { if (m.category) st.add(m.category); }); return ["all"].concat(Array.from(st).sort()); }, [allMappings]);

  const handleFiles = useCallback(function(fl) {
    var arr = Array.from(fl).filter(function(f) { return f.name.match(/\.(fex|mas|focexec|txt)$/i); });
    if (!arr.length) { setError("Upload .fex, .mas, .focexec, or .txt files"); return; }
    setFiles(function(prev) { return prev.concat(arr); }); setError(null);
  }, []);
  const analyze = useCallback(function() { setProcessing(true); setError(null); API.analyzeMigration(files).then(function(r) { setResponse(r); setTab("analysis"); }).catch(function(e) { setError(e.message); }).finally(function() { setProcessing(false); }); }, [files]);
  const genRdl = useCallback(function() { setRdlGen(true); setError(null); API.generateRdlBundle(files).catch(function(e) { setError(e.message); }).finally(function() { setRdlGen(false); }); }, [files]);

  var TABS = [{ id: "upload", label: "Upload", icon: "\u2191" }, { id: "analysis", label: "Analysis", icon: "\u25CE" }, { id: "mappings", label: "Mappings", icon: "\u21C4" }, { id: "features", label: "Features", icon: "\u2605" }, { id: "output", label: "Output", icon: "\u25C6" }, { id: "export", label: "Export", icon: "\u2193" }];

  return (<div>
    <div style={{ display: "flex", gap: "2px", background: "#0c0d18", borderRadius: "8px", padding: "3px", marginBottom: "14px" }}>
      {TABS.map(function(t) { return <button key={t.id} style={{ padding: "7px 14px", border: "none", borderRadius: "6px", background: tab === t.id ? C.accent : "transparent", color: tab === t.id ? C.white : C.muted, cursor: "pointer", fontSize: "11px", fontWeight: "700", fontFamily: FONT, display: "flex", alignItems: "center", gap: "5px" }} onClick={function() { setTab(t.id); }}>
        <span>{t.icon}</span><span>{t.label}</span>
        {t.id === "mappings" && allMappings.length > 0 && <span style={{ background: C.accent2, color: C.white, borderRadius: "99px", padding: "0 5px", fontSize: "9px", fontWeight: "900" }}>{allMappings.length}</span>}
      </button>; })}
    </div>
    {error && <div style={Object.assign({}, s.card, { background: "#1a0808", borderColor: "#3b1010", color: C.red, fontSize: "12px" })}>{error}</div>}

    {/* UPLOAD */}
    {tab === "upload" && <div>
      <div style={s.card}>
        <div style={s.cardTitle}>{"\u2191"} Upload WebFocus Files</div>
        <div style={{ border: "2px dashed " + C.border, borderRadius: "10px", padding: "36px", textAlign: "center", cursor: "pointer" }}
          onDrop={function(e) { e.preventDefault(); handleFiles(e.dataTransfer.files); }} onDragOver={function(e) { e.preventDefault(); }} onClick={function() { fileRef.current && fileRef.current.click(); }}>
          <div style={{ fontSize: "24px", opacity: 0.4, marginBottom: "6px" }}>{"\u2B06"}</div>
          <div style={{ fontSize: "13px", fontWeight: "700", color: C.white }}>Drop .fex / .mas files or click to browse</div>
          <input ref={fileRef} type="file" multiple accept=".fex,.mas,.focexec,.txt" style={{ display: "none" }} onChange={function(e) { handleFiles(e.target.files); }} />
        </div>
      </div>
      {files.length > 0 && <div style={s.card}>
        <div style={s.cardTitle}>{"\u25C6"} Queued ({files.length})</div>
        {files.map(function(f, i) { var ext = f.name.split(".").pop().toLowerCase(); return <div key={i} style={s.fileItem}>
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <div style={s.fileIcon(ext)}>{ext.toUpperCase()}</div>
            <div><div style={{ fontWeight: "700", color: C.white, fontSize: "12px" }}>{f.name}</div><div style={{ fontSize: "10px", color: C.muted }}>{(f.size / 1024).toFixed(1)} KB</div></div>
          </div>
          <button style={s.removeBtn} onClick={function() { setFiles(function(prev) { return prev.filter(function(_, j) { return j !== i; }); }); }}>{"\u2715"}</button>
        </div>; })}
        <div style={{ marginTop: "12px", display: "flex", gap: "8px", flexWrap: "wrap" }}>
          <button style={Object.assign({}, s.btn("green"), { padding: "12px 24px", fontSize: "13px" })} onClick={genRdl} disabled={rdlGen}>{rdlGen ? "\u27F3 Generating..." : "\u2B07 Generate RDL Bundle (ZIP)"}</button>
          <button style={s.btn()} onClick={analyze} disabled={processing}>{processing ? "\u27F3 Analyzing..." : "\u25CE Analyze & Preview"}</button>
          <button style={s.btn("secondary")} onClick={function() { setFiles([]); setResponse(null); }}>Clear</button>
        </div>
      </div>}
    </div>}

    {/* ANALYSIS */}
    {tab === "analysis" && (!response ? <div style={Object.assign({}, s.card, { textAlign: "center", padding: "40px", color: C.muted })}>Upload and analyze files first</div> : <div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(130px, 1fr))", gap: "8px", marginBottom: "14px" }}>
        {[{ v: summary.totalFiles, l: "Files", c: C.accent }, { v: summary.totalMappings, l: "Mappings", c: C.accent2 }, { v: summary.convertedMappings, l: "Converted", c: C.green }, { v: summary.reviewMappings, l: "Review", c: C.yellow }, { v: summary.unsupportedMappings || 0, l: "Manual", c: "#a78bfa" }, { v: summary.avgConfidence + "%", l: "Confidence", c: summary.avgConfidence > 70 ? C.green : C.yellow }].map(function(st, i) {
          return <div key={i} style={{ background: "#0a0b14", border: "1px solid " + C.border, borderRadius: "8px", padding: "12px", textAlign: "center" }}>
            <div style={{ fontSize: "24px", fontWeight: "900", color: st.c }}>{st.v}</div>
            <div style={{ fontSize: "9px", color: C.muted, textTransform: "uppercase", letterSpacing: "0.06em", marginTop: "2px" }}>{st.l}</div>
          </div>;
        })}
      </div>
      {summary.byClassification && Object.keys(summary.byClassification).length > 0 && <div style={s.card}>
        <div style={s.cardTitle}>{"\u25CE"} Report Classifications</div>
        <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
          {Object.entries(summary.byClassification).map(function(e) { return <div key={e[0]} style={{ background: "#08091a", border: "1px solid " + C.border, borderRadius: "8px", padding: "10px 16px", textAlign: "center" }}>
            <div style={{ fontSize: "18px", fontWeight: "900", color: C.white }}>{e[1]}</div><div style={{ fontSize: "10px", color: C.accent2, fontWeight: "600" }}>{e[0]}</div>
          </div>; })}
        </div>
      </div>}
      <div style={s.card}>
        <div style={s.cardTitle}>{"\u25CE"} Per-File Analysis</div>
        {conversions.map(function(c, ci) { return <div key={ci} style={{ background: selectedFile === ci ? "#141428" : "#0a0b14", border: "1px solid " + (selectedFile === ci ? C.accent : C.border), borderRadius: "8px", padding: "12px", marginBottom: "6px", cursor: "pointer" }} onClick={function() { setSelectedFile(selectedFile === ci ? null : ci); }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
              <div style={s.fileIcon(c.sourceType === "Master File" ? "mas" : "fex")}>{c.sourceType === "Master File" ? "MAS" : "FEX"}</div>
              <div><div style={{ fontWeight: "700", color: C.white, fontSize: "12px" }}>{c.sourceFile}</div>
                <div style={{ fontSize: "10px", color: C.muted }}>{c.sourceClassification || c.sourceType} \u00B7 {c.mappings.length} mappings</div></div>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
              <div style={Object.assign({}, s.progressBar, { width: "70px" })}><div style={s.progressFill(c.confidence)} /></div>
              <span style={{ fontSize: "11px", color: C.muted, fontWeight: "700" }}>{c.confidence}%</span>
            </div>
          </div>
          {selectedFile === ci && <div style={{ marginTop: "12px", borderTop: "1px solid " + C.border, paddingTop: "12px" }}>
            <div style={Object.assign({}, s.scroll, { maxHeight: "300px" })}>
              <table style={s.table}><thead><tr><th style={s.th}>Category</th><th style={s.th}>Source</th><th style={s.th}>Target</th><th style={s.th}>Status</th></tr></thead><tbody>
                {c.mappings.map(function(m, mi) { return <tr key={mi}>
                  <td style={s.td}><span style={s.catBadge(m.category)}>{m.category || "\u2014"}</span></td>
                  <td style={Object.assign({}, s.td, { color: "#b4b4c8", maxWidth: "260px", wordBreak: "break-word", fontSize: "10px" })}>{m.source}</td>
                  <td style={Object.assign({}, s.td, { color: C.accent, maxWidth: "260px", wordBreak: "break-word", fontSize: "10px" })}>{m.target}</td>
                  <td style={s.td}><span style={s.badge(m.status)}>{m.status}</span></td>
                </tr>; })}
              </tbody></table>
            </div>
          </div>}
        </div>; })}
      </div>
    </div>)}

    {/* MAPPINGS */}
    {tab === "mappings" && (!response ? <div style={Object.assign({}, s.card, { textAlign: "center", padding: "40px", color: C.muted })}>No data yet</div> : <div>
      <div style={{ display: "flex", gap: "4px", flexWrap: "wrap", marginBottom: "8px" }}>
        <span style={{ fontSize: "10px", color: C.muted, fontWeight: "700", padding: "5px 0" }}>STATUS:</span>
        {["all", "Converted", "Needs Review", "Manual"].map(function(st) { return <button key={st} style={s.pill(filterStatus === st)} onClick={function() { setFilterStatus(st); }}>{st === "all" ? "All" : st}</button>; })}
      </div>
      <div style={{ display: "flex", gap: "4px", flexWrap: "wrap", marginBottom: "8px" }}>
        <span style={{ fontSize: "10px", color: C.muted, fontWeight: "700", padding: "5px 0" }}>CATEGORY:</span>
        {categories.map(function(cat) { return <button key={cat} style={s.pill(filterCat === cat)} onClick={function() { setFilterCat(cat); }}>{cat === "all" ? "All" : cat}</button>; })}
      </div>
      <div style={{ fontSize: "11px", color: C.muted, marginBottom: "10px" }}>Showing {filteredMappings.length} of {allMappings.length}</div>
      <div style={s.card}><div style={Object.assign({}, s.scroll, { maxHeight: "600px" })}>
        <table style={s.table}><thead><tr><th style={s.th}>File</th><th style={s.th}>Cat</th><th style={s.th}>WebFocus Source</th><th style={s.th}>Power BI Target</th><th style={s.th}>Status</th></tr></thead><tbody>
          {filteredMappings.map(function(m, i) { return <tr key={i}>
            <td style={Object.assign({}, s.td, { fontSize: "10px", color: C.muted, whiteSpace: "nowrap" })}>{m.fileName}</td>
            <td style={s.td}><span style={s.catBadge(m.category)}>{m.category || "\u2014"}</span></td>
            <td style={Object.assign({}, s.td, { color: "#b4b4c8", maxWidth: "240px", wordBreak: "break-word", fontSize: "10px" })}>{m.source}</td>
            <td style={Object.assign({}, s.td, { color: C.accent, maxWidth: "240px", wordBreak: "break-word", fontSize: "10px" })}>{m.target}</td>
            <td style={s.td}><span style={s.badge(m.status)}>{m.status}</span></td>
          </tr>; })}
        </tbody></table>
      </div></div>
    </div>)}

    {/* FEATURES */}
    {tab === "features" && (!response ? <div style={Object.assign({}, s.card, { textAlign: "center", padding: "40px", color: C.muted })}>No data yet</div> : <div style={s.card}>
      <div style={s.cardTitle}>{"\u2605"} Feature Detection</div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px" }}>
        {[{ key: "paginatedReports", label: "Paginated Reports", desc: "PAGE-BREAK, HEADING/FOOTING, page numbering \u2192 PBI Paginated (RDL)" }, { key: "selfService", label: "Self-Service", desc: "InfoAssist, Report Painter \u2192 PBI Interactive Report" }, { key: "activeReports", label: "Active Reports", desc: "ARVERSION, HOLDLIST \u2192 PBI with Bookmarks & Slicers" }, { key: "dashboards", label: "Dashboards", desc: "HTML Composite, -HTMLFORM \u2192 PBI Dashboard" }, { key: "parameters", label: "Parameters", desc: "ACCEPT, PROMPT, -SET \u2192 PBI Parameters & Slicers" }, { key: "conditionalFormatting", label: "Conditional Formatting", desc: "SET STYLE WHEN \u2192 PBI conditional formatting" }, { key: "drillDown", label: "Drill-Down", desc: "FOCEXEC hyperlinks \u2192 PBI Drill-through" }, { key: "crossTab", label: "Cross-Tab (ACROSS)", desc: "ACROSS \u2192 PBI Matrix visual" }, { key: "holdChains", label: "HOLD Chains / ETL", desc: "Multi-step HOLD \u2192 PBI Dataflow" }, { key: "dialogueManager", label: "Dialogue Manager", desc: "-IF/-GOTO/-RUN \u2192 Power Automate" }].map(function(f) {
          var on = featureCoverage[f.key];
          return <div key={f.key} style={{ background: on ? "#0d1a14" : "#0a0b14", border: "1px solid " + (on ? "#065f46" : C.border), borderRadius: "8px", padding: "12px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "6px" }}>
              <span style={{ width: "8px", height: "8px", borderRadius: "50%", background: on ? C.green : "#333", display: "inline-block" }} />
              <span style={{ fontSize: "12px", fontWeight: "800", color: on ? C.green : C.muted }}>{f.label}</span>
              <span style={{ fontSize: "10px", color: on ? C.green : "#444", marginLeft: "auto" }}>{on ? "DETECTED" : "Not found"}</span>
            </div>
            <div style={{ fontSize: "10px", color: "#6a6a80", lineHeight: "1.5" }}>{f.desc}</div>
          </div>;
        })}
      </div>
    </div>)}

    {/* OUTPUT */}
    {tab === "output" && (!response ? <div style={Object.assign({}, s.card, { textAlign: "center", padding: "40px", color: C.muted })}>No output yet</div> : <div>
      <div style={{ display: "flex", gap: "4px", flexWrap: "wrap", marginBottom: "12px" }}>
        {[{ id: "dax", l: "DAX Measures" }, { id: "mquery", l: "Power Query M" }, { id: "params", l: "Parameters" }, { id: "report", l: "Full Report" }].map(function(v) { return <button key={v.id} style={s.pill(outputView === v.id)} onClick={function() { setOutputView(v.id); }}>{v.l}</button>; })}
      </div>
      <div style={s.card}>
        {outputView === "dax" && <pre style={s.code}>{conversions.flatMap(function(c) { return ["// \u2500\u2500 " + c.sourceFile + " \u2500\u2500"].concat((c.powerBI && c.powerBI.measures || []).map(function(m) { return m.name + " = " + m.expression; })).concat([""]); }).join("\n")}</pre>}
        {outputView === "mquery" && <pre style={s.code}>{conversions.flatMap(function(c) { return (c.powerBI && c.powerBI.queries || []).map(function(q) { return "// " + q.name + "\n" + q.expression + "\n"; }); }).join("\n")}</pre>}
        {outputView === "params" && <div style={s.scroll}><table style={s.table}><thead><tr><th style={s.th}>Name</th><th style={s.th}>Type</th><th style={s.th}>Default</th><th style={s.th}>Source</th></tr></thead><tbody>
          {conversions.flatMap(function(c) { return c.powerBI && c.powerBI.parameters || []; }).map(function(p, i) { return <tr key={i}><td style={Object.assign({}, s.td, { color: C.white, fontWeight: "600" })}>{p.name}</td><td style={s.td}>{p.dataType}</td><td style={s.td}>{p.defaultValue || "\u2014"}</td><td style={Object.assign({}, s.td, { fontSize: "10px", color: C.muted })}>{p.source}</td></tr>; })}
        </tbody></table></div>}
        {outputView === "report" && <pre style={s.code}>{(function() { var l = ["MIGRATION REPORT", "=".repeat(60), ""]; conversions.forEach(function(c) { l.push("\u2501\u2501 " + c.sourceFile + " (" + c.sourceType + ") \u2501\u2501"); l.push("Confidence: " + c.confidence + "%"); c.mappings.forEach(function(m) { var ic = m.status === "Converted" ? "\u2713" : "\u26A0"; l.push("  " + ic + " [" + (m.category || "?") + "] " + m.source); l.push("    \u2192 " + m.target); }); l.push(""); }); return l.join("\n"); })()}</pre>}
      </div>
    </div>)}

    {/* EXPORT */}
    {tab === "export" && (!response ? <div style={Object.assign({}, s.card, { textAlign: "center", padding: "40px", color: C.muted })}>Nothing to export</div> : <div style={s.card}>
      <div style={s.cardTitle}>{"\u2193"} Export</div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px" }}>
        {[{ icon: "\u2605", label: "RDL Report Bundle (ZIP)", desc: "All .rdl files organized by type", primary: true, action: function() { API.generateRdlBundle(files); } },
          { icon: "\u2B27", label: "DAX Script", desc: "Measures, calculated columns", action: function() { API.exportDAX(conversions); } },
          { icon: "\u2B27", label: "Power Query M", desc: "M expressions, transforms", action: function() { API.exportMQuery(conversions); } },
          { icon: "\u2B27", label: "Migration Report", desc: "Full mapping report", action: function() { API.exportReport(response); } },
          { icon: "\u2B27", label: "Full JSON", desc: "Complete export", action: function() { API.downloadJSON(response, "migration_export.json"); } }
        ].map(function(e, i) { return <button key={i} style={{ background: e.primary ? "linear-gradient(135deg,#059669," + C.green + ")" : "#0a0b14", border: "1px solid " + (e.primary ? C.green : C.border), borderRadius: "8px", padding: e.primary ? "18px" : "14px", cursor: "pointer", textAlign: "left", fontFamily: FONT, gridColumn: e.primary ? "1 / -1" : undefined }} onClick={e.action}>
          <div style={{ fontSize: e.primary ? "14px" : "12px", fontWeight: "800", color: C.white, marginBottom: "3px" }}>{e.icon} {e.label}</div>
          <div style={{ fontSize: "10px", color: e.primary ? "#d1fae5" : C.muted }}>{e.desc}</div>
        </button>; })}
      </div>
    </div>)}
  </div>);
}

// ═══════════════════════════════════════════════════════════════
// SELF-SERVICE MODULE
// ═══════════════════════════════════════════════════════════════
function SelfServiceModule() {
  const [catalog, setCatalog] = useState(null);
  const [capabilities, setCapabilities] = useState(null);
  const [selectedTable, setSelectedTable] = useState("");
  const [title, setTitle] = useState("My Report");
  const [measures, setMeasures] = useState([]);
  const [groupBy, setGroupBy] = useState([]);
  const [columns, setColumns] = useState([]);
  const [filters, setFilters] = useState([]);
  const [visType, setVisType] = useState("table");
  const [subtotals, setSubtotals] = useState(false);
  const [columnTotals, setColumnTotals] = useState(false);
  const [pageBreakOn, setPageBreakOn] = useState("");
  const [sortField, setSortField] = useState("");
  const [sortDir, setSortDir] = useState("ASC");
  const [reportFormat, setReportFormat] = useState("HTML5");
  const [preview, setPreview] = useState(null);
  const [renderedHtml, setRenderedHtml] = useState(null);
  const [renderMode, setRenderMode] = useState(null);
  const [generating, setGenerating] = useState(false);
  const [rendering, setRendering] = useState(false);
  const [savedReports, setSavedReports] = useState([]);
  const [saveName, setSaveName] = useState("");
  const [editingId, setEditingId] = useState(null);
  const [error, setError] = useState(null);
  const [panel, setPanel] = useState("builder");

  useEffect(function() { API.getCatalog().then(setCatalog).catch(function(e) { setError(e.message); }); API.getCapabilities().then(setCapabilities).catch(function() {}); API.listSavedReports().then(setSavedReports).catch(function() {}); }, []);

  const tableFields = useMemo(function() { if (!catalog || !selectedTable) return []; var t = catalog.tables.find(function(t) { return t.name === selectedTable; }); return t ? t.fields : []; }, [catalog, selectedTable]);
  const measureFields = useMemo(function() { return tableFields.filter(function(f) { return f.usage === "measure" || f.dataType === "Integer" || f.dataType === "Decimal"; }); }, [tableFields]);
  const dimensionFields = useMemo(function() { return tableFields.filter(function(f) { return f.usage === "dimension" || f.dataType === "String"; }); }, [tableFields]);
  const buildDef = useCallback(function() { return { title: title, dataSource: selectedTable, measures: measures.map(function(m) { return { field: m.field, aggregation: m.aggregation, alias: m.alias || null }; }), groupBy: groupBy, columns: columns, filters: filters.filter(function(f) { return f.field && f.value; }), options: { visualType: visType, subtotals: subtotals, columnTotals: columnTotals, pageBreakOn: pageBreakOn || null, sortField: sortField || null, sortDirection: sortDir } }; }, [title, selectedTable, measures, groupBy, columns, filters, visType, subtotals, columnTotals, pageBreakOn, sortField, sortDir]);
  const canGen = selectedTable && (measures.length > 0 || groupBy.length > 0);

  const handleGenerateReport = useCallback(function() { setRendering(true); setError(null); setRenderedHtml(null); API.generateReport(buildDef(), reportFormat).then(function(r) { if (r.html) { setRenderedHtml(r.html); setRenderMode(r.mode); } else setRenderMode(r.mode); }).catch(function(e) { setError(e.message); }).finally(function() { setRendering(false); }); }, [buildDef, reportFormat]);
  const handleGenerateRdl = useCallback(function() { setGenerating(true); setError(null); API.generateSelfServiceRdl(buildDef()).catch(function(e) { setError(e.message); }).finally(function() { setGenerating(false); }); }, [buildDef]);
  const handlePreview = useCallback(function() { setError(null); API.previewReport(buildDef()).then(setPreview).catch(function(e) { setError(e.message); }); }, [buildDef]);
  const handleSave = useCallback(function() { if (!saveName.trim()) { setError("Enter a report name"); return; } setError(null); var prom = editingId ? API.updateReport(editingId, saveName, buildDef()) : API.saveReport(saveName, buildDef()); prom.then(function(sv) { if (editingId) { setSavedReports(function(prev) { return prev.map(function(r) { return r.id === editingId ? sv : r; }); }); setEditingId(null); } else { setSavedReports(function(prev) { return [sv].concat(prev); }); } setSaveName(""); }).catch(function(e) { setError(e.message); }); }, [saveName, editingId, buildDef]);
  const loadReport = useCallback(function(sr) { var d = sr.definition; setTitle(d.title || ""); setSelectedTable(d.dataSource || ""); setMeasures(d.measures || []); setGroupBy(d.groupBy || []); setColumns(d.columns || []); setFilters(d.filters || []); setVisType(d.options && d.options.visualType || "table"); setSubtotals(d.options && d.options.subtotals || false); setColumnTotals(d.options && d.options.columnTotals || false); setPageBreakOn(d.options && d.options.pageBreakOn || ""); setSortField(d.options && d.options.sortField || ""); setSortDir(d.options && d.options.sortDirection || "ASC"); setSaveName(sr.name); setEditingId(sr.id); setPanel("builder"); setPreview(null); setRenderedHtml(null); }, []);
  const runSaved = useCallback(function(id, fmt) { setRendering(true); setError(null); setRenderedHtml(null); setPanel("builder"); API.runSavedReportRendered(id, fmt).then(function(r) { if (r.html) { setRenderedHtml(r.html); setRenderMode(r.mode); } }).catch(function(e) { setError(e.message); }).finally(function() { setRendering(false); }); }, []);
  const resetForm = function() { setTitle("My Report"); setSelectedTable(""); setMeasures([]); setGroupBy([]); setColumns([]); setFilters([]); setVisType("table"); setSubtotals(false); setColumnTotals(false); setPageBreakOn(""); setSortField(""); setSortDir("ASC"); setSaveName(""); setEditingId(null); setPreview(null); setRenderedHtml(null); };

  return (<div>
    {error && <div style={Object.assign({}, s.card, { background: "#1a0808", borderColor: "#3b1010", color: C.red, fontSize: "12px" })}>{error}</div>}
    {capabilities && <div style={Object.assign({}, s.card, { padding: "10px 16px", display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: "11px" })}><span>Render: <strong style={{ color: capabilities.renderMode === "ReportServer" ? C.green : C.yellow }}>{capabilities.renderMode}</strong></span><span>Formats: {capabilities.availableFormats && capabilities.availableFormats.join(", ")}</span></div>}
    <div style={{ display: "flex", gap: "4px", marginBottom: "14px" }}>
      {[{ id: "builder", l: "\u2605 Report Builder" }, { id: "saved", l: "\u25C6 Saved Reports (" + savedReports.length + ")" }].map(function(p) { return <button key={p.id} style={Object.assign({}, s.btn(panel === p.id ? "primary" : "secondary", true), { padding: "7px 16px" })} onClick={function() { setPanel(p.id); }}>{p.l}</button>; })}
      {editingId && <span style={{ fontSize: "11px", color: C.yellow, padding: "8px", fontWeight: "600" }}>Editing: {saveName}</span>}
      {editingId && <button style={s.btn("secondary", true)} onClick={resetForm}>+ New Report</button>}
    </div>

    {panel === "builder" && <div style={{ display: "grid", gridTemplateColumns: "250px 1fr", gap: "14px" }}>
      {/* CATALOG */}
      <div><div style={s.card}>
        <div style={s.zoneTitle}>Data Source</div>
        <select style={Object.assign({}, s.select, { width: "100%", marginBottom: "10px" })} value={selectedTable} onChange={function(e) { setSelectedTable(e.target.value); setMeasures([]); setGroupBy([]); setColumns([]); setFilters([]); setPreview(null); setRenderedHtml(null); }}><option value="">Select a table...</option>{catalog && catalog.tables.map(function(t) { return <option key={t.name} value={t.name}>{t.displayName || t.name}</option>; })}</select>
        {selectedTable && <div>
          <div style={s.zoneTitle}>Measures</div>
          <div style={{ marginBottom: "10px" }}>{measureFields.map(function(f) { var on = measures.find(function(m) { return m.field === f.name; }); return <div key={f.name} onClick={function() { if (!on) setMeasures(function(prev) { return prev.concat([{ field: f.name, aggregation: "SUM", alias: "" }]); }); }} style={{ padding: "5px 8px", fontSize: "11px", cursor: "pointer", borderRadius: "4px", marginBottom: "2px", color: on ? C.green : C.text, background: on ? C.green + "10" : "transparent" }}>{on ? "\u2713 " : "\uFF0B "}{f.displayName} <span style={{ color: C.muted }}>({f.dataType})</span></div>; })}</div>
          <div style={s.zoneTitle}>Dimensions</div>
          <div style={{ marginBottom: "10px" }}>{dimensionFields.map(function(f) { var on = groupBy.includes(f.name); return <div key={f.name} onClick={function() { if (!on) setGroupBy(function(prev) { return prev.concat([f.name]); }); }} style={{ padding: "5px 8px", fontSize: "11px", cursor: "pointer", borderRadius: "4px", marginBottom: "2px", color: on ? C.accent2 : C.text, background: on ? C.accent2 + "10" : "transparent" }}>{on ? "\u2713 " : "\uFF0B "}{f.displayName}</div>; })}</div>
          <button style={Object.assign({}, s.btn("secondary", true), { width: "100%", justifyContent: "center", fontSize: "10px" })} onClick={function() { var inp = document.createElement("input"); inp.type = "file"; inp.accept = ".mas"; inp.onchange = function(e) { if (e.target.files[0]) API.importMasterFile(e.target.files[0]).then(function() { return API.getCatalog(); }).then(setCatalog).catch(function(err) { setError(err.message); }); }; inp.click(); }}>+ Import .mas file</button>
        </div>}
      </div></div>

      {/* BUILDER */}
      <div>
        <div style={s.card}><div style={{ display: "flex", gap: "10px", alignItems: "center" }}><div style={{ flex: 1 }}><label style={s.label}>Report Title</label><input style={s.input} value={title} onChange={function(e) { setTitle(e.target.value); }} /></div><div><label style={s.label}>Visual Type</label><div style={{ display: "flex", gap: "3px" }}>{VIS_TYPES.map(function(vt) { return <button key={vt.id} onClick={function() { setVisType(vt.id); }} style={{ padding: "6px 10px", border: "1px solid " + (visType === vt.id ? C.accent : C.border), borderRadius: "5px", background: visType === vt.id ? C.accent + "25" : "transparent", color: visType === vt.id ? C.accent : C.muted, cursor: "pointer", fontSize: "11px", fontFamily: FONT, fontWeight: "600" }} title={vt.label}>{vt.icon}</button>; })}</div></div></div></div>

        {measures.length > 0 && <div style={s.card}><div style={s.zoneTitle}>Values (Measures)</div>{measures.map(function(m) { return <div key={m.field} style={{ display: "flex", gap: "6px", alignItems: "center", marginBottom: "6px" }}><span style={s.chip}>{(tableFields.find(function(f) { return f.name === m.field; }) || {}).displayName || m.field}</span><select style={Object.assign({}, s.select, { width: "90px" })} value={m.aggregation} onChange={function(e) { setMeasures(function(prev) { return prev.map(function(x) { return x.field === m.field ? Object.assign({}, x, { aggregation: e.target.value }) : x; }); }); }}>{AGG_OPTIONS.map(function(a) { return <option key={a} value={a}>{a}</option>; })}</select><input style={Object.assign({}, s.input, { width: "120px" })} value={m.alias} onChange={function(e) { setMeasures(function(prev) { return prev.map(function(x) { return x.field === m.field ? Object.assign({}, x, { alias: e.target.value }) : x; }); }); }} placeholder="Alias" /><button style={s.removeBtn} onClick={function() { setMeasures(function(prev) { return prev.filter(function(x) { return x.field !== m.field; }); }); }}>{"\u2715"}</button></div>; })}</div>}

        {groupBy.length > 0 && <div style={s.card}><div style={s.zoneTitle}>Rows (Group By)</div><div style={{ display: "flex", gap: "6px", flexWrap: "wrap" }}>{groupBy.map(function(g) { return <span key={g} style={s.chip}>{(tableFields.find(function(f) { return f.name === g; }) || {}).displayName || g}<button style={s.removeBtn} onClick={function() { setGroupBy(function(prev) { return prev.filter(function(x) { return x !== g; }); }); }}>{"\u2715"}</button></span>; })}</div></div>}

        {(visType === "matrix" || columns.length > 0) && <div style={s.card}><div style={s.zoneTitle}>Columns (Cross-Tab)</div><div style={{ display: "flex", gap: "6px", flexWrap: "wrap", marginBottom: "6px" }}>{columns.map(function(c) { return <span key={c} style={Object.assign({}, s.chip, { background: C.accent2 + "20", color: C.accent2, borderColor: C.accent2 + "40" })}>{(tableFields.find(function(f) { return f.name === c; }) || {}).displayName || c}<button style={s.removeBtn} onClick={function() { setColumns(function(prev) { return prev.filter(function(x) { return x !== c; }); }); }}>{"\u2715"}</button></span>; })}</div><select style={Object.assign({}, s.select, { fontSize: "11px" })} value="" onChange={function(e) { if (e.target.value && !columns.includes(e.target.value)) setColumns(function(prev) { return prev.concat([e.target.value]); }); }}><option value="">+ Add column...</option>{dimensionFields.filter(function(f) { return !columns.includes(f.name); }).map(function(f) { return <option key={f.name} value={f.name}>{f.displayName}</option>; })}</select></div>}

        <div style={s.card}><div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "8px" }}><div style={s.zoneTitle}>Filters</div><button style={s.btn("secondary", true)} onClick={function() { setFilters(function(prev) { return prev.concat([{ field: "", operator: "=", value: "" }]); }); }}>+ Add</button></div>{filters.map(function(f, idx) { return <div key={idx} style={{ display: "flex", gap: "6px", alignItems: "center", marginBottom: "6px" }}><select style={Object.assign({}, s.select, { width: "140px" })} value={f.field} onChange={function(e) { setFilters(function(prev) { return prev.map(function(x, i) { return i === idx ? Object.assign({}, x, { field: e.target.value }) : x; }); }); }}><option value="">Field...</option>{tableFields.map(function(ff) { return <option key={ff.name} value={ff.name}>{ff.displayName}</option>; })}</select><select style={Object.assign({}, s.select, { width: "65px" })} value={f.operator} onChange={function(e) { setFilters(function(prev) { return prev.map(function(x, i) { return i === idx ? Object.assign({}, x, { operator: e.target.value }) : x; }); }); }}>{OP_OPTIONS.map(function(o) { return <option key={o} value={o}>{o}</option>; })}</select><input style={Object.assign({}, s.input, { flex: 1 })} value={f.value} onChange={function(e) { setFilters(function(prev) { return prev.map(function(x, i) { return i === idx ? Object.assign({}, x, { value: e.target.value }) : x; }); }); }} placeholder="Value" /><button style={s.removeBtn} onClick={function() { setFilters(function(prev) { return prev.filter(function(_, i) { return i !== idx; }); }); }}>{"\u2715"}</button></div>; })}{filters.length === 0 && <div style={{ fontSize: "11px", color: C.muted }}>No filters</div>}</div>

        <div style={s.card}><div style={s.zoneTitle}>Options</div><div style={{ display: "flex", gap: "16px", flexWrap: "wrap", fontSize: "11px", alignItems: "center" }}><label style={{ display: "flex", alignItems: "center", gap: "5px", cursor: "pointer" }}><input type="checkbox" checked={subtotals} onChange={function(e) { setSubtotals(e.target.checked); }} /> Subtotals</label><label style={{ display: "flex", alignItems: "center", gap: "5px", cursor: "pointer" }}><input type="checkbox" checked={columnTotals} onChange={function(e) { setColumnTotals(e.target.checked); }} /> Column Totals</label><div style={{ display: "flex", alignItems: "center", gap: "4px" }}><span style={{ color: C.muted }}>Page break:</span><select style={Object.assign({}, s.select, { width: "120px", fontSize: "11px" })} value={pageBreakOn} onChange={function(e) { setPageBreakOn(e.target.value); }}><option value="">None</option>{groupBy.map(function(g) { return <option key={g} value={g}>{g}</option>; })}</select></div><div style={{ display: "flex", alignItems: "center", gap: "4px" }}><span style={{ color: C.muted }}>Sort:</span><select style={Object.assign({}, s.select, { width: "120px", fontSize: "11px" })} value={sortField} onChange={function(e) { setSortField(e.target.value); }}><option value="">None</option>{groupBy.concat(measures.map(function(m) { return m.field; })).map(function(f) { return <option key={f} value={f}>{f}</option>; })}</select><select style={Object.assign({}, s.select, { width: "65px", fontSize: "11px" })} value={sortDir} onChange={function(e) { setSortDir(e.target.value); }}><option value="ASC">ASC</option><option value="DESC">DESC</option></select></div></div></div>

        {/* ACTION BAR */}
        <div style={Object.assign({}, s.card, { background: "#0a0e14", borderColor: "#1a2a38" })}>
          <div style={{ display: "flex", gap: "8px", alignItems: "center", flexWrap: "wrap" }}>
            <select style={Object.assign({}, s.select, { width: "110px", fontWeight: "700" })} value={reportFormat} onChange={function(e) { setReportFormat(e.target.value); }}><option value="HTML5">HTML</option><option value="PDF">PDF</option><option value="EXCELOPENXML">Excel</option><option value="CSV">CSV</option></select>
            <button style={Object.assign({}, s.btn("green"), { padding: "12px 24px", fontSize: "13px", opacity: canGen ? 1 : 0.4 })} onClick={handleGenerateReport} disabled={!canGen || rendering}>{rendering ? "\u27F3 Generating..." : "\u25B6 Generate Report"}</button>
            <div style={{ width: "1px", height: "30px", background: C.border, margin: "0 4px" }} />
            <button style={Object.assign({}, s.btn("secondary", true), { opacity: canGen ? 1 : 0.4 })} onClick={handleGenerateRdl} disabled={!canGen || generating}>{generating ? "\u27F3..." : "\u2B07 RDL File"}</button>
            <button style={Object.assign({}, s.btn("secondary", true), { opacity: canGen ? 1 : 0.4 })} onClick={handlePreview} disabled={!canGen}>{"\u25CE"} Preview SQL</button>
            <div style={{ width: "1px", height: "30px", background: C.border, margin: "0 4px" }} />
            <input style={Object.assign({}, s.input, { width: "170px" })} value={saveName} onChange={function(e) { setSaveName(e.target.value); }} placeholder={editingId ? "Update name..." : "Report name..."} />
            <button style={Object.assign({}, s.btn(editingId ? "primary" : "secondary", true))} onClick={handleSave} disabled={!canGen}>{editingId ? "\u2713 Update" : "Save"}</button>
          </div>
          <div style={{ marginTop: "6px", fontSize: "10px", color: C.muted }}><strong style={{ color: C.green }}>Generate Report</strong> — renders final report. <strong style={{ color: C.muted, marginLeft: "10px" }}>RDL File</strong> — .rdl for Report Builder. <strong style={{ color: C.muted, marginLeft: "10px" }}>Save</strong> — stores for later.</div>
        </div>

        {/* RENDERED OUTPUT */}
        {renderedHtml && <div style={s.card}><div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "10px" }}><div style={s.zoneTitle}>Report Output</div><div style={{ display: "flex", gap: "8px", alignItems: "center" }}><span style={{ fontSize: "10px", color: C.muted }}>Mode: {renderMode}</span><button style={s.btn("secondary", true)} onClick={function() { var w = window.open(); w.document.write(renderedHtml); w.document.close(); }}>Fullscreen</button><button style={s.btn("secondary", true)} onClick={function() { setRenderedHtml(null); }}>Close</button></div></div><iframe srcDoc={renderedHtml} style={{ width: "100%", height: "500px", border: "1px solid " + C.border, borderRadius: "6px", background: "#fff" }} title="Report" /></div>}

        {preview && !renderedHtml && <div style={s.card}><div style={s.zoneTitle}>Preview</div><div style={{ marginBottom: "10px" }}><div style={s.label}>Generated SQL</div><pre style={s.code}>{preview.sql}</pre></div><div><div style={s.label}>RDL XML ({(preview.rdlSizeBytes / 1024).toFixed(1)} KB)</div><pre style={Object.assign({}, s.code, { maxHeight: "200px" })}>{preview.rdlXml && preview.rdlXml.substring(0, 3000)}{preview.rdlXml && preview.rdlXml.length > 3000 ? "\n... (truncated)" : ""}</pre></div></div>}
        {!selectedTable && <div style={Object.assign({}, s.card, { textAlign: "center", padding: "40px", color: C.muted })}><div style={{ fontSize: "28px", opacity: 0.3, marginBottom: "8px" }}>{"\u2605"}</div><div style={{ fontSize: "13px", fontWeight: "600" }}>Select a data source to start building</div></div>}
      </div>
    </div>}

    {/* SAVED REPORTS */}
    {panel === "saved" && <div style={s.card}><div style={s.cardTitle}>{"\u25C6"} Saved Reports</div>
      {savedReports.length === 0 && <div style={{ fontSize: "12px", color: C.muted, textAlign: "center", padding: "30px" }}>No saved reports. Build one and click Save.</div>}
      {savedReports.map(function(sr) { return <div key={sr.id} style={Object.assign({}, s.fileItem, { padding: "12px", flexDirection: "column", gap: "8px" })}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%" }}>
          <div><div style={{ fontSize: "13px", fontWeight: "700", color: C.white }}>{sr.name}</div><div style={{ fontSize: "10px", color: C.muted, marginTop: "2px" }}>Table: {sr.definition && sr.definition.dataSource} · {sr.definition && sr.definition.measures ? sr.definition.measures.length : 0} measures</div></div>
          <div style={{ display: "flex", gap: "6px" }}>
            <button style={s.btn("green", true)} onClick={function() { runSaved(sr.id, "HTML5"); }}>{"\u25B6"} View</button>
            <button style={s.btn("secondary", true)} onClick={function() { API.runSavedReportRendered(sr.id, "PDF"); }}>PDF</button>
            <button style={s.btn("secondary", true)} onClick={function() { API.runSavedReportRendered(sr.id, "EXCELOPENXML"); }}>Excel</button>
            <button style={s.btn("primary", true)} onClick={function() { loadReport(sr); }}>Edit</button>
            <button style={s.btn("secondary", true)} onClick={function() { API.runSavedReportRdl(sr.id); }}>RDL</button>
            <button style={Object.assign({}, s.btn("secondary", true), { color: C.red })} onClick={function() { API.deleteSavedReport(sr.id); setSavedReports(function(prev) { return prev.filter(function(r) { return r.id !== sr.id; }); }); }}>Delete</button>
          </div>
        </div>
        <div style={{ display: "flex", gap: "4px", flexWrap: "wrap" }}>
          {sr.definition && sr.definition.measures && sr.definition.measures.map(function(m, i) { return <span key={i} style={Object.assign({}, s.chip, { padding: "2px 8px", fontSize: "10px" })}>{m.aggregation}({m.field})</span>; })}
          {sr.definition && sr.definition.filters && sr.definition.filters.filter(function(f) { return f.field; }).map(function(f, i) { return <span key={"f" + i} style={Object.assign({}, s.chip, { padding: "2px 8px", fontSize: "10px", background: C.yellow + "15", color: C.yellow, borderColor: C.yellow + "30" })}>{f.field} {f.operator} {f.value}</span>; })}
        </div>
      </div>; })}
    </div>}
  </div>);
}

// Mount the app
ReactDOM.createRoot(document.getElementById('root')).render(<App />);
