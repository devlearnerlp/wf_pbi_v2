/**
 * API Service — Plain JavaScript, no build tools.
 * All functions are exposed on window.API for use by the React app.
 */
(function() {
  const BASE = '/api';

  function ct() { return { 'Content-Type': 'application/json' }; }
  function dl(blob, fn) { var u = URL.createObjectURL(blob); var a = document.createElement('a'); a.href = u; a.download = fn; a.click(); URL.revokeObjectURL(u); }

  async function jget(url) { var r = await fetch(url); if (!r.ok) throw new Error('Request failed: ' + r.status); return r.json(); }
  async function jpost(url, body) { var r = await fetch(url, { method: 'POST', headers: ct(), body: JSON.stringify(body) }); if (!r.ok) throw new Error('Request failed: ' + r.status); return r.json(); }
  async function pb(url, body, fn) { var r = await fetch(url, { method: 'POST', headers: ct(), body: JSON.stringify(body) }); dl(await r.blob(), fn); }

  window.API = {

    // ═══ Migration ═══
    analyzeMigration: async function(files) {
      var fd = new FormData(); files.forEach(function(f) { fd.append('files', f); });
      var r = await fetch(BASE + '/migration/analyze', { method: 'POST', body: fd });
      if (!r.ok) throw new Error('Analysis failed: ' + r.status); return r.json();
    },

    generateRdlBundle: async function(files) {
      var fd = new FormData(); files.forEach(function(f) { fd.append('files', f); });
      var r = await fetch(BASE + '/migration/generate-rdl', { method: 'POST', body: fd });
      if (!r.ok) throw new Error('RDL gen failed: ' + r.status); dl(await r.blob(), 'webfocus_rdl_bundle.zip');
    },

    exportDAX: function(c) { return pb(BASE + '/migration/export/dax', c, 'migration_dax.dax'); },
    exportMQuery: function(c) { return pb(BASE + '/migration/export/m', c, 'migration_m_queries.pq'); },
    exportReport: function(r) { return pb(BASE + '/migration/export/report', r, 'migration_report.txt'); },

    // ═══ Self-Service ═══
    getCatalog: function() { return jget(BASE + '/self-service/catalog'); },
    getCapabilities: function() { return jget(BASE + '/self-service/capabilities'); },

    importMasterFile: async function(file) {
      var fd = new FormData(); fd.append('file', file);
      var r = await fetch(BASE + '/self-service/catalog/import', { method: 'POST', body: fd });
      if (!r.ok) throw new Error('Import failed: ' + r.status); return r.json();
    },

    generateSelfServiceRdl: async function(def) {
      var r = await fetch(BASE + '/self-service/generate-rdl', { method: 'POST', headers: ct(), body: JSON.stringify(def) });
      if (!r.ok) throw new Error(await r.text() || 'Failed: ' + r.status);
      var title = (def.title || 'report').replace(/[^a-zA-Z0-9_\- ]/g, '').replace(/\s+/g, '_');
      dl(await r.blob(), title + '.rdl');
    },

    generateReport: async function(def, format) {
      format = format || 'HTML5';
      var r = await fetch(BASE + '/self-service/generate-report?format=' + format, { method: 'POST', headers: ct(), body: JSON.stringify(def) });
      if (!r.ok) throw new Error(await r.text() || 'Render failed: ' + r.status);
      var mode = r.headers.get('X-Render-Mode') || 'Unknown';
      if (format === 'HTML5' || format === 'HTML') return { html: await r.text(), mode: mode };
      var title = (def.title || 'report').replace(/[^a-zA-Z0-9_\- ]/g, '').replace(/\s+/g, '_');
      var ext = format === 'PDF' ? '.pdf' : format === 'EXCELOPENXML' ? '.xlsx' : format === 'CSV' ? '.csv' : '.html';
      dl(await r.blob(), title + ext);
      return { downloaded: true, mode: mode };
    },

    previewReport: async function(def) {
      var r = await fetch(BASE + '/self-service/preview', { method: 'POST', headers: ct(), body: JSON.stringify(def) });
      if (!r.ok) throw new Error('Preview failed: ' + r.status); return r.json();
    },

    saveReport: function(name, def) { return jpost(BASE + '/self-service/reports/save', { name: name, definition: def }); },

    updateReport: async function(id, name, def) {
      var r = await fetch(BASE + '/self-service/reports/' + id, { method: 'PUT', headers: ct(), body: JSON.stringify({ name: name, definition: def }) });
      if (!r.ok) throw new Error('Update failed: ' + r.status); return r.json();
    },

    listSavedReports: function() { return jget(BASE + '/self-service/reports'); },
    getSavedReport: function(id) { return jget(BASE + '/self-service/reports/' + id); },
    deleteSavedReport: function(id) { return fetch(BASE + '/self-service/reports/' + id, { method: 'DELETE' }); },

    runSavedReportRdl: async function(id) {
      var r = await fetch(BASE + '/self-service/reports/' + id + '/rdl');
      if (!r.ok) throw new Error('Run failed'); dl(await r.blob(), 'report_' + id + '.rdl');
    },

    runSavedReportRendered: async function(id, format) {
      format = format || 'HTML5';
      var r = await fetch(BASE + '/self-service/reports/' + id + '/render?format=' + format);
      if (!r.ok) throw new Error('Render failed');
      if (format === 'HTML5' || format === 'HTML') return { html: await r.text(), mode: r.headers.get('X-Render-Mode') };
      dl(await r.blob(), 'report_' + id + (format === 'PDF' ? '.pdf' : '.xlsx'));
      return { downloaded: true };
    },

    healthCheck: async function() { try { return await jget(BASE + '/migration/health'); } catch(e) { return null; } },
    downloadJSON: function(d, fn) { dl(new Blob([JSON.stringify(d, null, 2)], { type: 'application/json' }), fn); }
  };
})();
