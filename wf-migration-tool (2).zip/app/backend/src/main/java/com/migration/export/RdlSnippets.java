package com.migration.export;

/**
 * Pre-validated RDL XML snippets. Each snippet is a structurally valid
 * fragment of the RDL 2016 schema. They are assembled by RdlGenerator
 * via string replacement into the master template.
 *
 * WHY TEMPLATES: Building RDL with XMLStreamWriter is fragile — one
 * wrong element order and Report Builder rejects the entire file.
 * These templates are validated against the schema once, then reused.
 */
public final class RdlSnippets {

    private RdlSnippets() {}

    // ── Field ────────────────────────────────────────────────────
    public static String field(String name, String safeName, String type) {
        return "        <Field Name=\"" + safeName + "\">\n"
             + "          <DataField>" + esc(name) + "</DataField>\n"
             + "          <rd:TypeName>" + type + "</rd:TypeName>\n"
             + "        </Field>\n";
    }

    // ── Report Parameter ─────────────────────────────────────────
    public static String parameter(String name, String dataType, String prompt, String defaultValue) {
        StringBuilder sb = new StringBuilder();
        sb.append("    <ReportParameter Name=\"").append(esc(name)).append("\">\n");
        sb.append("      <DataType>").append(dataType).append("</DataType>\n");
        sb.append("      <Nullable>false</Nullable>\n");
        sb.append("      <Prompt>").append(esc(prompt)).append("</Prompt>\n");
        if (defaultValue != null && !defaultValue.isEmpty()) {
            sb.append("      <DefaultValue>\n");
            sb.append("        <Values>\n");
            sb.append("          <Value>").append(esc(defaultValue)).append("</Value>\n");
            sb.append("        </Values>\n");
            sb.append("      </DefaultValue>\n");
        }
        sb.append("    </ReportParameter>\n");
        return sb.toString();
    }

    public static String parametersBlock(String innerParams) {
        if (innerParams == null || innerParams.isEmpty()) return "";
        return "  <ReportParameters>\n" + innerParams + "  </ReportParameters>\n";
    }

    // ── Textbox ──────────────────────────────────────────────────
    public static String textbox(String name, String value, boolean isExpression,
                                  String top, String left, String height, String width,
                                  String fontSize, boolean bold, String color,
                                  String bgColor, String textAlign) {
        String val = isExpression ? value : esc(value);
        StringBuilder sb = new StringBuilder();
        sb.append("          <Textbox Name=\"").append(name).append("\">\n");
        sb.append("            <Paragraphs>\n");
        sb.append("              <Paragraph>\n");
        sb.append("                <TextRuns>\n");
        sb.append("                  <TextRun>\n");
        sb.append("                    <Value>").append(val).append("</Value>\n");
        sb.append("                    <Style>\n");
        sb.append("                      <FontFamily>Segoe UI</FontFamily>\n");
        sb.append("                      <FontSize>").append(fontSize).append("</FontSize>\n");
        if (bold) sb.append("                      <FontWeight>Bold</FontWeight>\n");
        if (color != null) sb.append("                      <Color>").append(color).append("</Color>\n");
        sb.append("                    </Style>\n");
        sb.append("                  </TextRun>\n");
        sb.append("                </TextRuns>\n");
        if (textAlign != null) {
            sb.append("                <Style>\n");
            sb.append("                  <TextAlign>").append(textAlign).append("</TextAlign>\n");
            sb.append("                </Style>\n");
        }
        sb.append("              </Paragraph>\n");
        sb.append("            </Paragraphs>\n");
        sb.append("            <Top>").append(top).append("</Top>\n");
        sb.append("            <Left>").append(left).append("</Left>\n");
        sb.append("            <Height>").append(height).append("</Height>\n");
        sb.append("            <Width>").append(width).append("</Width>\n");
        if (bgColor != null) {
            sb.append("            <Style>\n");
            sb.append("              <BackgroundColor>").append(bgColor).append("</BackgroundColor>\n");
            sb.append("            </Style>\n");
        }
        sb.append("          </Textbox>\n");
        return sb.toString();
    }

    // ── Tablix (complete valid structure) ─────────────────────────
    public static String tablix(String name, String dataSetName,
                                 String top, String width, String height,
                                 String columnsXml, String rowsXml,
                                 String colHierarchyXml, String rowHierarchyXml) {
        return "          <Tablix Name=\"" + name + "\">\n"
             + "            <TablixBody>\n"
             + "              <TablixColumns>\n"
             + columnsXml
             + "              </TablixColumns>\n"
             + "              <TablixRows>\n"
             + rowsXml
             + "              </TablixRows>\n"
             + "            </TablixBody>\n"
             + "            <TablixColumnHierarchy>\n"
             + "              <TablixMembers>\n"
             + colHierarchyXml
             + "              </TablixMembers>\n"
             + "            </TablixColumnHierarchy>\n"
             + "            <TablixRowHierarchy>\n"
             + "              <TablixMembers>\n"
             + rowHierarchyXml
             + "              </TablixMembers>\n"
             + "            </TablixRowHierarchy>\n"
             + "            <DataSetName>" + dataSetName + "</DataSetName>\n"
             + "            <Top>" + top + "</Top>\n"
             + "            <Left>0.25in</Left>\n"
             + "            <Height>" + height + "</Height>\n"
             + "            <Width>" + width + "</Width>\n"
             + "            <NoRowsMessage>No data available</NoRowsMessage>\n"
             + "            <Style>\n"
             + "              <FontFamily>Segoe UI</FontFamily>\n"
             + "              <FontSize>9pt</FontSize>\n"
             + "            </Style>\n"
             + "          </Tablix>\n";
    }

    public static String tablixColumn(String w) {
        return "                <TablixColumn>\n"
             + "                  <Width>" + w + "</Width>\n"
             + "                </TablixColumn>\n";
    }

    public static String tablixRow(String h, String cellsXml) {
        return "                <TablixRow>\n"
             + "                  <Height>" + h + "</Height>\n"
             + "                  <TablixCells>\n"
             + cellsXml
             + "                  </TablixCells>\n"
             + "                </TablixRow>\n";
    }

    public static String tablixCell(String textboxName, String value, boolean isExpression,
                                     String fontSize, boolean bold, boolean numeric,
                                     String bgColor, String fontColor) {
        String val = isExpression ? value : esc(value);
        StringBuilder sb = new StringBuilder();
        sb.append("                    <TablixCell>\n");
        sb.append("                      <CellContents>\n");
        sb.append("                        <Textbox Name=\"").append(textboxName).append("\">\n");
        sb.append("                          <Paragraphs>\n");
        sb.append("                            <Paragraph>\n");
        sb.append("                              <TextRuns>\n");
        sb.append("                                <TextRun>\n");
        sb.append("                                  <Value>").append(val).append("</Value>\n");
        sb.append("                                  <Style>\n");
        sb.append("                                    <FontFamily>Segoe UI</FontFamily>\n");
        sb.append("                                    <FontSize>").append(fontSize).append("</FontSize>\n");
        if (bold) sb.append("                                    <FontWeight>Bold</FontWeight>\n");
        if (fontColor != null) sb.append("                                    <Color>").append(fontColor).append("</Color>\n");
        if (numeric) sb.append("                                    <Format>#,##0.00</Format>\n");
        sb.append("                                  </Style>\n");
        sb.append("                                </TextRun>\n");
        sb.append("                              </TextRuns>\n");
        if (numeric) {
            sb.append("                              <Style>\n");
            sb.append("                                <TextAlign>Right</TextAlign>\n");
            sb.append("                              </Style>\n");
        }
        sb.append("                            </Paragraph>\n");
        sb.append("                          </Paragraphs>\n");
        sb.append("                          <Style>\n");
        if (bgColor != null) sb.append("                            <BackgroundColor>").append(bgColor).append("</BackgroundColor>\n");
        sb.append("                            <PaddingLeft>4pt</PaddingLeft>\n");
        sb.append("                            <PaddingRight>4pt</PaddingRight>\n");
        sb.append("                            <PaddingTop>2pt</PaddingTop>\n");
        sb.append("                            <PaddingBottom>2pt</PaddingBottom>\n");
        sb.append("                            <Border>\n");
        sb.append("                              <Style>Solid</Style>\n");
        sb.append("                              <Width>0.5pt</Width>\n");
        sb.append("                              <Color>#C0C0C0</Color>\n");
        sb.append("                            </Border>\n");
        sb.append("                          </Style>\n");
        sb.append("                        </Textbox>\n");
        sb.append("                      </CellContents>\n");
        sb.append("                    </TablixCell>\n");
        return sb.toString();
    }

    // Column hierarchy: one static member per column
    public static String staticColumnMember() {
        return "                <TablixMember />\n";
    }

    // Row hierarchy: static header member
    public static String staticRowHeaderMember() {
        return "                <TablixMember>\n"
             + "                  <KeepWithGroup>After</KeepWithGroup>\n"
             + "                  <RepeatOnNewPage>true</RepeatOnNewPage>\n"
             + "                </TablixMember>\n";
    }

    // Row hierarchy: detail group member
    public static String detailGroupMember(String groupName) {
        return "                <TablixMember>\n"
             + "                  <Group Name=\"" + groupName + "\" />\n"
             + "                </TablixMember>\n";
    }

    // Row hierarchy: nested group member with sort
    public static String groupMember(String groupName, String fieldExpr, boolean pageBreak, String childrenXml) {
        StringBuilder sb = new StringBuilder();
        sb.append("                <TablixMember>\n");
        sb.append("                  <Group Name=\"").append(groupName).append("\">\n");
        sb.append("                    <GroupExpressions>\n");
        sb.append("                      <GroupExpression>").append(fieldExpr).append("</GroupExpression>\n");
        sb.append("                    </GroupExpressions>\n");
        if (pageBreak) {
            sb.append("                    <PageBreak>\n");
            sb.append("                      <BreakLocation>Between</BreakLocation>\n");
            sb.append("                    </PageBreak>\n");
        }
        sb.append("                  </Group>\n");
        sb.append("                  <SortExpressions>\n");
        sb.append("                    <SortExpression>\n");
        sb.append("                      <Value>").append(fieldExpr).append("</Value>\n");
        sb.append("                      <Direction>Ascending</Direction>\n");
        sb.append("                    </SortExpression>\n");
        sb.append("                  </SortExpressions>\n");
        sb.append("                  <TablixMembers>\n");
        sb.append(childrenXml);
        sb.append("                  </TablixMembers>\n");
        sb.append("                </TablixMember>\n");
        return sb.toString();
    }

    // Static subtotal member
    public static String staticSubtotalMember() {
        return "                <TablixMember>\n"
             + "                  <KeepWithGroup>Before</KeepWithGroup>\n"
             + "                </TablixMember>\n";
    }

    // ── Chart ────────────────────────────────────────────────────
    public static String chart(String name, String dsName, String top,
                                String chartType, String categoryExpr,
                                String seriesXml) {
        StringBuilder sb = new StringBuilder();
        sb.append("          <Chart Name=\"").append(name).append("\">\n");
        sb.append("            <ChartCategoryHierarchy>\n");
        sb.append("              <ChartMembers>\n");
        sb.append("                <ChartMember>\n");
        if (categoryExpr != null) {
            sb.append("                  <Group Name=\"ChCat_").append(name).append("\">\n");
            sb.append("                    <GroupExpressions>\n");
            sb.append("                      <GroupExpression>").append(categoryExpr).append("</GroupExpression>\n");
            sb.append("                    </GroupExpressions>\n");
            sb.append("                  </Group>\n");
            sb.append("                  <Label>").append(categoryExpr).append("</Label>\n");
        }
        sb.append("                </ChartMember>\n");
        sb.append("              </ChartMembers>\n");
        sb.append("            </ChartCategoryHierarchy>\n");
        sb.append("            <ChartSeriesHierarchy>\n");
        sb.append("              <ChartMembers>\n");
        sb.append("                <ChartMember />\n");
        sb.append("              </ChartMembers>\n");
        sb.append("            </ChartSeriesHierarchy>\n");
        sb.append("            <ChartData>\n");
        sb.append("              <ChartSeriesCollection>\n");
        sb.append(seriesXml);
        sb.append("              </ChartSeriesCollection>\n");
        sb.append("            </ChartData>\n");
        sb.append("            <ChartAreas>\n");
        sb.append("              <ChartArea Name=\"Default\" />\n");
        sb.append("            </ChartAreas>\n");
        sb.append("            <ChartLegends>\n");
        sb.append("              <ChartLegend Name=\"Default\">\n");
        sb.append("                <Style />\n");
        sb.append("              </ChartLegend>\n");
        sb.append("            </ChartLegends>\n");
        sb.append("            <DataSetName>").append(dsName).append("</DataSetName>\n");
        sb.append("            <Top>").append(top).append("</Top>\n");
        sb.append("            <Left>0.25in</Left>\n");
        sb.append("            <Height>3.50in</Height>\n");
        sb.append("            <Width>8.00in</Width>\n");
        sb.append("          </Chart>\n");
        return sb.toString();
    }

    public static String chartSeries(String chartType, String valueExpr) {
        return "                <ChartSeries>\n"
             + "                  <ChartDataPoints>\n"
             + "                    <ChartDataPoint>\n"
             + "                      <ChartDataPointValues>\n"
             + "                        <Y>" + valueExpr + "</Y>\n"
             + "                      </ChartDataPointValues>\n"
             + "                      <ChartDataLabel>\n"
             + "                        <Visible>false</Visible>\n"
             + "                      </ChartDataLabel>\n"
             + "                    </ChartDataPoint>\n"
             + "                  </ChartDataPoints>\n"
             + "                  <Type>" + chartType + "</Type>\n"
             + "                </ChartSeries>\n";
    }

    // ── Page Header / Footer ─────────────────────────────────────
    public static String pageHeader(String titleText) {
        return "      <PageHeader>\n"
             + "        <Height>0.50in</Height>\n"
             + "        <PrintOnFirstPage>true</PrintOnFirstPage>\n"
             + "        <PrintOnLastPage>true</PrintOnLastPage>\n"
             + "        <ReportItems>\n"
             + textbox("PgHdrTitle", titleText, false, "0in", "0in", "0.40in", "9.50in", "14pt", true, "#1F4E79", null, "Center")
             + "        </ReportItems>\n"
             + "      </PageHeader>\n";
    }

    public static String pageFooter() {
        return "      <PageFooter>\n"
             + "        <Height>0.35in</Height>\n"
             + "        <PrintOnFirstPage>true</PrintOnFirstPage>\n"
             + "        <PrintOnLastPage>true</PrintOnLastPage>\n"
             + "        <ReportItems>\n"
             + textbox("FtrDate", "=\"Generated: \" & Format(Now(), \"yyyy-MM-dd HH:mm\")", true,
                       "0in", "0in", "0.25in", "4.00in", "8pt", false, "#999999", null, null)
             + textbox("FtrPage", "=\"Page \" & Globals!PageNumber & \" of \" & Globals!TotalPages", true,
                       "0in", "5.50in", "0.25in", "4.00in", "8pt", false, "#999999", null, "Right")
             + "        </ReportItems>\n"
             + "      </PageFooter>\n";
    }

    // ── XML escaping ─────────────────────────────────────────────
    public static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;");
    }
}
