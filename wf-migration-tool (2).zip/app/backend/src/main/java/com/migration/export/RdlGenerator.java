package com.migration.export;

import com.migration.converter.ExpressionConverter;
import com.migration.model.ConversionResult;
import com.migration.model.ParsedFexFile;
import com.migration.model.ParsedFexFile.*;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

import static com.migration.export.RdlSnippets.*;

/**
 * Template-based RDL generator.
 * Loads a pre-validated RDL template and fills placeholders with data from parsed FEX files.
 * No XMLStreamWriter — eliminates all element ordering bugs.
 */
@Service
public class RdlGenerator {

    private final ExpressionConverter exprConverter;
    private final String template;

    public RdlGenerator(ExpressionConverter exprConverter) {
        this.exprConverter = exprConverter;
        this.template = loadTemplate();
    }

    private String loadTemplate() {
        try {
            ClassPathResource res = new ClassPathResource("templates/report.rdl");
            return new String(res.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load RDL template", e);
        }
    }

    public byte[] generateRdl(ParsedFexFile fex, ConversionResult conversion) {
        AtomicInteger idGen = new AtomicInteger(0);
        List<TableRequest> requests = fex.getRequests() != null ? fex.getRequests() : List.of();

        String rdl = template;
        rdl = rdl.replace("{{SQL_QUERY}}", buildSql(requests));
        rdl = rdl.replace("{{FIELDS}}", buildFields(fex, idGen));
        rdl = rdl.replace("{{REPORT_PARAMETERS}}", buildParameters(fex));
        rdl = rdl.replace("{{BODY_HEIGHT}}", fmt(Math.max(2.0, calcBodyHeight(requests))));
        rdl = rdl.replace("{{BODY_ITEMS}}", buildBodyItems(fex, idGen));
        rdl = rdl.replace("{{PAGE_HEADER}}", buildPageHeader(fex));
        rdl = rdl.replace("{{PAGE_FOOTER}}", pageFooter());

        return rdl.getBytes(StandardCharsets.UTF_8);
    }

    // ═══ Fields ══════════════════════════════════════════════════
    private String buildFields(ParsedFexFile fex, AtomicInteger idGen) {
        StringBuilder sb = new StringBuilder();
        Set<String> added = new LinkedHashSet<>();
        for (TableRequest req : safe(fex.getRequests())) {
            for (String g : safe(req.getGroupBy())) if (added.add(g)) sb.append(field(g, safeName(g), guessType(g, fex)));
            for (String a : safe(req.getAcrossFields())) if (added.add(a)) sb.append(field(a, safeName(a), "System.String"));
            for (RequestField rf : safe(req.getFields())) {
                String n = str(rf.getName(), "F" + idGen.incrementAndGet());
                if (added.add(n)) sb.append(field(n, safeName(n), rf.getAggregation() != null ? "System.Decimal" : guessType(n, fex)));
            }
            for (ComputeField cf : safe(req.getComputes())) {
                String n = str(cf.getField(), "C" + idGen.incrementAndGet());
                if (added.add(n)) sb.append(field(n, safeName(n), "System.Decimal"));
            }
        }
        if (added.isEmpty()) sb.append(field("VALUE", "VALUE", "System.String"));
        return sb.toString();
    }

    // ═══ Parameters ══════════════════════════════════════════════
    private String buildParameters(ParsedFexFile fex) {
        StringBuilder inner = new StringBuilder();
        for (PromptSpec p : safe(fex.getPrompts())) {
            String name = str(p.getParamName(), "param_" + p.getLine());
            inner.append(parameter(safeName(name), mapParamType(p.getParamType()), str(p.getDescription(), name), p.getDefaultValue()));
        }
        for (Variable v : safe(fex.getVariables())) {
            String val = v.getValue() != null ? v.getValue().replaceAll("^['\"]|['\"]$", "") : "";
            inner.append(parameter(safeName(v.getName()), "String", str(v.getName(), "VAR"), val));
        }
        return parametersBlock(inner.toString());
    }

    // ═══ Body Items ══════════════════════════════════════════════
    private String buildBodyItems(ParsedFexFile fex, AtomicInteger idGen) {
        StringBuilder sb = new StringBuilder();
        List<TableRequest> requests = safe(fex.getRequests());
        if (requests.isEmpty()) {
            sb.append(textbox("EmptyMsg", "No report requests found", false, "0in", "0.25in", "0.50in", "6.00in", "12pt", false, null, null, null));
            return sb.toString();
        }

        double top = 0;
        for (int i = 0; i < requests.size(); i++) {
            TableRequest req = requests.get(i);
            String type = str(req.getType(), "TABLE");

            if ("GRAPH".equals(type)) {
                sb.append(buildChart(req, i, idGen, top));
                top += 4.0;
            } else if (!safe(req.getAcrossFields()).isEmpty()) {
                sb.append(buildTablix(req, i, idGen, top, true));
                top += 2.5;
            } else {
                sb.append(buildTablix(req, i, idGen, top, false));
                top += estimateHeight(req);
            }
        }
        return sb.toString();
    }

    // ═══ Tablix Builder ══════════════════════════════════════════
    private String buildTablix(TableRequest req, int reqIdx, AtomicInteger idGen, double top, boolean isMatrix) {
        // Build column specs
        List<String> labels = new ArrayList<>();
        List<String> exprs = new ArrayList<>();
        List<Boolean> isNum = new ArrayList<>();

        if (isMatrix) {
            String rowF = !safe(req.getGroupBy()).isEmpty() ? req.getGroupBy().get(0) : "Row";
            String colF = safe(req.getAcrossFields()).get(0);
            labels.add(rowF); exprs.add("=Fields!" + safeName(rowF) + ".Value"); isNum.add(false);
            RequestField mf = safe(req.getFields()).stream().filter(f -> f.getAggregation() != null).findFirst().orElse(null);
            if (mf != null) {
                labels.add(str(mf.getAlias(), mf.getName()));
                exprs.add("=Sum(Fields!" + safeName(mf.getName()) + ".Value)");
                isNum.add(true);
            } else {
                labels.add("Value"); exprs.add("=\"\""); isNum.add(false);
            }
        } else {
            for (RequestField rf : safe(req.getFields())) {
                if (rf.isNoprint()) continue;
                String n = str(rf.getName(), "FIELD");
                labels.add(str(rf.getAlias(), n));
                if (rf.getAggregation() != null) {
                    exprs.add("=" + mapAgg(rf.getAggregation()) + "(Fields!" + safeName(n) + ".Value)");
                    isNum.add(true);
                } else {
                    exprs.add("=Fields!" + safeName(n) + ".Value");
                    isNum.add(false);
                }
            }
            for (ComputeField cf : safe(req.getComputes())) {
                labels.add(str(cf.getField(), "COMPUTE"));
                exprs.add("=Fields!" + safeName(str(cf.getField(), "COMPUTE")) + ".Value");
                isNum.add(true);
            }
        }

        if (labels.isEmpty()) { labels.add("Value"); exprs.add("=\"(no data)\""); isNum.add(false); }

        int numCols = labels.size();
        double colW = Math.min(2.5, 9.5 / numCols);
        boolean hasSub = req.isSubTotals() && !safe(req.getGroupBy()).isEmpty() && !isMatrix;

        // Build columns XML
        StringBuilder colsXml = new StringBuilder();
        for (int i = 0; i < numCols; i++) colsXml.append(tablixColumn(fmt(colW) + "in"));

        // Build rows XML (header + detail + optional subtotal)
        StringBuilder rowsXml = new StringBuilder();

        // Header row
        StringBuilder hdrCells = new StringBuilder();
        for (int i = 0; i < numCols; i++) {
            hdrCells.append(tablixCell("H_" + reqIdx + "_" + idGen.incrementAndGet(), labels.get(i), false, "9pt", true, false, "#4472C4", "White"));
        }
        rowsXml.append(tablixRow("0.30in", hdrCells.toString()));

        // Detail row
        StringBuilder dataCells = new StringBuilder();
        for (int i = 0; i < numCols; i++) {
            dataCells.append(tablixCell("D_" + reqIdx + "_" + idGen.incrementAndGet(), exprs.get(i), true, "8pt", false, isNum.get(i), null, null));
        }
        rowsXml.append(tablixRow("0.25in", dataCells.toString()));

        // Subtotal row
        if (hasSub) {
            StringBuilder subCells = new StringBuilder();
            for (int i = 0; i < numCols; i++) {
                if (i == 0) subCells.append(tablixCell("S_" + reqIdx + "_" + idGen.incrementAndGet(), "=\"Subtotal\"", true, "8pt", true, false, "#E2EFDA", null));
                else if (isNum.get(i)) subCells.append(tablixCell("S_" + reqIdx + "_" + idGen.incrementAndGet(), exprs.get(i), true, "8pt", true, true, "#E2EFDA", null));
                else subCells.append(tablixCell("S_" + reqIdx + "_" + idGen.incrementAndGet(), "", false, "8pt", false, false, "#E2EFDA", null));
            }
            rowsXml.append(tablixRow("0.28in", subCells.toString()));
        }

        // Column hierarchy
        StringBuilder colHier = new StringBuilder();
        if (isMatrix && !safe(req.getAcrossFields()).isEmpty()) {
            colHier.append(staticColumnMember()); // row label column
            colHier.append("                <TablixMember>\n");
            colHier.append("                  <Group Name=\"ColGrp_").append(reqIdx).append("\">\n");
            colHier.append("                    <GroupExpressions>\n");
            colHier.append("                      <GroupExpression>=Fields!").append(safeName(req.getAcrossFields().get(0))).append(".Value</GroupExpression>\n");
            colHier.append("                    </GroupExpressions>\n");
            colHier.append("                  </Group>\n");
            colHier.append("                </TablixMember>\n");
        } else {
            for (int i = 0; i < numCols; i++) colHier.append(staticColumnMember());
        }

        // Row hierarchy
        StringBuilder rowHier = new StringBuilder();
        rowHier.append(staticRowHeaderMember());
        List<String> groups = safe(req.getGroupBy());
        if (!groups.isEmpty() && !isMatrix) {
            rowHier.append(buildNestedGroups(req, groups, 0, reqIdx));
        } else if (isMatrix && !groups.isEmpty()) {
            // Matrix row group
            String rowF = groups.get(0);
            rowHier.append("                <TablixMember>\n");
            rowHier.append("                  <Group Name=\"RowGrp_").append(reqIdx).append("\">\n");
            rowHier.append("                    <GroupExpressions>\n");
            rowHier.append("                      <GroupExpression>=Fields!").append(safeName(rowF)).append(".Value</GroupExpression>\n");
            rowHier.append("                    </GroupExpressions>\n");
            rowHier.append("                  </Group>\n");
            rowHier.append("                </TablixMember>\n");
        } else {
            rowHier.append(detailGroupMember("Detail_" + reqIdx));
        }
        if (hasSub) rowHier.append(staticSubtotalMember());

        String tblName = isMatrix ? "Mtx_" + reqIdx : "Tbl_" + reqIdx;
        return tablix(tblName, "MainDataSet", fmt(top) + "in", fmt(colW * numCols) + "in", fmt(estimateHeight(req)) + "in",
            colsXml.toString(), rowsXml.toString(), colHier.toString(), rowHier.toString());
    }

    private String buildNestedGroups(TableRequest req, List<String> groups, int depth, int reqIdx) {
        if (depth >= groups.size()) return detailGroupMember("Detail_" + reqIdx);
        String field = groups.get(depth);
        Set<String> pbs = req.getPageBreaks() != null ? req.getPageBreaks() : Collections.emptySet();
        return groupMember("Grp_" + reqIdx + "_" + safeName(field) + "_" + depth,
            "=Fields!" + safeName(field) + ".Value", pbs.contains(field),
            buildNestedGroups(req, groups, depth + 1, reqIdx));
    }

    // ═══ Chart Builder ═══════════════════════════════════════════
    private String buildChart(TableRequest req, int reqIdx, AtomicInteger idGen, double top) {
        String chartType = "Column";
        if (req.getGraphConfig() != null && req.getGraphConfig().getGraphType() != null) {
            chartType = switch (req.getGraphConfig().getGraphType().toUpperCase()) {
                case "PIE" -> "Shape"; case "LINE" -> "Line"; case "BAR", "VBAR" -> "Column";
                case "HBAR" -> "Bar"; case "AREA" -> "Area"; default -> "Column";
            };
        }

        String catExpr = null;
        if (!safe(req.getGroupBy()).isEmpty()) {
            catExpr = "=Fields!" + safeName(req.getGroupBy().get(0)) + ".Value";
        }

        StringBuilder series = new StringBuilder();
        boolean hasSeries = false;
        for (RequestField rf : safe(req.getFields())) {
            if (rf.getAggregation() != null) {
                series.append(chartSeries(chartType, "=Sum(Fields!" + safeName(str(rf.getName(), "VAL")) + ".Value)"));
                hasSeries = true;
            }
        }
        if (!hasSeries) {
            String fallback = !safe(req.getFields()).isEmpty() ? safeName(str(req.getFields().get(0).getName(), "VAL")) : "VALUE";
            series.append(chartSeries(chartType, "=Count(Fields!" + fallback + ".Value)"));
        }

        return chart("Cht_" + reqIdx, "MainDataSet", fmt(top) + "in", chartType, catExpr, series.toString());
    }

    // ═══ Page Header ═════════════════════════════════════════════
    private String buildPageHeader(ParsedFexFile fex) {
        List<String> headings = new ArrayList<>();
        for (TableRequest r : safe(fex.getRequests())) headings.addAll(safe(r.getHeadings()));
        if (headings.isEmpty()) return "";
        String title = headings.get(0).replaceAll("^[\"']|[\"']$", "").replaceAll("&\\w+", "").replaceAll("<[^>]+>", "").trim();
        if (title.isEmpty()) title = "Report";
        return pageHeader(title);
    }

    // ═══ SQL Builder ═════════════════════════════════════════════
    private String buildSql(List<TableRequest> requests) {
        if (requests.isEmpty()) return "SELECT 1";
        TableRequest req = requests.get(0);
        StringBuilder sql = new StringBuilder("SELECT ");
        List<String> cols = new ArrayList<>();
        for (String g : safe(req.getGroupBy())) cols.add(g);
        for (String a : safe(req.getAcrossFields())) if (!cols.contains(a)) cols.add(a);
        for (RequestField rf : safe(req.getFields())) { String n = str(rf.getName(), "F"); if (!cols.contains(n)) cols.add(n); }
        for (ComputeField cf : safe(req.getComputes())) { String n = str(cf.getField(), "C"); if (!cols.contains(n)) cols.add(n); }
        if (cols.isEmpty()) cols.add("*");
        sql.append(esc(String.join(", ", cols)));
        sql.append("\nFROM dbo.").append(esc(str(req.getFile(), "TABLE_NAME")));
        List<String> wheres = new ArrayList<>();
        for (FilterSpec f : safe(req.getFilters())) {
            String expr = f.getExpression();
            if (expr == null || expr.isBlank()) continue;
            expr = expr.replaceAll("(?i)^(WHERE|IF)\\s+", "").trim()
                .replaceAll("(?i)\\bEQ\\b", "=").replaceAll("(?i)\\bNE\\b", "&lt;&gt;")
                .replaceAll("(?i)\\bGT\\b", "&gt;").replaceAll("(?i)\\bLT\\b", "&lt;")
                .replaceAll("(?i)\\bGE\\b", "&gt;=").replaceAll("(?i)\\bLE\\b", "&lt;=")
                .replaceAll("&amp;(\\w+)", "@$1");
            if (!expr.isEmpty()) wheres.add(expr);
        }
        if (!wheres.isEmpty()) sql.append("\nWHERE ").append(String.join("\n  AND ", wheres));
        return sql.toString();
    }

    // ═══ Helpers ═════════════════════════════════════════════════
    private String safeName(String n) {
        if (n == null) return "UNNAMED";
        String r = n.replaceAll("[^a-zA-Z0-9_]", "_");
        if (!r.isEmpty() && Character.isDigit(r.charAt(0))) r = "F_" + r;
        return r.isEmpty() ? "UNNAMED" : r;
    }

    private String str(String v, String fallback) { return v != null && !v.isBlank() ? v : fallback; }

    @SuppressWarnings("unchecked")
    private <T> List<T> safe(List<T> list) { return list != null ? list : Collections.emptyList(); }

    private String fmt(double v) { return String.format(Locale.US, "%.2f", v); }

    private String mapAgg(String a) {
        if (a == null) return "First";
        return switch (a.toUpperCase()) { case "SUM" -> "Sum"; case "COUNT", "CNT" -> "Count"; case "AVG" -> "Avg"; case "MIN" -> "Min"; case "MAX" -> "Max"; default -> "Sum"; };
    }

    private String mapParamType(String t) {
        if (t == null) return "String";
        return switch (t.toUpperCase()) { case "INTEGER", "I", "INT" -> "Integer"; case "FLOAT", "DOUBLE", "D", "P" -> "Float"; case "DATE", "YYMD" -> "DateTime"; default -> "String"; };
    }

    private String guessType(String f, ParsedFexFile fex) {
        for (DefineField d : safe(fex.getDefines())) {
            if (d.getField() != null && d.getField().equalsIgnoreCase(f) && d.getFormat() != null) {
                if (d.getFormat().startsWith("A")) return "System.String";
                if (d.getFormat().startsWith("I")) return "System.Int32";
                if (d.getFormat().startsWith("D") || d.getFormat().startsWith("P")) return "System.Decimal";
            }
        }
        return "System.String";
    }

    private double calcBodyHeight(List<TableRequest> requests) {
        double h = 0;
        for (TableRequest r : requests) h += "GRAPH".equals(str(r.getType(), "TABLE")) ? 4.0 : estimateHeight(r);
        return h;
    }

    private double estimateHeight(TableRequest r) {
        int rows = 2 + safe(r.getGroupBy()).size() + (r.isSubTotals() && !safe(r.getGroupBy()).isEmpty() ? 1 : 0);
        return Math.max(0.3 * rows + 0.5, 1.5);
    }
}
