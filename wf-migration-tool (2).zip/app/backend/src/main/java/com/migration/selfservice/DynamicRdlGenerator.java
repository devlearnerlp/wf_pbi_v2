package com.migration.selfservice;

import com.migration.selfservice.SelfServiceModels.*;
import com.migration.export.RdlSnippets;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

import static com.migration.export.RdlSnippets.*;

/**
 * Template-based RDL generator for self-service report definitions.
 * Uses the same pre-validated RDL template as the migration generator.
 */
@Service
public class DynamicRdlGenerator {

    private final String template;

    public DynamicRdlGenerator() {
        try {
            ClassPathResource res = new ClassPathResource("templates/report.rdl");
            this.template = new String(res.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load RDL template", e);
        }
    }

    public byte[] generate(ReportDefinition def) {
        AtomicInteger idGen = new AtomicInteger(0);

        String rdl = template;
        rdl = rdl.replace("{{SQL_QUERY}}", buildSql(def));
        rdl = rdl.replace("{{FIELDS}}", buildFields(def, idGen));
        rdl = rdl.replace("{{REPORT_PARAMETERS}}", "");
        rdl = rdl.replace("{{BODY_HEIGHT}}", "8.00");
        rdl = rdl.replace("{{BODY_ITEMS}}", buildBodyItems(def, idGen));
        rdl = rdl.replace("{{PAGE_HEADER}}", pageHeader(str(def.getTitle(), "Report")));
        rdl = rdl.replace("{{PAGE_FOOTER}}", pageFooter());

        return rdl.getBytes(StandardCharsets.UTF_8);
    }

    // ═══ Fields ══════════════════════════════════════════════════
    private String buildFields(ReportDefinition def, AtomicInteger idGen) {
        StringBuilder sb = new StringBuilder();
        Set<String> added = new LinkedHashSet<>();
        for (String g : safe(def.getGroupBy())) if (added.add(g)) sb.append(field(g, safeName(g), "System.String"));
        for (String c : safe(def.getColumns())) if (added.add(c)) sb.append(field(c, safeName(c), "System.String"));
        for (MeasureField m : safe(def.getMeasures())) {
            String n = str(m.getField(), "M" + idGen.incrementAndGet());
            if (added.add(n)) sb.append(field(n, safeName(n), "System.Decimal"));
        }
        if (added.isEmpty()) sb.append(field("VALUE", "VALUE", "System.String"));
        return sb.toString();
    }

    // ═══ Body Items ══════════════════════════════════════════════
    private String buildBodyItems(ReportDefinition def, AtomicInteger idGen) {
        StringBuilder sb = new StringBuilder();

        // Title
        sb.append(textbox("Title", str(def.getTitle(), "Report"), false,
            "0in", "0.25in", "0.45in", "9.00in", "16pt", true, "#1F4E79", null, "Left"));

        String vt = def.getOptions() != null ? str(def.getOptions().getVisualType(), "table") : "table";
        boolean hasChart = vt.equals("bar") || vt.equals("line") || vt.equals("pie") || vt.equals("area");
        if (hasChart) sb.append(buildChart(def, idGen, 0.6));

        double tableTop = hasChart ? 4.5 : 0.6;
        boolean isMatrix = !safe(def.getColumns()).isEmpty();
        sb.append(buildTablix(def, idGen, tableTop, isMatrix));

        return sb.toString();
    }

    // ═══ Tablix ══════════════════════════════════════════════════
    private String buildTablix(ReportDefinition def, AtomicInteger idGen, double top, boolean isMatrix) {
        List<String> labels = new ArrayList<>();
        List<String> exprs = new ArrayList<>();
        List<Boolean> isNum = new ArrayList<>();

        if (isMatrix) {
            String rowF = !safe(def.getGroupBy()).isEmpty() ? def.getGroupBy().get(0) : "Row";
            labels.add(rowF); exprs.add("=Fields!" + safeName(rowF) + ".Value"); isNum.add(false);
            MeasureField mf = !safe(def.getMeasures()).isEmpty() ? def.getMeasures().get(0) : null;
            if (mf != null) {
                labels.add(str(mf.getAlias(), str(mf.getField(), "Value")));
                exprs.add("=" + mapAgg(mf.getAggregation()) + "(Fields!" + safeName(str(mf.getField(), "VAL")) + ".Value)");
                isNum.add(true);
            } else {
                labels.add("Value"); exprs.add("=\"\""); isNum.add(false);
            }
        } else {
            for (String g : safe(def.getGroupBy())) {
                labels.add(g); exprs.add("=Fields!" + safeName(g) + ".Value"); isNum.add(false);
            }
            for (MeasureField m : safe(def.getMeasures())) {
                String n = str(m.getField(), "MEASURE");
                labels.add(str(m.getAlias(), n));
                exprs.add("=" + mapAgg(m.getAggregation()) + "(Fields!" + safeName(n) + ".Value)");
                isNum.add(true);
            }
        }
        if (labels.isEmpty()) { labels.add("Value"); exprs.add("=\"(no data)\""); isNum.add(false); }

        int numCols = labels.size();
        double colW = Math.min(2.5, 9.0 / numCols);
        boolean hasSub = def.getOptions() != null && def.getOptions().isSubtotals() && !safe(def.getGroupBy()).isEmpty() && !isMatrix;

        // Columns
        StringBuilder colsXml = new StringBuilder();
        for (int i = 0; i < numCols; i++) colsXml.append(tablixColumn(fmt(colW) + "in"));

        // Rows
        StringBuilder rowsXml = new StringBuilder();

        StringBuilder hdrCells = new StringBuilder();
        for (int i = 0; i < numCols; i++) hdrCells.append(tablixCell("H_SS_" + idGen.incrementAndGet(), labels.get(i), false, "9pt", true, false, "#1F4E79", "White"));
        rowsXml.append(tablixRow("0.30in", hdrCells.toString()));

        StringBuilder dataCells = new StringBuilder();
        for (int i = 0; i < numCols; i++) dataCells.append(tablixCell("D_SS_" + idGen.incrementAndGet(), exprs.get(i), true, "8pt", false, isNum.get(i), null, null));
        rowsXml.append(tablixRow("0.25in", dataCells.toString()));

        if (hasSub) {
            StringBuilder subCells = new StringBuilder();
            for (int i = 0; i < numCols; i++) {
                if (i == 0) subCells.append(tablixCell("S_SS_" + idGen.incrementAndGet(), "=\"Subtotal\"", true, "8pt", true, false, "#E2EFDA", null));
                else if (isNum.get(i)) subCells.append(tablixCell("S_SS_" + idGen.incrementAndGet(), exprs.get(i), true, "8pt", true, true, "#E2EFDA", null));
                else subCells.append(tablixCell("S_SS_" + idGen.incrementAndGet(), "", false, "8pt", false, false, "#E2EFDA", null));
            }
            rowsXml.append(tablixRow("0.28in", subCells.toString()));
        }

        // Column hierarchy
        StringBuilder colHier = new StringBuilder();
        if (isMatrix && !safe(def.getColumns()).isEmpty()) {
            colHier.append(staticColumnMember());
            colHier.append("                <TablixMember>\n");
            colHier.append("                  <Group Name=\"ColGrp_SS\">\n");
            colHier.append("                    <GroupExpressions>\n");
            colHier.append("                      <GroupExpression>=Fields!").append(safeName(def.getColumns().get(0))).append(".Value</GroupExpression>\n");
            colHier.append("                    </GroupExpressions>\n");
            colHier.append("                  </Group>\n");
            colHier.append("                </TablixMember>\n");
        } else {
            for (int i = 0; i < numCols; i++) colHier.append(staticColumnMember());
        }

        // Row hierarchy
        StringBuilder rowHier = new StringBuilder();
        rowHier.append(staticRowHeaderMember());
        if (isMatrix && !safe(def.getGroupBy()).isEmpty()) {
            String rowF = def.getGroupBy().get(0);
            rowHier.append("                <TablixMember>\n");
            rowHier.append("                  <Group Name=\"RowGrp_SS\">\n");
            rowHier.append("                    <GroupExpressions>\n");
            rowHier.append("                      <GroupExpression>=Fields!").append(safeName(rowF)).append(".Value</GroupExpression>\n");
            rowHier.append("                    </GroupExpressions>\n");
            rowHier.append("                  </Group>\n");
            rowHier.append("                </TablixMember>\n");
        } else if (!safe(def.getGroupBy()).isEmpty() && !isMatrix) {
            rowHier.append(buildNestedGroups(def, 0));
        } else {
            rowHier.append(detailGroupMember("Detail_SS"));
        }
        if (hasSub) rowHier.append(staticSubtotalMember());

        String name = isMatrix ? "Matrix_SS" : "Table_SS";
        return tablix(name, "MainDataSet", fmt(top) + "in", fmt(colW * numCols) + "in", "2.00in",
            colsXml.toString(), rowsXml.toString(), colHier.toString(), rowHier.toString());
    }

    private String buildNestedGroups(ReportDefinition def, int depth) {
        List<String> groups = safe(def.getGroupBy());
        if (depth >= groups.size()) return detailGroupMember("Detail_SS");
        String field = groups.get(depth);
        boolean pgBreak = def.getOptions() != null && field.equals(def.getOptions().getPageBreakOn());
        return groupMember("Grp_SS_" + safeName(field) + "_" + depth,
            "=Fields!" + safeName(field) + ".Value", pgBreak,
            buildNestedGroups(def, depth + 1));
    }

    // ═══ Chart ═══════════════════════════════════════════════════
    private String buildChart(ReportDefinition def, AtomicInteger idGen, double top) {
        String vt = def.getOptions() != null ? str(def.getOptions().getVisualType(), "bar") : "bar";
        String chartType = switch (vt) { case "pie" -> "Shape"; case "line" -> "Line"; case "area" -> "Area"; default -> "Column"; };

        String catExpr = null;
        if (!safe(def.getGroupBy()).isEmpty()) catExpr = "=Fields!" + safeName(def.getGroupBy().get(0)) + ".Value";

        StringBuilder series = new StringBuilder();
        boolean hasSeries = false;
        for (MeasureField m : safe(def.getMeasures())) {
            series.append(chartSeries(chartType, "=Sum(Fields!" + safeName(str(m.getField(), "VAL")) + ".Value)"));
            hasSeries = true;
        }
        if (!hasSeries) series.append(chartSeries(chartType, "=Count(Fields!VALUE.Value)"));

        return chart("Chart_SS", "MainDataSet", fmt(top) + "in", chartType, catExpr, series.toString());
    }

    // ═══ SQL ═════════════════════════════════════════════════════
    private String buildSql(ReportDefinition def) {
        StringBuilder sql = new StringBuilder("SELECT ");
        List<String> cols = new ArrayList<>();
        for (String g : safe(def.getGroupBy())) cols.add(g);
        for (String c : safe(def.getColumns())) if (!cols.contains(c)) cols.add(c);
        for (MeasureField m : safe(def.getMeasures())) { String n = str(m.getField(), "M"); if (!cols.contains(n)) cols.add(n); }
        if (cols.isEmpty()) cols.add("*");
        sql.append(esc(String.join(", ", cols)));
        sql.append("\nFROM dbo.").append(esc(str(def.getDataSource(), "TABLE_NAME")));

        List<FilterCondition> filters = safe(def.getFilters());
        if (!filters.isEmpty()) {
            List<String> clauses = new ArrayList<>();
            for (FilterCondition f : filters) {
                if (f.getField() == null || f.getField().isBlank() || f.getValue() == null || f.getValue().isBlank()) continue;
                String val = f.getValue();
                String op = str(f.getOperator(), "=");
                if (op.equalsIgnoreCase("LIKE")) val = "'%" + val + "%'";
                else if (op.equalsIgnoreCase("IN")) val = "(" + val + ")";
                else { try { Double.parseDouble(val); } catch (Exception e) { val = "'" + val + "'"; } }
                clauses.add(esc(f.getField() + " " + op + " " + val));
            }
            if (!clauses.isEmpty()) sql.append("\nWHERE ").append(String.join("\n  AND ", clauses));
        }

        if (def.getOptions() != null && def.getOptions().getSortField() != null && !def.getOptions().getSortField().isEmpty()) {
            sql.append("\nORDER BY ").append(esc(def.getOptions().getSortField())).append(" ").append(str(def.getOptions().getSortDirection(), "ASC"));
        }
        return sql.toString();
    }

    // ═══ Helpers ═════════════════════════════════════════════════
    private String safeName(String n) {
        if (n == null) return "UNNAMED";
        String r = n.replaceAll("[^a-zA-Z0-9_]", "_");
        if (!r.isEmpty() && Character.isDigit(r.charAt(0))) r = "F_" + r;
        return r.isEmpty() ? "UNNAMED" : r;
    }

    private String str(String v, String fallback) { return v != null && !v.isBlank() ? v : fallback; }

    @SuppressWarnings("unchecked")
    private <T> List<T> safe(List<T> list) { return list != null ? list : Collections.emptyList(); }

    private String fmt(double v) { return String.format(Locale.US, "%.2f", v); }

    private String mapAgg(String a) {
        if (a == null) return "Sum";
        return switch (a.toUpperCase()) { case "SUM" -> "Sum"; case "AVG" -> "Avg"; case "MIN" -> "Min"; case "MAX" -> "Max"; case "COUNT" -> "Count"; default -> "Sum"; };
    }
}
